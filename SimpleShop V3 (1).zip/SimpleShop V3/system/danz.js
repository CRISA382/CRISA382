process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

const premium = JSON.parse(fs.readFileSync("./data/premium.json"))
const antilink = JSON.parse(fs.readFileSync("./data/antilink.json"))
const welcome = JSON.parse(fs.readFileSync("./data/welcome.json"))
const bljpm = JSON.parse(fs.readFileSync("./data/bljpm.json"))
const ownplus = JSON.parse(fs.readFileSync("./data/owner.json"))
const setbot = JSON.parse(fs.readFileSync("./data/bot.json"))
let domains = JSON.parse(fs.readFileSync("./data/domain.json"))
const list = JSON.parse(fs.readFileSync("./data/list.json"))
const channel = JSON.parse(fs.readFileSync("./data/channel.json"))
const stokdo = JSON.parse(fs.readFileSync("./data/stokdo.json"))
const script = JSON.parse(fs.readFileSync("./data/script.json"))
const premium2 = JSON.parse(fs.readFileSync("./data/premium2.json"))

module.exports = async (sock, m, chat) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
const { Client } = require('ssh2');

const prefix = '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const chats = chat
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const crypto = require("crypto")
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await sock.decodeJid(sock.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : ownplus.includes(m.sender)
const isGrupReseller = premium.includes(m.chat)
const isPremium = premium2.includes(m.sender) ? true : isOwner
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)
const func = require('../server/utils.js')
const vps = [
82,101,97,100,121,32,86,112,115,32,66,121,32,68,97,110,122,109,97,104,97,115,105,103,109,97,10,10,
        55357,56510,32,82,49,32,67,49,32,58,32,49,53,75,10,
        55357,56510,32,82,50,32,67,49,32,58,32,50,48,75,10,
        55357,56510,32,82,50,32,67,50,32,58,32,50,53,75,10,
        55357,56510,32,82,52,32,67,50,32,58,32,51,48,75,10,
        55357,56510,32,82,56,32,67,50,32,58,32,51,53,75,10,
        55357,56510,32,82,56,32,67,52,32,58,32,52,53,75,10,
        55357,56510,32,82,49,54,32,67,52,32,58,32,54,48,75,10,10,
        42,55357,56546,32,66,69,78,69,70,73,84,42,10,
        45,32,70,114,101,101,32,114,101,113,117,101,115,116,32,110,97,109,97,32,100,111,109,97,105,110,46,10,
        45,32,70,114,101,101,32,105,110,115,116,97,108,108,32,112,97,110,101,108,10,
        45,32,70,114,101,101,32,105,110,115,116,97,108,108,32,116,101,109,97,32,100,105,32,114,97,109,32,52,103,98,32,45,32,49,54,103,98,10,
        45,32,70,114,101,101,32,101,103,103,32,118,50,48,45,118,50,51,32,110,101,119,10,
        45,32,49,48,48,37,32,109,105,108,105,107,109,117,10,10,
        55357,57042,32,66,117,121,63,32,67,104,97,116,32,119,97,46,109,101,47,54,50,56,56,50,55,54,51,52,56,53,50,50
];
        
const script =  [
42,83,105,109,112,108,101,98,111,116,122,32,86,45,54,46,48,46,48,42,10,
        96,80,114,105,99,101,32,58,32,51,48,46,48,48,48,96,10,10,
        80,114,105,118,105,101,119,32,70,105,116,117,114,32,58,32,10,
        107,101,116,105,107,32,46,109,101,110,117,32,107,101,32,119,97,46,109,101,47,54,50,56,56,50,55,54,51,52,56,53,50,50,10,10,
        45,78,101,119,32,70,101,97,116,117,114,101,115,10,
        45,70,114,101,101,32,85,112,100,97,116,101,32,74,105,107,97,32,84,105,100,97,107,32,78,101,103,111,10,10,
        55357,57042,32,77,105,110,97,116,63,32,67,104,97,116,32,119,97,46,109,101,47,54,50,56,53,54,54,52,54,51,55,55,52,50
];
// >~~~~~~~ Metadata Groups ~~~~~~~~< //

try {
m.isGroup = m.chat.endsWith("g.us");
m.metadata = m.isGroup ? await sock.groupMetadata(m.chat).catch(_ => {}) : {};
const participants = m.metadata?.participants || [];
m.isAdmin = Boolean(participants.find(e => e.admin !== null && e.id === m.sender));
m.isBotAdmin = Boolean(participants.find(e => e.admin !== null && e.id === botNumber));
} catch (error) {
m.metadata = {};
m.isAdmin = false;
m.isBotAdmin = false;
}

// >~~~~~~~~~ Database ~~~~~~~~~~~< //

if (!isCmd) {
let check = list.find(e => e.cmd == m.text.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qpay = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `${namaowner}`}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Powered By ${namaowner}`}}}

const qown = {key: {remoteJid: "status@broadcast", participant: "13135550002@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qjasajpm = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Jasa Jpm By ${namaowner}`}}}

const qcmd = {key: {remoteJid: "status@broadcast", participant: "13135550002@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Powered By Danz`}}}

const qchannel = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `120363373941283254@newsletter`, newsletterName: `Hore`, jpegThumbnail: "", caption: `Powered By ${namaowner}`, inviteExpiration: 0 }}}

const qdan = {
    key: {
        fromMe: false,
        participant: '13135550002@s.whatsapp.net',
        remoteJid: "status@broadcast"
    },
    message: {
        orderMessage: {
            orderId: "2029",
            thumbnailUrl: "https://files.catbox.moe/etm9md.jpg",
            itemCount: 90999,
            status: "INQUIRY",
            surface: "CATALOG",
            message: `Sender : ${m.sender.split("@")[0]}`,
            token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
        }
    },
    contextInfo: {
        mentionedJid: m.sender.split,
        forwardingScore: 999,
        isForwarded: true
    }
}

// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = async (teks) => {
const commander = ` *Contoh Command :*\n*${cmd}* ${teks}`
return m.reply(commander)
}

if (isCmd) {
console.log(chalk.white.bgBlue.bold("[ Message Notification ]"), chalk.blue.bold(`\nSender : `), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`\nMessage :`), chalk.blue.bold(`${cmd}`), "\n")
}

const runtime = function(seconds = process.uptime()) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? "d " : "d ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? "h " : "h ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? "m " : "m ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? "s" : "s") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

if (m.isGroup && antilink.find(i => i.id == m.chat)) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(chats) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await sock.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let room = antilink.find(i => i.id == m.chat)
let delet = m.key.participant
let bang = m.key.id
await sock.sendMessage(m.chat, {text: `
*🔍 Link Grup Terdeteksi!*

Maaf, ${room.kick == true ? "Kamu akan saya kik" : "pesan kamu saya hapus"}, karena admin/owner bot telah mengaktifkan fitur *Antilink Grup*!
`, mentions: [m.sender]}, {quoted: m})
await sock.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
if (room.kick == true) {
await func.sleep(1000)
await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

const capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const Reply = m.reply;
const rreply = m.reply;

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function pickRandom(list) {
      return list[Math.floor(Math.random() * list.length)]
    }
    
    function generateRandomText(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let text = '';
  for (let i = 0; i < length; i++) {
    text += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return text;
}

async function deleteMessage(id) {
    return await sock.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: true,
        id: id
      }
    });
  };
    
    const repe = (teks) => { 
sock.sendMessage(m.chat, { text: teks, contextInfo: { 
externalAdReply : { 
showAdAttribution : true,  
title : "𝙳𝙰𝙽𝚉𝚇𝙱𝙾𝚃𝚂〽️", 
containsAutoReply : true, 
mediaType : 1, 
thumbnailUrl : "https://files.catbox.moe/5656ka.jpg", 
mediaUrl : null, 
sourceUrl : "https://whatsapp.com/channel/0029VayrD8xI1rcrL9sc4s03" }}}, { quoted: m }) 
}

const replyown = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Only owner can akses.`, 
thumbnailUrl: "https://i.supa.codes/Nfxd7k", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replypanel = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Silahkan Claim Data panel anda..`, 
thumbnailUrl: "https://i.supa.codes/oTlY4C", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replyprivate = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Only private chat`, 
thumbnailUrl: "https://i.supa.codes/dmiB79", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replyprem = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Only user Premium can akses.`, 
thumbnailUrl: "https://i.supa.codes/i-1HbY", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replytrx = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Notification Transaksi Succes ✅`, 
thumbnailUrl: "https://i.supa.codes/M2pht1", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replysaldo = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Saldo ${global.namaowner}`, 
thumbnailUrl: "https://i.supa.codes/mkT1nh", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

const replylistprem = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: "Shopbotz V3", 
body: `Berikut all list data premium.`, 
thumbnailUrl: "https://i.supa.codes/ZnuRnd", 
sourceUrl: null, 
mediaType: 1,
renderLargerThumbnail: true,
}}}, {quoted: qown})
}

// >~~~~~~~~~ Command ~~~~~~~~~~< //

switch (command) {
case "help": {
let teks = `Haii @${m.sender.split("@")[0]},
Perkenalkan, saya adalah *Shopbotz* Yang dirancang untuk membantu anda.

Keunggulan Layanan CS Kami:
✅ Cepat & Responsif – Waktu tanggapan yang optimal untuk kepuasan pelanggan.
✅ Profesional & Ramah – Pelayanan dilakukan dengan etika komunikasi yang baik.
✅ Solusi yang Efektif – Penyelesaian masalah secara tepat dan efisien.
✅ Dukungan Berkelanjutan – Pelanggan dapat terus memperoleh bantuan kapan pun diperlukan.

♨️ Menemukan bug / error saat melakukan interaksi dengan bot? hubungi CS kami.
✆ wa.me/${global.owner}

*#Jika ingin melihat produk danz dipersilahkan memilih button di bawah ini 👇*`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Select Menu",
                    sections: [
                        {
                            title: "Shopbotz V3",
                            highlight_label: "Recomended",
                            rows: [
                                {
                                	title: "Panel pterodactyl private",
                                    description:"",
                                    id: `.`
                                 },
                                                                {               
                                    title: "Panel pterodactyl public",
                                    description:"",
                                    id: `.`
                                 },
                                                                {                                                                
                                    title: "Adminpanel pterodactyl",
                                    description: "",
                                    id: `.`              
                                },
                                                                {                                                                
                                    title: "Resellerpanel pterodactyl",
                                    description: "",
                                    id: `.`                                              
                            },
                                                                {                                                                
                                    title: "Jasa Install",
                                    description: "",
                                    id: `.`                                                        
                            },
                                                                {                                                                
                                    title: "Jasa Rename, Addfitur, Fix Error",
                                    description: "",
                                    id: `.`              
                            },
                                                                {                                                                
                                    title: "Buy pulsa",
                                    description: "",
                                    id: `.`              
                            },
                                                                {                                                                
                                    title: "Buy paket",
                                    description: "",
                                    id: `.`              
                             },
                                                                {                                                                
                                    title: "Buy Diamond",
                                    description: "",
                                    id: `.`              
                              },
                                                                {                                                                
                                    title: "Virtualprivateserver",
                                    description: "Digitalocean ( Vcc )",
                                    id: `.`              
                                },
                                                                {                                                                
                                    title: "Virtualprivateserver",
                                    description: "Digitalocean ( PP )",
                                    id: `.`           
                              },
                                                                {                                                                
                                    title: "Script simplebotz",
                                    description: "Made by skyzo",
                                    id: `.`             
                             },
                                                                {                                                                
                                    title: "Script shopbotz",
                                    description: "Made by danz",
                                    id: `.`
                             },
                                                                {                                                                
                                    title: "Nokos Whatsapp",
                                    description: "All negara ( sesuai stok ! )",
                                    id: `.`                                              
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await sock.sendMessage(m.chat, {
        document: await fs.readFileSync("./package.json"), 
        fileName: "© D A N Z O F F I C I A L", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${teks}`,
        contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `Shopbotz V3`,
newsletterJid: global.idsaluran
  }, 
externalAdReply: {
title: `Status : ${isOwner ? "Ownerbot" : isGrupReseller ? "Premium" : "Gratisan"}`,
thumbnailUrl: imgdanz,
body: `♨️ ${runtime(process.uptime())}️`, 
sourceUrl: linksaluran,
previewType: "PHOTO"
},
   },
        footer: "Produk By Danz",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: qcmd })
};
break



case "menu": {
let menu = `*Haii* @${m.sender.split("@")[0]}
Perkenalkan saya adalah bot *Shopbotz* Dirancang oleh @${global.owner}.

*━ Information Bot*
  ▢ Botname : *${namabot}*
  ▢ Mode : *${sock.public ? "Public" : "Self"}*
  ▢ Version : *V3.0.0*`;

let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Select Menu",
                    sections: [
                        {
                            title: "Shopbotz V3",
                            highlight_label: "",
                            rows: [
                                {
                                	title: "🛍️ Shopmenu",
                                    description:"Menampilkan menu shop.",
                                    id: `.shopmenu`
                                 },
                                                                {               
                                    title: "🌐 Jpmmenu",
                                    description:"Menampilkan menu jpm.",
                                    id: `.menujpm`
                                 },
                                                                {               
                                    title: "📡 Channelmenu",
                                    description:"Menampilkan menu channel.",
                                    id: `.menuchannel`
                                 },
                                                                {                                                                
                                    title: "📌 Panelmenu",
                                    description: "Menampilkan menu panel.",
                                    id: `.panelmenu`                
                                },
                                                                {               
                                    title: "📣 Groupmenu",
                                    description:"Menampilkan menu group.",
                                    id: `.groupmenu`
                                 },
                                                                {                                                                
                                    title: "🖇️ Ownermenu",
                                    description: "Menampilkan menu owner.",
                                    id: `.ownermenu`           
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]

    await sock.sendMessage(m.chat, {
        document: await fs.readFileSync("./package.json"), 
        fileName: "© D A N Z O F F I C I A L", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner}`,
newsletterJid: global.idsaluran
  }, 
externalAdReply: {
title: `Status : ${isOwner ? "Ownerbot" : isGrupReseller ? "Premium" : "Gratisan"}`,
thumbnailUrl: imgdanz,
body: `Haii ${m.pushName} 👋️`, 
sourceUrl: linksaluran,
previewType: "PHOTO"
},
   },
        footer: "Shopbotz By Danz",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: qcmd })
};
break

case "menujpm": {
let menu = `╭─▧ *Jpmmenu*
│ • .addidch
│ • .delidch
│ • .addowner
│ • .delowner
│ • .hidetag
│ • .jpmall
│ • .jpm
│ • .jpmtesti
╰ • .jpmht`;
  let buttons = [
        {            
            buttonId: ".menu", 
            buttonText: { displayText: "Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case "menuchannel": {
let menu = `╭─▧ *Channelmenu*
│ • .cekidch
│ • .reactch
│ • .addidch
│ • .listidch
│ • .delidch
╰ • .joinch`;
  let buttons = [
        {            
            buttonId: ".menu", 
            buttonText: { displayText: "💫 Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case "panelmenu": {
let menu = `━ *Panelmenu*

╭─▧ *Server V1*
│ • .1gb - unlimited
│ • .listpanel
│ • .listadmin
│ • .deladmin
│ • .delpanel
╰ • .clearallserver`
let buttons = [
        {
            buttonId: ".panelmenu2", 
            buttonText: { displayText: "V2" }
        }, 
        {
            buttonId: ".menu", 
            buttonText: { displayText: "Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case "shopmenu": {
let menu = `Haii @${m.sender.split("@")[0]},
*Selamat datang di menu Shop kami, saya akan membuat anda mengenalkan fitur terbaru kami !*

╭─▧ *GateawayForest*
│ • .buypanel
│ • .buyresellerpanel
│ • .buyadminpanel
│ • .buyvps
│ • .buyscript
╰ • .deposit

╭─▧ *Topupgame*
│ • .mlbb
│ • .ml_wdp
│ • .ml_sl
│ • .ml_tl
│ • .hok
│ • .aov
│ • .lol
│ • .coc
│ • .ff
╰ • .pubg

╭─▧ *Topuppaketdata*
│ • .byu_data
│ • .tsel_data
│ • .xl_data
│ • .axis_data
│ • .isat_data
╰ • .tri_data

╭─▧ *Topuppulsa*
│ • .byu_pulsa
│ • .tsel_pulsa
│ • .xl_pulsa
│ • .axis_pulsa
│ • .isat_pulsa
╰ • ..tri_pulsa

╭─▧ *Voucher*
╰ • .pln

\`\`\`📄 Jika ingin topup menggunakan qris ketik .toup code,tujuan\`\`\`

\`\`\`⭐ Jika ingin topup menggunakan saldo admin ketik .buy code,tujuan\`\`\`
`;
let buttons = [
        {
            buttonId: ".shopv2", 
            buttonText: { displayText: "✨ Gateaway Orderkuota" }
        }, 
        {
            buttonId: ".menu", 
            buttonText: { displayText: "⭐ Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case "shopv2": {
let otomatis = `━ *ShoppV2*

╭─▧ *Shoopmenu*
│ • .buypanelkut
│ • .buyadpkut
│ • .buyresellerkut
│ • .buyscriptkut
│ • .buydigitalocean
│ • .buyvpskut
│ • .buypulsa
│ • .buykuota
│ • .buysaldo
│ • .topupml
│ • .topupff
╰ • .topuppubg
`
let buttons = [
        {            
            buttonId: ".menu", 
            buttonText: { displayText: "Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${otomatis}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case 'panelmenu2': {
let menu = `━ *Panelmenu*

╭─▧ *Server V2*
│ • .1gb-v2 - unlimited-v2
│ • .listpanel-v2
│ • .listadmin-v2
│ • .deladmin-v2
│ • .delpanel-v2
╰ • .clearallserver-v2`
let buttons = [
        {            
            buttonId: ".menu", 
            buttonText: { displayText: "⭐ Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case 'ownermenu': {
let menu = `━ *Ownermenu*

╭─▧ *Ownermenu*
│ • .deposit
│ • .saldo
│ • .done
│ • .proses
│ • .pushkontak
│ • .pushkontak2
│ • .listgc
│ • .tourl
│ • .brat
│ • .restartbot
│ • .getmyip
│ • .getcase
│ • .backupsc
│ • .autoread
│ • .autoreadsw
│ • .autotyping
│ • .autorecording
╰ • .anticall`
let buttons = [
        {            
            buttonId: ".aksesmenu", 
            buttonText: { displayText: "✨ Aksesmenu" }
        }, 
        {
            buttonId: ".menu", 
            buttonText: { displayText: "⭐ Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case 'aksesmenu': {
let menu = `━ *Aksesmenu*

╭─▧ *Aksesmenu*
│ • .addowner
│ • .addpremium
│ • .addaksesjpm
│ • .delowner
│ • .delpremium
╰ • .delaksesjpm`
let buttons = [
        {                        
            buttonId: ".menu", 
            buttonText: { displayText: "⭐ Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case 'groupmenu': {
let menu = `━ *Grupmenu*

╭─▧ *Groupmenu*
│ • .antilink
│ • .addbl
│ • .unbl
│ • .welcome
│ • .buatgc
│ • .kick
│ • .promote
│ • .demote
│ • .hidetag
│ • .close/open
│ • .resetlink
╰ • .leave`
let buttons = [
        {                        
            buttonId: ".menu", 
            buttonText: { displayText: "⭐ Back" }
        }
    ];

    let buttonMessage = {
        document: await fs.readFileSync("./package.json"), 
        fileName: "⭐ Shopbotz", 
        mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        caption: `${menu}`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idSaluran,
                newsletterName: `Danz ID`
            }, 
            externalAdReply: {
                title: global.namaowner, 
                body: `Hii ${m.pushName}`, 
                thumbnailUrl: "https://i.supa.codes/jrFWxO", 
                renderLargerThumbnail: true, 
                mediaType: 1, 
                sorceUrl: null,
            }
        },
        footer: "MarketDann",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };
    // Kirim menu sebagai pesan
    await sock.sendMessage(m.chat, buttonMessage, { quoted: qcmd });
};
break

case "addpremium":
case "addprem": {
  if (!isOwner) return replyown(msg.owner);
  if (!text && !m.quoted) return example("6285XX atau @tag");

  let input = m.quoted 
    ? m.quoted.sender 
    : m.mentionedJid?.[0] || text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  if (!input) return example("6285XX atau @tag");
  if (premium2.includes(input) || input == botNumber || input.split("@")[0] == global.owner)
    return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai premium!`);

  premium2.push(input);
  fs.writeFileSync("./data/premium2.json", JSON.stringify(premium2, null, 2));
  m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *user premium*`);

  const thumbUrl = "https://i.supa.codes/K4DNT6";
  await sock.sendMessage(input, {
    text: `✨ *Notifikasi Premium*\n\nNomor Anda telah ditambahkan sebagai *User Premium*\n🗓️ Tanggal: ${func.tanggal(Date.now())}\n✉️ Oleh: ${m.pushName || m.sender.split("@")[0]}`,
    contextInfo: {
      externalAdReply: {
        title: "Akses Premium Aktif",
        body: "Selamat, kamu sekarang Premium!",
        thumbnailUrl: thumbUrl,
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;

case "addbl": { // Mengaktifkan blacklist
    if (!isOwner) return replyown(msg.owner)
    if (!m.isGroup) return m.reply(msg.group)
    if (bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah aktif!`)
    
    bljpm.push(m.chat)
    await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
    return m.reply(`Berhasil menghidupkan blacklist jpm di grup ini ✅`)
}
break

case "unbl": { // Menonaktifkan blacklist
    if (!isOwner) return replyown(msg.owner)
    if (!m.isGroup) return m.reply(msg.group)
    if (!bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah tidak aktif!`)
    
    let posi = bljpm.indexOf(m.chat)
    await bljpm.splice(posi, 1)
    await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
    return m.reply(`Berhasil mematikan blacklist jpm di grup ini ✅`)
}
break

case "myip": case "getmyip": {
if (!isOwner) return replyown(msg.owner)
let t = await func.fetchJson('https://api64.ipify.org?format=json')
m.reply(`IP Panel : ${t.ip}`)
}
break

case "setppbot": case "setpp": {
if (!isOwner) return m.reply(msg.owner)
if (!/image/.test(mime)) return example("dengan mengirim foto")
const { S_WHATSAPP_NET } = require("baileys");

const buffer = await sock.downloadAndSaveMediaMessage(qmsg)
var { img } = await func.generateProfilePicture(buffer)
await sock.query({
tag: 'iq',
attrs: {
to: S_WHATSAPP_NET,
type: 'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
m.reply("Berhasil mengganti profile bot ✅")
fs.unlinkSync(buffer)
}
break

case "rst": case "restartbot": {
if (!isOwner) return
const { spawn } = require("child_process");

function restartServer() {
  // Spawn proses baru untuk menjalankan ulang server
  const newProcess = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: "inherit",
  });

  // Keluar dari proses lama
  process.exit(0);
}

await m.reply("Restarting bot . . .")
// Contoh penggunaan: Restart setelah 5 detik
await setTimeout(() => {
  restartServer();
}, 5000);
}
break

case "getcase": {
if (!isOwner) return
if (!text) return example("menu")
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./danz.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

case "buatgc": {
if (!isOwner) return m.reply(msg.owner)
if (!q) return example("nama grup")
let res = await sock.groupCreate(q, [])
const urlGrup = "https://chat.whatsapp.com/" + await sock.groupInviteCode(res.id)
let teks = `
*Grup WhatsApp Berhasil Dibuat ✅*
${urlGrup}
`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak2": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text) return example("pesannya")
const teks = text
const jidawal = m.chat
const data = await sock.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("pesannya")
const meta = await sock.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Target Grup Pushkontak\n",
  contextInfo: {
   mentionedJid: [m.sender], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await sock.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

delete global.textpushkontak
await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break

case "delpremium":
case "delprem": {
  if (!isOwner) return replyown(msg.owner);
  if (!text && !m.quoted) return example("6285XX atau @tag");

  if (text === "all") {
    premium2.length = 0;
    fs.writeFileSync("./data/premium2.json", JSON.stringify(premium2, null, 2));
    m.reply("Berhasil menghapus semua user premium ✅");
    await sock.sendMessage("6285664637742@s.whatsapp.net", {
      text: `⚠️ *User Premium Dihapus Massal*\n\nSemua user premium dihapus oleh *${m.sender.split("@")[0]}*.`
    });
    return;
  }

  let input = m.quoted 
    ? m.quoted.sender 
    : m.mentionedJid?.[0] || text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  if (!input || !premium2.includes(input) || input == botNumber || input.split("@")[0] == global.owner)
    return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai user premium!`);

  premium2.splice(premium2.indexOf(input), 1);
  fs.writeFileSync("./data/premium2.json", JSON.stringify(premium2, null, 2));
  m.reply(`Sukses menghapus ${input.split("@")[0]} dari *user premium*`);

  const thumbUrl = "https://i.supa.codes/K4DNT6";
  await sock.sendMessage(input, {
    text: `🗑️ *Premium Dihapus*\n\nNomor Anda *${input.split("@")[0]}* telah dicabut dari daftar user premium oleh *${m.sender.split("@")[0]}*.`,
    contextInfo: {
      externalAdReply: {
        title: "Akses Premium Dicabut",
        body: "Status premium kamu telah dihapus.",
        thumbnailUrl: thumbUrl,
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;

case "listprem": case "listpremium": {
if (premium2.length < 1) return m.reply("Tidak ada user premium")
let teks = ""
for (let i of premium2) {
teks += `\n* @${i.split("@")[0]}\n`
}
return replylistprem(teks)
}
break

case "antilink": {
  if (!isOwner) return m.reply(msg.owner);
  if (!m.isGroup) return m.reply(msg.group);

  let room = antilink.find((i) => i.id == m.chat);

  if (!args[0] || !args[1]) return example("nokick/kick on/off");

  let mode = args[0].toLowerCase();
  let state = args[1].toLowerCase();
  let isOn = /on/g.test(state);
  let isOff = /off/g.test(state);

  if (!["kick", "nokick", "kik", "nokik"].includes(mode))
    return example("nokick/kick on/off");

  if (!isOn && !isOff) return example("nokick/kick on/off");

  let shouldKick = mode === "kick" || mode === "kik";

  if (isOn) {
    if (room && room.kick === shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah aktif!`
      );

    if (room) {
      let ind = antilink.indexOf(room);
      antilink.splice(ind, 1);
    }

    antilink.push({ id: m.chat, kick: shouldKick });
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil diaktifkan ✅`
    );
  } else if (isOff) {
    if (!room || room.kick !== shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah tidak aktif!`
      );

    let ind = antilink.indexOf(room);
    antilink.splice(ind, 1);
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil dimatikan ✅`
    );
  }
}

case "leave": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
await func.sleep(4000)
await sock.groupLeave(m.chat)
}
break

case "reactch": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterReactMessage(res.id, serverId, args[1])
m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

case "demote":
case "promote": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (m.quoted || text) {
var action
let target = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await sock.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await sock.sendMessage(m.chat, {text: `Berhasil ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return example("@tag/6285###")
}
}
break

case "kick": case "kik": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (text || m.quoted) {
const input = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await sock.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await sock.groupParticipantsUpdate(m.chat, [input], 'remove')
} else {
return example("@tag/reply")
}
}
break

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await sock.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await sock.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

case "resetlinkgc": case "resetlink": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
await sock.groupRevokeInvite(m.chat)
m.reply("Sukses mereset ling grup ini ✅")
}
break

case "brat": {
	if (!isOwner) return replyown(msg.owner)
if (!text) return example("Hello World!")
await sock.sendStimg(m.chat, `https://restapi.simplebot.my.id/imagecreator/brat?apikey=${global.ApikeyRestApi}&text=${text}`, m, {packname: global.namaowner})
}
break

case "welcome": case "welcom": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text || !/on|off/.test(text)) return example("on/off")
const input = text.toLowerCase()
if (/on/.test(input)) {
if (welcome.includes(m.chat)) return m.reply(`Welcome di grup ini sudah aktif!`)
welcome.push(m.chat)
await fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
return m.reply(`Berhasil menghidupkan Welcome di grup ini ✅`)
} 
if (/off/.test(input)) {
if (!welcome.includes(m.chat)) return m.reply(`Welcome di grup ini sudah tidak aktif!`)
let posi = welcome.indexOf(m.chat)
await welcome.splice(posi, 1)
await fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
return m.reply(`Berhasil mematikan welcome di grup ini ✅`)
}
}
break

case "done": case "proses": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("jasa install panel")
let teks = `*Dana Masuk ✅*
* ${text}
* ${func.tanggal(Date.now())}

*Testimoni :*
* ${global.linksaluran}
`
await sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, "0@s.whatsapp.net", global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.namasaluran
   }
  },}, {quoted: qdan})
}
break

case "joinch": case "joinchannel": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("linkchnya")
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterFollow(res.id)
m.reply(`*Berhasil join channel whatsapp ✅*

* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*`)
}
break


case "tourl": {
	if (!isOwner) return replyown(msg.owner)
    if (!/image|video/.test(mime)) return repe(example("Kirim atau reply foto/video!"));

    const FormData = require('form-data');
    const { fromBuffer } = require('file-type');
    async function getUrls(buffer) {
        let { ext } = await fromBuffer(buffer);
        let bodyForm = new FormData();
        bodyForm.append("fileToUpload", buffer, "file." + ext);
        bodyForm.append("reqtype", "fileupload");
        let res = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: bodyForm,
        });
        return await res.text();
    }

    try {
        let media = await sock.downloadAndSaveMediaMessage(qmsg);
        let buffer = fs.readFileSync(media);
        let url = await getUrls(buffer);
        let ext = await fromBuffer(buffer);
        let waktu = func.tanggal(Date.now());

        let teks = `*✅ Berhasil Mengupload Media!*

📤 *Tipe:* ${mime.startsWith("image") ? "Image" : "Video"}
🕒 *Waktu:* ${waktu}
🔗 *Link:* ${url}

*Gunakan link ini untuk membagikan media kamu!*`;

        await sock.sendMessage(m.chat, { text: teks }, { quoted: m });
        await fs.unlinkSync(media);
    } catch (err) {
        m.reply("Terjadi kesalahan: " + err.message);
    }
}
break;

case "cekidch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`;
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: "Cek by botz."
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await sock.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
});
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addaksesjpm":
case "addaksesgc": {
  if (!isOwner) return replyown(msg.owner)
  if (!m.isGroup) return m.reply(msg.group)

  const input = m.chat
  if (premium.includes(input)) return m.reply(`Succes meng addakses Jpmchannel ke Grup`)

  premium.push(input)
  await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
  m.reply(`Haii ${m.pushName}, Succes meng add akses Grup ini ✅`)

  // Ambil metadata grup
  let metadata = await sock.groupMetadata(m.chat)
  let namaGrup = metadata.subject
  let idGrup = m.chat
  let jumlahMember = metadata.participants.length
  let Ownernumber = owner + "@s.whatsappnet"

  // Kirim ke Owner  
  const captiondone = `Halo ${namaowner}, 
${m.pushName} Berhasil meng add akses grup

*Nama Grup:* ${namaGrup}
*ID Grup:* ${idGrup}
*Jumlah Member:* ${jumlahMember}`

// Kirim laporan ke nomor admin
    sock.sendMessage("6285664637742@s.whatsapp.net", {
        text: `Laporan:\nGrup ${input} telah diberi akses reseller panel oleh owner.`
    })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delaksesjpm": case "delaksesgc": {
if (!isOwner) return replyown(msg.owner)
if (premium.length < 1) return m.reply("Tidak ada grup reseller panel")
if (!m.isGroup) return m.reply(msg.group)
let input = text ? text : m.chat
if (input == "all") {
premium.length = 0
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
return m.reply(`Berhasil menghapus semua grup reseller panel ✅`)
}
if (!premium.includes(input)) return m.reply(`Grup ini bukan grup reseller panel!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus grup reseller panel ✅`)

// Ambil metadata grup
  let metadata = await sock.groupMetadata(m.chat)
  let namaGrup = metadata.subject
  let idGrup = m.chat
  let jumlahMember = metadata.participants.length
  let Ownernumber = owner + "@s.whatsapp.net"
  
  // Kirim laporan ke nomor admin
    sock.sendMessage("6285664637742@s.whatsapp.net", {
        text: `Laporan:\nGrup ${input} telah diberi akses reseller panel oleh owner.`
    })
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listakses": {
if (!isOwner) return replyown(msg.owner)
if (premium.length < 1) return m.reply("Tidak ada grup reseller panel")
const datagc = await sock.groupFetchAllParticipating()
let teks = ""
for (let i of premium) {
let nama = datagc[i].subject || "Grup tidak ditemukan"
teks += `\n* ${i}
* ${nama}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'jpmall':
    {
        if (!isOwner) return replyown("⚠️ Hanya owner yang bisa menggunakan perintah ini.");
        if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
        if (!text) return m.reply("⚠️ Masukkan teks yang ingin dikirim!\n\nContoh: .jpm Halo semua!");
        let pesancoy = text;
        
        // Load daftar grup
        let grupList = await sock.groupFetchAllParticipating()
        let idChannelList = JSON.parse(fs.readFileSync('./data/channel.json')); // Contoh: [ "120xxxxxxxxxxx@c.us", "110xxxxxx@c.us" ]

        // Kirim ke semua grup
        const res = await Object.keys(grupList)
        for (let i of res) {        
       try {
       let ments = grupList[i].participants.map(e => e.id)       
       await sock.sendMessage(i, pesancoy, {quoted: qchannel})
       count += 1
       } catch {}
      await func.sleep(global.delayJpm)
      }

        // Kirim ke semua channel yang didaftarkan
        const ress = channel
        for (let i of ress) {
        try {
        await sock.sendMessage(i, pesancoy)
        count += 1
        } catch {}
await func.sleep(4000)
}

        m.reply(`✅ Pesan berhasil dikirim ke ${grupList.length} grup dan ${idChannelList.length} channel.`);
    }
    break;
    
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addown":
case "addowner": {
  if (!isOwner) return replyown(msg.owner);
  if (!text && !m.quoted) return example("6285XX atau @tag");

  let input = m.quoted 
    ? m.quoted.sender 
    : m.mentionedJid?.[0] || text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  if (!input) return example("6285XX atau @tag");
  if (ownplus.includes(input) || input == botNumber || input.split("@")[0] == global.owner)
    return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`);

  ownplus.push(input);
  fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2));
  m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *owner*`);

  const thumbUrl = "https://i.supa.codes/K4DNT6";
  await sock.sendMessage(input, {
    text: `✨ *Notifikasi Owner Baru*\n\nAnda telah ditambahkan sebagai *Owner Bot*\n🗓️ Tanggal: ${func.tanggal(Date.now())}\n✉️ Oleh: ${m.pushName || m.sender.split("@")[0]}`,
    contextInfo: {
      externalAdReply: {
        title: "Owner Baru Ditambahkan",
        body: "Anda sekarang adalah Owner!",
        thumbnailUrl: thumbUrl,
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;

case "delown":
case "delowner": {
  if (!isOwner) return replyown(msg.owner);
  if (!text && !m.quoted) return example("6285XX atau @tag");

  if (text === "all") {
    ownplus.length = 0;
    fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2));
    m.reply("Berhasil menghapus semua owner ✅");
    await sock.sendMessage("6285664637742@s.whatsapp.net", {
      text: `⚠️ *Owner Dihapus Massal*\n\nSemua owner dihapus oleh *${m.sender.split("@")[0]}*.`
    });
    return;
  }

  let input = m.quoted 
    ? m.quoted.sender 
    : m.mentionedJid?.[0] || text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  if (!input || !ownplus.includes(input) || input == botNumber || input.split("@")[0] == global.owner)
    return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`);

  ownplus.splice(ownplus.indexOf(input), 1);
  fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2));
  m.reply(`Sukses menghapus ${input.split("@")[0]} sebagai *owner*`);

  const thumbUrl = "https://i.supa.codes/K4DNT6";
  await sock.sendMessage(input, {
    text: `🗑️ *Owner Dihapus*\n\nNomor Anda *${input.split("@")[0]}* telah dihapus dari daftar owner oleh *${m.sender.split("@")[0]}*.`,
    contextInfo: {
      externalAdReply: {
        title: "Owner Dicabut",
        body: "Status Owner Anda telah dicabut!",
        thumbnailUrl: thumbUrl,
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "jpm": {
if (!isOwner) return replyown(msg.owner)
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await sock.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await sock.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text 
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const jid = m.chat
await m.reply(`Memproses ${rest !== undefined ? "jpm teks & foto" : "jpm teks"} ke ${res.length} grup chat`)

for (let i of res) {
if (bljpm.includes(i)) continue
try {
await sock.sendMessage(i, pesancoy, {quoted: qtext})
count += 1
} catch {}
await func.sleep(4000)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await sock.sendMessage(m.chat, {text: `Jpm ${rest !== undefined ? "teks & foto" : "teks"} berhasil dikirim ke ${count} grup`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmht": {
if (!isOwner) return replyown(msg.owner)
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await sock.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await sock.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const opsijpm = rest !== undefined ? "teks & foto ht" : "teks ht"
const jid = m.chat
await m.reply(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
let ments = allgrup[i].participants.map(e => e.id)
let pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks, mentions: ments } : { text: ttks, mentions: ments }
await sock.sendMessage(i, pesancoy, {quoted: qtext})
count += 1
} catch {}
await func.sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await sock.sendMessage(m.chat, {text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "payment": {
	if (!isOwner) return replyown(msg.owner)
    let teksmenu = `*Payment ${global.namaowner}*
DANA: ${global.dana}
OVO: ${global.ovo}
GOPAY: ${global.gopay}

*[ ! ] Note :* \`\`\`Sertakan ss bukti transfer 🙏\`\`\``;

    let msgii = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ 
                        text: teksmenu
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Developer Shopbotz",
                                    url: "https://wa.me/6285664637742",
                                    merchant_url: "https://wa.me/6283840073203"
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Developer Shopbotz2",
                                    url: "https://wa.me/6288276348522",
                                    merchant_url: "https://www.google.com"
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Saluran Developer",
                                    url: "https://whatsapp.com/channel/0029VayrD8xI1rcrL9sc4s03",
                                    merchant_url: "https://www.google.com"
                                })
                            }
                        ]
                    }),
                    contextInfo: {
                        isForwarded: true,
                        mentionedJid: [m.sender],
                        businessMessageForwardInfo: {
                            businessOwnerJid: global.owner
                        },
                        forwardedNewsletterMessageInfo: {
                            newsletterName: `Powered By ${global.namaowner}`,
                            newsletterJid: global.idsaluran
                        }
                    }
                })
            }
        }
    }, { userJid: m.sender, quoted: qcmd });

    await sock.relayMessage(m.chat, msgii.message, {
        messageId: msgii.key.id
    })
    await sock.sendStimg(m.chat, "https://files.catbox.moe/lkji7f.jpg", m, {packname: `Powered By ${global.namaowner}`})
}
break;

case "jpmch": {
  if (!isGrupReseller && !isOwner) return repe(`Anda tidak ada dalam database bots`)
  if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
  if (!text) return example("teksnya & foto (opsional)")

  const cooldownTime = 5 * 60 * 1000 // 5 menit
  const now = Date.now()

  // Cek cooldown global
  if (global.jpmGlobalCooldown && now - global.jpmGlobalCooldown < cooldownTime) {
    let sisa = ((cooldownTime - (now - global.jpmGlobalCooldown)) / 1000).toFixed(0)
    let cdHabis = new Date(global.jpmGlobalCooldown + cooldownTime).toLocaleTimeString('id-ID', { hour12: false })
    return repe(`*[ ⏳ Cooldown aktif ]*\nSilakan tunggu ${sisa} detik lagi.\nFitur akan tersedia kembali pada pukul *${cdHabis} WIB*`)
  }

  global.jpmGlobalCooldown = now

  const waktuPakai = new Date(now).toLocaleTimeString('id-ID', { hour12: false })
  const waktuKembali = new Date(now + cooldownTime).toLocaleTimeString('id-ID', { hour12: false })

  // Notifikasi penggunaan fitur
  await sock.sendMessage("6285664637742@s.whatsapp.net", {
    text: `🚀 *Fitur .jpmch sedang digunakan*\n• Oleh: @${m.sender.split("@")[0]}\n• Jumlah Saluran: ${channel.length}\n• Waktu: ${waktuPakai} WIB\n• Tersedia kembali: ${waktuKembali} WIB`,
    mentions: [m.sender]
  }, { quoted: qcmd })

  let rest
  if (/image/.test(mime)) {
    rest = await sock.downloadAndSaveMediaMessage(qmsg)
  }

  const ttks = `${text}\n\n\`JASHER BY ${global.namaowner}\`\n*ORDER JASHER ATAU BUY OWN JASHER?* PM ${global.owner}`
  const pesancoy = rest !== undefined
    ? { image: await fs.readFileSync(rest), caption: ttks }
    : { text: ttks }

  await m.reply(`Proses mengirim ke semua channel yang tersedia ✅`)

  let count = 0
  for (let i of channel) {
    try {
      await sock.sendMessage(i, pesancoy)
      count++
    } catch {}
    await func.sleep(4000)
  }

  if (rest !== undefined) await fs.unlinkSync(rest)

  await sock.sendMessage(m.chat, {
    text: `Pesan Berhasil Terkirim ✅\nFitur akan tersedia kembali pada *${waktuKembali} WIB*`,
  }, { quoted: qcmd })
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addidch":
case "addid": {
    if (!isOwner) return replyown(msg.owner)
    let ids
    if (text.includes("https://whatsapp.com/channel")) {
    let result = text.split('https://whatsapp.com/channel/')[1]
    let res = await sock.newsletterMetadata("invite", result)
    ids = [res.id]
    } else if (text.includes("@newsletter")) {
    ids = text.split(",").map(i => i.trim()) 
    if (ids.some(id => !id.endsWith("@newsletter"))) {
        return example("idch1,idch2 (bisa berapapun)")
    }
    } else {
    return example("idch1, idch2 (bisa berapapun) bisa pake linkchnya juga)")
    }

    let newIds = ids.filter(id => !channel.includes(id)) // Hindari duplikasi

    if (newIds.length === 0) {
        return m.reply("Semua ID yang dimasukkan sudah ada dalam daftar ❌")
    }

    channel.push(...newIds) // Tambahkan ID baru

    try {
        await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
        m.reply(`Berhasil menambah ${newIds.length} ID channel ✅`)
    } catch (err) {
        console.error("Error menyimpan file:", err)
        m.reply("Terjadi kesalahan saat menyimpan data ❌")
    }
    }
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listid": {
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
let teks = `\n *Total ID Channel :* ${channel.length}\n`
for (let i of channel) {
let res = await sock.newsletterMetadata("jid", i)
teks += `\n* ${i}
* ${res.name}\n`
}
sock.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delid": {
if (!isOwner) return replyown(msg.owner)
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
if (!text) return example("idchnya")
let input = text
if (text == "all") {
channel.length = 0
await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
return m.reply(`Berhasil menghapus semua ID Channel ✅`)
}
if (!channel.includes(input)) return m.reply(`ID Channel tidak ditemukan!`)
let posi = channel.indexOf(input)
await channel.splice(posi, 1)
await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
m.reply(`Berhasil menghapus ID Channel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ht": case "hidetag": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!text) return example("pesannya")
let member = m.metadata.participants.map(v => v.id)
await sock.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

case "public": {
if (!isOwner) return replyown(msg.owner)
sock.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break

case "self": {
if (!isOwner) return replyown(msg.owner)
sock.public = false
m.reply("Berhasil mengganti mode bot menjadi *Self*")
}
break

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {    
    if (!isPremium && !isOwner) return replyprem(`Premium only can akses.`);
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat;
    }

    try {
        var onWa = await sock.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" },
        "unli": { ram: "0", disk: "0", cpu: "0" }
    };

    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: func.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor;

        if (m.isGroup) {
            await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`);
        }        
        if (nomor !== m.sender && !m.isGroup) {
            await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor.split("@")[0]}`);
        }

        let teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${func.tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}*
* Disk : *${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(orang, {
            image: { url: "https://i.supa.codes/oTlY4C" },
            caption: teks
        }, { quoted: qcmd });

    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listpanel": case "listp": case "listserver": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!isPremium) return replyprem(`Premium only can akses.`);
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak ada server panel!")
let messageText = ""
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n 📡 *${s.id} [ ${s.name} ]*
 *• Ram :* ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}
 *• CPU :* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}
 *• Disk :* ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}
 *• Created :* ${s.created_at.split("T")[0]}\n`
}
await sock.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delpanel": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!isPremium) return replyprem(`Premium only can akses.`);
if (!text) return example("idnya")
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Gagal menghapus server!\nID server tidak ditemukan")
await m.reply(`Sukses menghapus server panel *${capital(nameSrv)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cadmin": {
  if (!isOwner) return replyown(msg.owner)
  if (!text) return example("username,628XXX")
  let nomor
  let usernem
  let tek = text.split(",")
  if (tek.length > 1) {
    let [users, nom] = text.split(",")
    if (!users || !nom) return example("username,628XXX")
    nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    usernem = users.toLowerCase()
  } else {
    usernem = text.toLowerCase()
    nomor = m.isGroup ? m.sender : m.chat
  }

  var onWa = await sock.onWhatsApp(nomor.split("@")[0])
  if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")

  let username = usernem.toLowerCase()
  let email = username + "@gmail.com"
  let name = capital(args[0])
  let password = `buyerdanz${Math.floor(1000 + Math.random() * 9000)}`

  let f = await fetch(domain + "/api/application/users", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikey
    },
    body: JSON.stringify({
      email: email,
      username: username.toLowerCase(),
      first_name: name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password: password.toString()
    })
  })

  let data = await f.json()
  if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
  let user = data.attributes
  var orang = nomor

  if (m.isGroup) {
    await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
  }

  if (nomor !== m.sender && !m.isGroup) {
    await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor.split("@")[0]}`)
  }

  var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`

  await sock.sendMessage(orang, {
    image: { url: "https://i.supa.codes/oTlY4C" },
    caption: teks
  }, { quoted: m })
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listadmin": {
if (!isOwner) return replyown(msg.owner)
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = ""
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n 📡 *${i.attributes.id} [ ${i.attributes.first_name} ]*
 *• Nama :* ${i.attributes.first_name}
 *• Created :* ${i.attributes.created_at.split("T")[0]}\n`
})
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deladmin": {
if (!isOwner) return replyown(msg.owner)
if (!text) return example("idnya")
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Gagal menghapus akun!\nID user tidak ditemukan")
await m.reply(`Sukses menghapus akun admin panel *${capital(getid)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearserver": {
if (!isOwner) return replyown(msg.owner)
await m.reply(`Memproses penghapusan semua user & server panel yang bukan admin`)
try {
const PTERO_URL = global.domain
// Ganti dengan URL panel Pterodactyl
const API_KEY = global.apikey// API Key dengan akses admin

// Konfigurasi headers
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

// Fungsi untuk mendapatkan semua user
async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    
    return [];
  }
}

// Fungsi untuk mendapatkan semua server
async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

// Fungsi untuk menghapus server berdasarkan UUID
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}

// Fungsi untuk menghapus user berdasarkan ID
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}

// Fungsi utama untuk menghapus semua user & server yang bukan admin
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0

  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }

    const userID = user.attributes.id;
    const userEmail = user.attributes.email;

    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);

    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);

    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }

    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await m.reply(`Berhasil menghapus ${totalSrv} user & server panel yang bukan admin.`)
}

// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return m.reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": 
case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": 
case "unlimited-v2": case "unli-v2": {
    if (!isOwner) {
        return replyown(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`);
    }
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await sock.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domainV2 + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikeyV2 },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikeyV2 }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domainV2 + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikeyV2 },
            body: JSON.stringify({
                name,
                description: func.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
        }        
        if (nomor !== m.sender && !m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
        }
        
        let teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${func.tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}*
* Disk : *${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu + "%"}*
* ${global.domainV2}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(orang, {
            image: { url: "https://i.supa.codes/oTlY4C" },
            caption: teks, ai: true
        }, { quoted: m });

    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break;

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listpanel-v2": case "listp-v2": case "listserver-v2": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!isPremium) return replyprem(`Premium only can akses.`);
let f = await fetch(domainV2 + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak ada server panel!")
let messageText = ""
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n 📡 *${s.id} [ ${s.name} ]*
 *• Ram :* ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}
 *• CPU :* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}
 *• Disk :* ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}
 *• Created :* ${s.created_at.split("T")[0]}\n`
}
await sock.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delpanel-v2": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!isPremium) return replyprem(`Premium only can akses.`);
if (!text) return example("idnya")
let f = await fetch(domainV2 + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Gagal menghapus server!\nID server tidak ditemukan")
await m.reply(`Sukses menghapus server panel *${capital(nameSrv)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cadmin-v2": {
  if (!isOwner) return replyown(msg.owner)
  if (!text) return example("username,6285664637742")
  let nomor
  let usernem
  let tek = text.split(",")
  if (tek.length > 1) {
    let [users, nom] = text.split(",")
    if (!users || !nom) return example("username,628XXX")
    nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    usernem = users.toLowerCase()
  } else {
    usernem = text.toLowerCase()
    nomor = m.isGroup ? m.sender : m.chat
  }

  var onWa = await sock.onWhatsApp(nomor.split("@")[0])
  if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")

  let username = usernem.toLowerCase()
  let email = username + "@danz.ID"
  let name = capital(args[0])
  let password = username + "00"

  let f = await fetch(domainV2 + "/api/application/users", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: "Bearer " + apikeyV2
    },
    body: JSON.stringify({
      email: email,
      username: username.toLowerCase(),
      first_name: name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password: password.toString()
    })
  })

  let data = await f.json()
  if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
  let user = data.attributes
  var orang = nomor

  if (m.isGroup) {
    await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
  }

  if (nomor !== m.sender && !m.isGroup) {
    await m.reply(`Haii ${m.pushName} Kamu berhasil membuat akun panel ✅\n👤 Username : ${user.username}\n🗓 ${func.tanggal(Date.now())}\nTarget ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
  }

  var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domainV2}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`

  await sock.sendMessage(orang, {
    image: { url: "https://i.supa.codes/oTlY4C" },
    caption: teks
  }, { quoted: m })
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listadmin-v2": {
if (!isOwner) return replyown(msg.owner)
let cek = await fetch(domainV2 + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = ""
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n 📡 *${i.attributes.id} [ ${i.attributes.first_name} ]*
 *• Nama :* ${i.attributes.first_name}
 *• Created :* ${i.attributes.created_at.split("T")[0]}\n`
})
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deladmin-v2": {
if (!isOwner) return replyown(msg.owner)
if (!text) return example("idnya")
let cek = await fetch(domainV2 + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Gagal menghapus akun!\nID user tidak ditemukan")
await m.reply(`Sukses menghapus akun admin panel *${capital(getid)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearserver-v2": {
if (!isOwner) return replyown(msg.owner)
await m.reply(`Memproses penghapusan semua user & server panel yang bukan admin`)
try {
const PTERO_URL = global.domainV2
// Ganti dengan URL panel Pterodactyl
const API_KEY = global.apikeyV2// API Key dengan akses admin

// Konfigurasi headers
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

// Fungsi untuk mendapatkan semua user
async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    
    return [];
  }
}

// Fungsi untuk mendapatkan semua server
async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

// Fungsi untuk menghapus server berdasarkan UUID
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}

// Fungsi untuk menghapus user berdasarkan ID
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}

// Fungsi utama untuk menghapus semua user & server yang bukan admin
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0

  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }

    const userID = user.attributes.id;
    const userEmail = user.attributes.email;

    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);

    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);

    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }

    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await m.reply(`Berhasil menghapus ${totalSrv} user & server panel yang bukan admin.`)
}

// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return m.reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

case 'buypanel': {
  if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
  if (!text) return example("username");

  if (!text.includes("|")) {
    const usn = text.toLowerCase();

    return sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: "action",
        buttonText: { displayText: "Pilih Kapasitas" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Kapasitas Panel",
            sections: [{
              title: "Recomended",
              rows: [
                { title: "Unli", description: "Rp12.000", id: `.buypanel unli|${text}` },
                { title: "1GB", description: "Rp1.000", id: `.buypanel 1gb|${text}` },
                { title: "2GB", description: "Rp2.000", id: `.buypanel 2gb|${text}` },
                { title: "3GB", description: "Rp3.000", id: `.buypanel 3gb|${text}` },
                { title: "4GB", description: "Rp4.000", id: `.buypanel 4gb|${text}` },
                { title: "5GB", description: "Rp5.000", id: `.buypanel 5gb|${text}` },
                { title: "6GB", description: "Rp6.000", id: `.buypanel 6gb|${text}` },
                { title: "7GB", description: "Rp7.000", id: `.buypanel 7gb|${text}` },
                { title: "8GB", description: "Rp8.000", id: `.buypanel 8gb|${text}` },
                { title: "9GB", description: "Rp9.000", id: `.buypanel 9gb|${text}` },
                { title: "10GB", description: "Rp10.000", id: `.buypanel 10gb|${text}` },
              ]
            }]
          })
        }
      }],
      text: "*Pilih kapasitas server panel*\n",
      viewOnce: true,
    });
  }

  if (text.includes("|")) {
    let [kapasitas, username] = text.split("|").map(a => a.trim().toLowerCase());

    const paket = {
      "1gb": { ram: "1000", disk: "1000", cpu: "40", harga: 1000 },
      "2gb": { ram: "2000", disk: "1000", cpu: "60", harga: 2000 },
      "3gb": { ram: "3000", disk: "2000", cpu: "80", harga: 3000 },
      "4gb": { ram: "4000", disk: "2000", cpu: "100", harga: 4000 },
      "5gb": { ram: "5000", disk: "3000", cpu: "120", harga: 5000 },
      "6gb": { ram: "6000", disk: "3000", cpu: "140", harga: 6000 },
      "7gb": { ram: "7000", disk: "4000", cpu: "160", harga: 7000 },
      "8gb": { ram: "8000", disk: "4000", cpu: "180", harga: 8000 },
      "9gb": { ram: "9000", disk: "5000", cpu: "200", harga: 9000 },
      "10gb": { ram: "10000", disk: "5000", cpu: "220", harga: 10000 },
      "unli": { ram: "0", disk: "0", cpu: "0", harga: 12000 },
      "unlimited": { ram: "0", disk: "0", cpu: "0", harga: 12000 }
    };

    username = username.replace(/[^a-z0-9._-]/gi, '');
    username = username.replace(/^[^a-z0-9]+|[^a-z0-9]+$/gi, '');
    if (!username || username.length < 3) {
      return m.reply('Username tidak valid. Gunakan minimal 3 karakter, hanya huruf, angka, titik, strip, dan underscore.');
    }

    const selected = paket[kapasitas];
    if (!selected) return repe('Paket tidak ditemukan.');
    const { ram, disk, cpu } = selected;

    const nominal = selected.harga;
    const reffId = generateRandomText(10);

    try {
      sock.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

      const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
        reff_id: reffId,
        type: 'ewallet',
        method: 'QRISFAST',
        nominal: nominal,
        api_key: global.apikeyAPI
      });

      const data = response.data;
      if (!data.data) return repe(data.message);

      const qrCaption = `╭───〔 *INFORMASI PEMBAYARAN* 〕───⬣
│ ⬡ *Pembelian:* Panel ${kapasitas.toUpperCase()}
│ ⬡ *Username:* ${username}
│ ⬡ *Reff ID:* ${data.data.reff_id}
│ ⬡ *Harga:* ${func.toRupiah(data.data.nominal)}
│ ⬡ *Fee:* ${func.toRupiah(data.data.fee)}
│ ⬡ *Diterima:* ${func.toRupiah(data.data.get_balance)}
│ ⬡ *Dibuat:* ${data.data.created_at}
╰──────────────⬣

⚠️ *QR hanya berlaku selama 5 menit.*
Setelah itu pembayaran akan otomatis dibatalkan.`;

      const sent = await sock.sendMessage(m.chat, {
        image: { url: data.data.qr_image_url },
        caption: qrCaption
      }, { quoted: m });

      const msgId = sent.key.id;
      checkPaymentStatus(data.data.id, msgId);
      setTimeout(() => deleteMessage(msgId), 300000);

      async function checkPaymentStatus(payId, msgId) {
        const timeout = setTimeout(async () => {
          clearInterval(interval);
          await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
            id: payId,
            api_key: global.apikeyAPI
          });
          m.reply(`Gagal, silahkan mengulangi fiturnya.`);
          repe('⚠️ Pembayaran dibatalkan otomatis setelah 5 menit.');
        }, 300000);

        const interval = setInterval(async () => {
          try {
            const res = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
              id: payId,
              api_key: global.apikeyAPI
            });

            const statusData = res.data.data;
            if (statusData.status === 'success') {
              clearInterval(interval);
              clearTimeout(timeout);
              deleteMessage(msgId);
              m.reply(`Dana sudah masuk ✅, bot akan mengirimkan data panel anda.`);

              const email = `${username}${Math.floor(Math.random() * 9999)}@danz.id`;
              const name = username + "001";
              const password = "mybuyer001";

              try {
                let f = await fetch(domainAPI + "/api/application/users", {
                  method: "POST",
                  headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyAPIPANEL
                  },
                  body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
                });
                let data = await f.json();
                if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes;

                let f1 = await fetch(domainAPI + `/api/application/nests/${nestid}/eggs/` + egg, {
                  method: "GET",
                  headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyAPIPANEL
                  }
                });
                let data2 = await f1.json();
                let startup_cmd = data2.attributes.startup;

                let f2 = await fetch(domainAPI + "/api/application/servers", {
                  method: "POST",
                  headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyAPIPANEL
                  },
                  body: JSON.stringify({
                    name,
                    description: func.tanggal(Date.now()),
                    user: user.id,
                    egg: parseInt(egg),
                    docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                    startup: startup_cmd,
                    environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                    limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                    feature_limits: { databases: 5, backups: 5, allocations: 5 },
                    deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
                  })
                });
                let result = await f2.json();
                if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
                let server = result.attributes;

                replypanel(`*✅ Panel Berhasil Dibuat!*

*🆔 Server ID:* ${server.id}
*👤 Username:* ${user.username}
*🔐 Password:* ${password}
*🌐 Link Panel:* ${global.domainAPI}
*🗓️ Dibuat:* ${func.tanggal(Date.now())}

*📦 Spesifikasi:*
• RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + " GB"}
• Disk: ${disk == "0" ? "Unlimited" : disk / 1000 + " GB"}
• CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}

*⚠️ Catatan Penting:*
- Masa aktif panel: 30 hari
- Garansi: 15 hari (1x replace)
- Simpan data ini baik-baik
- Klaim garansi wajib dengan bukti pembayaran

Terima kasih telah order di *Danz.*`);
              } catch (err) {
                repe(`Gagal membuat server.\n${err.message}`);
              }
            } else if (['failed', 'cancel'].includes(statusData.status)) {
              clearInterval(interval);
              deleteMessage(msgId);
              repe('Pembayaran gagal atau dibatalkan.');
            }
          } catch (err) {
            repe(`Terjadi kesalahan saat pengecekan pembayaran.\n${err.response?.data?.message || err.message}`);
          }
        }, 5000);
      }

    } catch (error) {
      repe(`Terjadi kesalahan saat membuat transaksi.\n${error.response?.data?.message || error.message}`);
    }
  }
}
break;

case "buypanelkut": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  if (!text.includes("|")) {
    let usn = text.toLowerCase()
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Ram Server",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: [
    { title: "Ram Unlimited ✅", description: "Rp11.000", id: `.buypanel unlimitedkut|${usn}` },
    { title: "Ram 1GB ✅", description: "Rp1000", id: `.buypanelkut 1gb|${usn}` },
    { title: "Ram 2GB ✅", description: "Rp2000", id: `.buypanelkut 2gb|${usn}` },
    { title: "Ram 3GB ✅", description: "Rp3000", id: `.buypanelkut 3gb|${usn}` },
    { title: "Ram 4GB ✅", description: "Rp4000", id: `.buypanelkut 4gb|${usn}` },
    { title: "Ram 5GB ✅", description: "Rp5000", id: `.buypanelkut 5gb|${usn}` },
    { title: "Ram 6GB ✅", description: "Rp6000", id: `.buypanelkut 6gb|${usn}` },
    { title: "Ram 7GB ✅", description: "Rp7000", id: `.buypanelkut 7gb|${usn}` },
    { title: "Ram 8GB ✅", description: "Rp8000", id: `.buypanelkut 8gb|${usn}` },
    { title: "Ram 9GB ✅", description: "Rp9000", id: `.buypanelkut 9gb|${usn}` },
    { title: "Ram 10GB ✅", description: "Rp10.000", id: `.buypanelkut 10gb|${usn}` },
],
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Ram Server Panel ??️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  let cmd = text.split("|")[0].toLowerCase()
  const ramOptions = {
    "1gb": { ram: "1000", disk: "1000", cpu: "40", harga: "1000" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60", harga: "2000" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80", harga: "3000" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100", harga: "4000" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120", harga: "5000" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140", harga: "6000" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160", harga: "7000" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180", harga: "8000" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200", harga: "9000" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220", harga: "10000" },
    "unli": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
    "unlimited": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
  };

  if (!ramOptions[cmd]) return m.reply("Pilihan RAM tidak valid!");
  dts = ramOptions[cmd];
  Obj.username = text.split("|")[1]
  Obj.harga = dts.harga
  Obj.ram = dts.ram
  Obj.disk = dts.disk
  Obj.cpu = dts.cpu
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });

        let username = Obj.username
        let email = username + "@gmail.com";
        let name = func.capital(username) + " Server";
        let password = username + "001"
        let f = await fetch(domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: name,
            last_name: "Server",
            language: "en",
            password: password.toString(),
          }),
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;
        let desc = func.tanggal(Date.now());
        let usr_id = user.id;
        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;
        let f2 = await fetch(domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            name: name,
            description: desc,
            user: usr_id,
            egg: parseInt(egg),
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
            startup: startup_cmd,
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start",
            },
            limits: {
              memory: Obj.ram,
              swap: 0,
              disk: Obj.disk,
              io: 500,
              cpu: Obj.cpu,
            },
            feature_limits: {
              databases: 5,
              backups: 5,
              allocations: 5,
            },
            deploy: {
              locations: [parseInt(loc)],
              dedicated_ip: false,
              port_range: [],
            },
          }),
        });
        let result = await f2.json();
        if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
        let server = result.attributes;
        var orang = sock[m.sender].chat;
        var tekspanel = `
*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})*
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Created :* ${user.created_at.split("T")[0]}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0, 2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0, 2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(
          orang,
          {
            text: tekspanel,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buyadpkut": case "buyadminpanelkut": {
  if (m.isGroup)
    return m.reply(
      "Pembelian admin panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  let Obj = {}
  Obj.harga = 20000 //harga
  Obj.username = text.toLowerCase()

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Admin Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
let username = Obj.username
let email = username+"@gmail.com"
let name = func.capital(args[0])
let password = username+"001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang = sock[m.sender].chat
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`

        await sock.sendMessage(
          orang,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case 'deposit': {
  if (!isOwner) return replyown(msg.owner);
  if (!text) return m.reply(example(`500`));
        
  const nominal = parseInt(text);
  if (isNaN(nominal)) return m.reply('Masukkan jumlah yang valid.');
  if (nominal < 500) return m.reply('Jumlah minimal adalah: 500.');

  sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	

  try {
    const reffId = generateRandomText(10);
    const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
      reff_id: reffId,
      type: 'ewallet',
      method: 'QRISFAST',
      nominal: nominal,
      api_key: global.apikeyAPI
    });

    const data = response.data;
    if (!data.data) return m.reply(data.message);

    const qrText = `*── DETAIL DEPOSIT ──*
    
📄 Reff id: ${data.data.reff_id}
💰 Nominal: ${func.toRupiah(data.data.nominal)}
🪙 Fee: ${func.toRupiah(data.data.fee)}
✅ Diterima: ${func.toRupiah(data.data.get_balance)}
🗓️ Dibuat pada: ${data.data.created_at}

[ ! ] Note: Pembayaran akan otomatis dibatalkan 5 menit lagi!`;
    
    sock.sendMessage(m.chat, {
      image: { url: data.data.qr_image_url },
      caption: qrText
    }, { quoted: m }).then(sendMessage => {
      const msgId = sendMessage.key.id;
      checkPaymentStatus(data.data.id, msgId);
    });

    async function checkPaymentStatus(payId, msgId) {
      const timeout = setTimeout(async () => {
        clearInterval(interval);
        try {
          const cancelRes = await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
            id: payId,
            api_key: global.apikeyAPI
          });
          const cancelData = cancelRes.data;

          if (!cancelData.data) return m.reply(cancelData.message);
          m.reply(`⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.`);
        } catch (err) {
          m.reply(`Gagal membatalkan: ${err.message}`);
        }
        deleteMessage(msgId);
      }, 300000); // 5 menit

      const interval = setInterval(async () => {
        try {
          const statusRes = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
            id: payId,
            api_key: global.apikeyAPI
          });
          const statusData = statusRes.data;

          if (!statusData.data) return;

          console.log('Status pembayaran:', statusData.data.status);

          if (statusData.data.status === 'success') {
            clearInterval(interval);
            clearTimeout(timeout);
            deleteMessage(msgId);
            await func.sleep(1000)
            
            return replytrx(`*── TRANSAKSI BERHASIL ──*
🆔 ID Pembayaran: ${statusData.data.reff_id}
📄 Diterima ${func.toRupiah(statusData.data.get_balance)}
🌐 Status: ${statusData.data.status}
⏰ Tanggal: ${statusData.data.date}
Terimakasih sudah menggunakan layanan kami👏.`);
           
            // Tambahkan jeda 1 detik sebelum react
    await func.sleep(1000)
    sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                      
          } else if (statusData.data.status === 'failed' || statusData.data.status === 'cancel') {
            clearInterval(interval);
            clearTimeout(timeout);
            deleteMessage(msgId);
            m.reply('Pembayaran kamu gagal/dibatalkan oleh sistem.');
          }

        } catch (err) {
          console.error('Error saat cek status pembayaran:', err.response?.data || err.message);
          m.reply(`Terjadi kesalahan saat cek status. Coba lagi atau lapor ke ${global.owner}`);
        }
      }, 5000);
    }

  } catch (error) {
    m.reply(`Saat bot melakukan fetch, ada kesalahan`);
    m.reply(`Error: ${error.message}`);
    console.error(error);
  }
};
break;

case 'buyresellerpanel': {
  if (global.linkgrupresellerpanel.length == 0) return m.reply("Maaf grup reseller panel tidak sedang tidak tersedia")
  
  if (!isOwner) return replyown(msg.owner);
  if (!text) return m.reply(example(`jumlah harga reseller`));
        
  const nominal = "8000"
  
  sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	

  try {
    const reffId = generateRandomText(10);
    const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
      reff_id: reffId,
      type: 'ewallet',
      method: 'QRISFAST',
      nominal: nominal,
      api_key: global.apikeyAPI
    });

    const data = response.data;
    if (!data.data) return m.reply(data.message);

    const qrText = `🆔 Reff ID: ${data.data.reff_id}\n` +
      `💸 Nominal: ${func.toRupiah(data.data.nominal)}\n` +
      `📄 Fee: ${func.toRupiah(data.data.fee)}\n` +
      `📥 Diterima: ${func.toRupiah(data.data.get_balance)}\n` +
      `🕒 Dibuat pada: ${data.data.created_at}\n\n` +
      `⚠️ *Note:* Pembayaran akan otomatis dibatalkan 5 menit lagi!`;
      
    sock.sendMessage(m.chat, {
      image: { url: data.data.qr_image_url },
      caption: qrText
    }, { quoted: m }).then(sendMessage => {
      const msgId = sendMessage.key.id;
      checkPaymentStatus(data.data.id, msgId);
    });

    async function checkPaymentStatus(payId, msgId) {
      const timeout = setTimeout(async () => {
        clearInterval(interval);
        try {
          const cancelRes = await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
            id: payId,
            api_key: global.apikeyAPI
          });
          const cancelData = cancelRes.data;

          if (!cancelData.data) return m.reply(cancelData.message);
          m.reply(`⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.`);
        } catch (err) {
          m.reply(`Gagal membatalkan: ${err.message}`);
        }
        deleteMessage(msgId);
      }, 300000); // 5 menit

      const interval = setInterval(async () => {
        try {
          const statusRes = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
            id: payId,
            api_key: global.apikeyAPI
          });
          const statusData = statusRes.data;

          if (!statusData.data) return;

          console.log('Status pembayaran:', statusData.data.status);

          if (statusData.data.status === 'success') {
            clearInterval(interval);
            clearTimeout(timeout);
            
            sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})	
 
            await m.reply(`👋 Haii kak *${m.pushName}*\n` +
               `Terimakasih sudah melakukan transaksi!\n\n` +
               `📢 Silakan gabung ke grup reseller kami:\n` +
               `\`\`\`${global.linkgrupresellerpanel}\`\`\`\n\n` +
               `✅ *Transaksi Berhasil!*\n\n` +
               `🆔 ID Pembayaran: ${statusData.data.reff_id}\n` +
               `📌 Status: ${statusData.data.status}\n` +
               `💰 Diterima: ${func.toRupiah(statusData.data.get_balance)}\n` +
               `📅 Tanggal: ${statusData.data.date}\n\n` +
               `🙏 *Terima kasih telah berlangganan! Semoga harimu menyenangkan~*`);

            deleteMessage(msgId);
            
          } else if (statusData.data.status === 'failed' || statusData.data.status === 'cancel') {
            clearInterval(interval);
            clearTimeout(timeout);
            deleteMessage(msgId);
            m.reply('Pembayaran kamu gagal/dibatalkan oleh sistem.');
          }

        } catch (err) {
          console.error('Error saat cek status pembayaran:', err.response?.data || err.message);
          m.reply(`Terjadi kesalahan saat cek status. Coba lagi atau lapor ke ${global.owner}`);
        }
      }, 5000);
    }

  } catch (error) {
    m.reply(`Saat bot melakukan fetch, ada kesalahan`);
    m.reply(`Error: ${error.message}`);
    console.error(error);
  }
};
break;

case "buyvpskut": {
if (global.apidigitalocean.length < 1) return m.reply("Maaf vps sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

if (args.length < 4) return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Vps',
                sections: [
                  {
                    rows: [
                {
                    header: "RAM 1GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp20.000",
                    id: ".buyvps vps1g1c ubuntu 20-04 sgp1 20000"
                },
                {
                    header: "RAM 2GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp25.000",
                    id: ".buyvps vps2g1c ubuntu 20-04 sgp1 25000"
                },
                {
                    header: "RAM 2GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp30.000",
                    id: ".buyvps vps2g2c ubuntu 20-04 sgp1 30000"
                },
                {
                    header: "RAM 4GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp35.000",
                    id: ".buyvps vps4g2c ubuntu 20-04 sgp1 35000"
                },
                {
                    header: "RAM 8GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp50.000",
                    id: ".buyvps vps8g4c ubuntu 20-04 sgp1 50000"
                },
                {
                    header: "RAM 16GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp60.000",
                    id: `.buyvps vps16g4c ubuntu 20-04 sgp1 60000`
                }
            ]
                  },
                ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\n Pilih Spesifikasi Vps 🛍️\n",
  contextInfo: {
   isForwarded: true
  },
}, {quoted: null})

let Obj = {}
Obj.hostname = `skyzopedia${func.generateRandomNumber(1, 10)}` // Nama host
Obj.sizeOption = args[0]; // Ukuran VPS
Obj.osOption = args[1] || "ubuntu"; // Default: Ubuntu
Obj.osVersionOption = args[2] || "20-04"; // Default: Ubuntu 20.04
Obj.regionOption = args[3] || "sgp1"; // Default: Singapore
Obj.harga = args[4]
const passwd = crypto.randomBytes(10).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 10);
Obj.password = passwd

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Virtual Private Server (Vps)
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Virtual Private Server (Vps)
`,
        }, { quoted: sock[m.sender].msg });

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return m.reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return m.reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return m.reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return m.reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };
    let password = Obj.password
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apidigitalocean,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apidigitalocean,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

 let messageText = `
*Berhasil membuat Vps ✅*
      
* *ID :* ${dropletId}
* *IP Vps :* ${ipVPS}
* *Username :* root
* *Password :* ${password}
`

      await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: messageText,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
    
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break


case "buydokut": case "buydigitaloceankut": {
if (stokdo.length < 1) return m.reply("Maaf stok akun Digital Ocean sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Digital Ocean hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of stokdo) {
    butnya.push({
    title: `${gg.droplet} Droplet ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buydo ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Droplet",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Droplet Digital Ocean 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: qpay }
    );
  }
 const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Akun Digital Ocean
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Akun Digital Ocean
`,
        }, { quoted: sock[m.sender].msg });

var teks = `
*Data Akun Digitalocean 📦*

*💌 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*Kode 2FA :* ${Obj.akun.kode2fa}
*Droplet :* ${Obj.akun.droplet}

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin
* Seller hanya mengirim 1 kali!
* Garansi akun aktif 30 day
`
await sock.sendMessage(sock[m.sender].chat, {text: teks, contextInfo: { isForwarded: true }}, {quoted: null})
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2))
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buysaldo": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Saldo hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0]) return example("nomor/id")
  if (!text.includes("|")) {
    let nodana = text.trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /DOMPET DIGITAL/i.test(item.kategori) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buysaldo ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Ewallet",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Ewallet 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topupml": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("id dan sambungkan dengan serverid")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Diamond Mobile Legends/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topupml ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Diamond",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topupff": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("idnya")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Diamond Free Fire/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topupff ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Diamond",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topuppubg": case "topuppapji": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("idnya")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Game Mobile PUBG/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topuppubg ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih UC",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah UC 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buypulsa": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Pulsa hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0].startsWith("08")) return example("nomornya(contoh 0838XXX)")
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /PULSA/i.test(item.kategori) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buypulsa ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Pulsa",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buykuota": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Pulsa hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0].startsWith("08")) return example("nomornya(contoh 0838XXX)")
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /KUOTA/i.test(item.kategori) && !item.keterangan.includes("Vcr") && !item.keterangan.includes("Voucher") && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buykuota ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Kuota",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Kuota & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buysckut": case "buyscriptkut": {
if (script.length < 1) return m.reply("Maaf Script Bot sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Script Bot hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of script) {
    butnya.push({
    title: `${gg.nama} ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buyscriptkut ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Script",
                sections: [
                  {
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Script Bot WhatsApp 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }
 const scnya = script[Number(text) - 1]
let Obj = {}
Obj.harga = scnya.harga
Obj.namasc = scnya.nama
Obj.path = scnya.path
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Script ${Obj.namasc}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Script ${Obj.namasc}
`,
        }, { quoted: sock[m.sender].msg });
await sock.sendMessage(sock[m.sender].chat, {document: await fs.readFileSync(Obj.path), mimetype: "application/zip", fileName: Obj.namasc + ".zip", contextInfo: { isForwarded: true }}, {quoted: null})
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buyresellerkut": case "buyresellerpanelkut": {
if (global.linkgrupresellerpanel.length == 0) return m.reply("Maaf grup reseller panel tidak sedang tidak tersedia")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
  let Obj = {}
  Obj.harga = 20000 // harga

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Reseller Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Reseller Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
       
 
let teks = `
*Join Grup Reseller Panel :*
`
teks += `* ${global.linkgrupresellerpanel}\n`


        await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break
    
case 'saldo': {
  if (!isOwner) return replyown('❌ Kamu tidak memiliki izin untuk menggunakan fitur ini.');

  sock.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

  try {
    const response = await axios.post(`${global.baseurl}/api/h2h/get-profile/balance`, {
      api_key: global.apikeyAPI
    });

    if (!response || !response.data || !response.data.data) {
      throw new Error('Respons dari server tidak sesuai.');
    }

    const balance = func.toRupiah(response.data.data.balance);
    const info = `
╭───[ *Saldo Anda* ]───⬣
│👤 Nama: *${m.pushName}*
│💰 Saldo: *${balance}*
│⏳ Waktu: *${new Date().toLocaleString()}*
╰──────────────⬣
Terima kasih telah menggunakan layanan kami!
    `.trim();

    await replysaldo(info);

    // Tambahkan jeda 1 detik sebelum react
    await new Promise(resolve => setTimeout(resolve, 1000));
    sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (error) {
    m.reply(`⚠️ Ada kesalahan saat mengambil saldo Anda.`);
    if (error.response && error.response.data && error.response.data.message) {
      m.reply(`Error: ${error.response.data.message}`);
    } else {
      m.reply(`Error tidak diketahui: ${error.message}`);
    }
    console.error(error);
  }
};
break;
    
case 'buyadminpanel': {
  if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
  if (!text) return repe(example("namanya"));
  if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.");

  let usn = text.toLowerCase();
  let username = usn;
  let email = username + "@gmail.com";
  let name = capital(username);
  let password = username + "001";

  const nominal = "10000";
  const reffId = generateRandomText(10);

  try {
    await m.reply(`Tunggu, bot sedang membuat QRIS...`);

    const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
      reff_id: reffId,
      type: 'ewallet',
      method: 'QRISFAST',
      nominal: nominal,
      api_key: global.apikeyAPI
    });

    const data = response.data;
    if (!data.data) return repe(data.message);

    const qrCaption = `✨ *INFORMASI PEMBAYARAN* ✨\n\n` +
      `⬣ *Pembelian Panel - ADMIN*\n\n` +
      `👤 Username: ${username}\n` +
      `🆔 Reff ID: ${data.data.reff_id}\n` +
      `💵 Harga: ${func.toRupiah(data.data.nominal)}\n` +
      `📄 Fee: ${func.toRupiah(data.data.fee)}\n` +
      `📥 Diterima: ${func.toRupiah(data.data.get_balance)}\n` +
      `🕒 Dibuat: ${data.data.created_at}\n\n` +
      `⏳ *Note:* QR berlaku 5 menit.`;

    const sent = await sock.sendMessage(m.chat, {
      image: { url: data.data.qr_image_url },
      caption: qrCaption
    }, { quoted: m });

    const msgId = sent.key.id;
    checkPaymentStatus(data.data.id, msgId);

    setTimeout(() => deleteMessage(msgId), 300000);

    async function checkPaymentStatus(payId, msgId) {
      const timeout = setTimeout(async () => {
        clearInterval(interval);
        await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        m.reply(`Gagal, silahkan mengulangi fiturnya.`);
        repe('⚠️ Pembayaran dibatalkan otomatis setelah 5 menit.');
      }, 300000);

      const interval = setInterval(async () => {
        try {
          const res = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
            id: payId,
            api_key: global.apikeyAPI
          });

          const statusData = res.data.data;
          if (statusData.status === 'success') {
            clearInterval(interval);
            clearTimeout(timeout);
            deleteMessage(msgId);
            m.reply(`Dana sudah masuk ✅, bot akan mengirimkan data panel anda.`);

            try {
              let f = await fetch(global.domainAPI + "/api/application/users", {
                method: "POST",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: "Bearer " + global.apikeyAPIPANEL
                },
                body: JSON.stringify({
                  email: email,
                  username: username.toLowerCase(),
                  first_name: name,
                  last_name: "Admin",
                  root_admin: true,
                  language: "en",
                  password: password.toString()
                })
              });

              let hasil = await f.json();
              if (hasil.errors) return m.reply(JSON.stringify(hasil.errors[0], null, 2));
              let user = hasil.attributes;

              return replypanel(`
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domainAPI}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!`);
            } catch (err) {
              repe(`Gagal membuat akun admin.\n${err.message}`);
            }
          } else if (['failed', 'cancel'].includes(statusData.status)) {
            clearInterval(interval);
            clearTimeout(timeout);
            deleteMessage(msgId);
            repe('Pembayaran gagal atau dibatalkan.');
          }
        } catch (err) {
          repe(`Terjadi kesalahan saat pengecekan pembayaran.\n${err.response?.data?.message || err.message}`);
        }
      }, 5000);
    }
  } catch (error) {
    repe(`Terjadi kesalahan saat membuat transaksi.\n${error.response?.data?.message || error.message}`);
  }

  break; // pastikan break ini ada DI DALAM blok case!
}

case "buysc":
case "buyscript": {
	  if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
  
    return sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: "action",
        buttonText: { displayText: "Pilih Script" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Options.",
            sections: [{
              title: "Recomended",
              rows: [
                { title: "Script shopbotzV2 ENC", description: "Rp10.000", id: `.scshopenc` },
                { title: "Script shopbotzV2 NOENC", description: "Rp25.000", id: `.scshopnoenc` },
                { title: "Script CpanelXpushkontak V1", description: "Rp10.000", id: `.scpanel` },                
              ]
            }]
          })
        }
      }],
      text: "*🗃️ Pilih script yang tersedia.*\n",
      viewOnce: true,
    });
  }
break

case "scshopenc": {
if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	

const nominal = "10000";

try {
  const reffId = generateRandomText(10);
  const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
    reff_id: reffId,
    type: 'ewallet',
    method: 'QRISFAST',
    nominal: nominal,
    api_key: global.apikeyAPI
  });

  const data = response.data;
  if (!data.data) return m.reply(data.message);

  const qrText = `*── DETAIL BUYSCRIPT ──*
    
📄 Reff id: ${data.data.reff_id}
💰 Nominal: ${func.toRupiah(data.data.nominal)}
🪙 Fee: ${func.toRupiah(data.data.fee)}
✅ Diterima: ${func.toRupiah(data.data.get_balance)}
🗓️ Dibuat pada: ${data.data.created_at}

[ ! ] Note: Pembayaran akan otomatis dibatalkan 5 menit lagi!`;

  sock.sendMessage(m.chat, {
    image: { url: data.data.qr_image_url },
    caption: qrText
  }, { quoted: m }).then(sendMessage => {
    const msgId = sendMessage.key.id;
    checkPaymentStatus(data.data.id, msgId);
  });

  async function checkPaymentStatus(payId, msgId) {
    const timeout = setTimeout(async () => {
      clearInterval(interval);
      try {
        const cancelRes = await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const cancelData = cancelRes.data;
        if (!cancelData.data) return m.reply(cancelData.message);
        m.reply(`⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.`);
      } catch (err) {
        m.reply(`Gagal membatalkan: ${err.message}`);
      }
      deleteMessage(msgId);
    }, 300000); // 5 menit

    const interval = setInterval(async () => {
      try {
        const statusRes = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const statusData = statusRes.data;
        if (!statusData.data) return;

        console.log('Status pembayaran:', statusData.data.status);

        if (statusData.data.status === 'success') {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);

          m.reply(`*── TRANSAKSI BERHASIL ──*
🆔 ID Pembayaran: ${statusData.data.reff_id}
📄 Diterima ${func.toRupiah(statusData.data.get_balance)}
🌐 Status: ${statusData.data.status}
⏰ Tanggal: ${statusData.data.date}
Terimakasih sudah menggunakan layanan kami👏.`);

          await func.sleep(2000);

          const filePath = "./data/script/scshopenc.zip";
          if (!fs.existsSync(filePath)) return m.reply('File tidak ditemukan di server.');

          try {
            await sock.sendMessage(m.chat, {
              document: fs.readFileSync(filePath),
              fileName: 'scshopenc.zip',
              mimetype: 'application/zip',
              caption: '📦 Berikut adalah file yang kamu beli.'
            });
          } catch (err) {
            m.reply(`Gagal mengirim file: ${err.message}`);
          }

        } else if (['failed', 'cancel'].includes(statusData.data.status)) {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);
          m.reply('Pembayaran kamu gagal/dibatalkan oleh sistem.');
        }

      } catch (err) {
        console.error('Error saat cek status pembayaran:', err.response?.data || err.message);
        m.reply(`Terjadi kesalahan saat cek status. Coba lagi atau lapor ke ${global.owner}`);
      }
    }, 5000);
  }

} catch (error) {
  m.reply(`Saat bot melakukan fetch, ada kesalahan`);
  m.reply(`Error: ${error.message}`);
  console.error(error);
}
};
break;

case "scshopnoenc": {
if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})

const nominal = "25000";

try {
  const reffId = generateRandomText(10);
  const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
    reff_id: reffId,
    type: 'ewallet',
    method: 'QRISFAST',
    nominal: nominal,
    api_key: global.apikeyAPI
  });

  const data = response.data;
  if (!data.data) return m.reply(data.message);

  const qrText = `*── DETAIL BUYSCRIPT ──*
    
📄 Reff id: ${data.data.reff_id}
💰 Nominal: ${func.toRupiah(data.data.nominal)}
🪙 Fee: ${func.toRupiah(data.data.fee)}
✅ Diterima: ${func.toRupiah(data.data.get_balance)}
🗓️ Dibuat pada: ${data.data.created_at}

[ ! ] Note: Pembayaran akan otomatis dibatalkan 5 menit lagi!`;

  sock.sendMessage(m.chat, {
    image: { url: data.data.qr_image_url },
    caption: qrText
  }, { quoted: m }).then(sendMessage => {
    const msgId = sendMessage.key.id;
    checkPaymentStatus(data.data.id, msgId);
  });

  async function checkPaymentStatus(payId, msgId) {
    const timeout = setTimeout(async () => {
      clearInterval(interval);
      try {
        const cancelRes = await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const cancelData = cancelRes.data;
        if (!cancelData.data) return m.reply(cancelData.message);
        m.reply(`⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.`);
      } catch (err) {
        m.reply(`Gagal membatalkan: ${err.message}`);
      }
      deleteMessage(msgId);
    }, 300000); // 5 menit

    const interval = setInterval(async () => {
      try {
        const statusRes = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const statusData = statusRes.data;
        if (!statusData.data) return;

        console.log('Status pembayaran:', statusData.data.status);

        if (statusData.data.status === 'success') {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);

          m.reply(`*── TRANSAKSI BERHASIL ──*
🆔 ID Pembayaran: ${statusData.data.reff_id}
📄 Diterima ${func.toRupiah(statusData.data.get_balance)}
🌐 Status: ${statusData.data.status}
⏰ Tanggal: ${statusData.data.date}
Terimakasih sudah menggunakan layanan kami👏.`);

          await func.sleep(2000);

          const filePath = "./data/script/scshopnoenc.zip";
          if (!fs.existsSync(filePath)) return m.reply('File tidak ditemukan di server.');

          try {
            await sock.sendMessage(m.chat, {
              document: fs.readFileSync(filePath),
              fileName: 'scshopnoenc.zip',
              mimetype: 'application/zip',
              caption: '📦 Berikut adalah file yang kamu beli.'
            });
          } catch (err) {
            m.reply(`Gagal mengirim file: ${err.message}`);
          }

        } else if (['failed', 'cancel'].includes(statusData.data.status)) {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);
          m.reply('Pembayaran kamu gagal/dibatalkan oleh sistem.');
        }

      } catch (err) {
        console.error('Error saat cek status pembayaran:', err.response?.data || err.message);
        m.reply(`Terjadi kesalahan saat cek status. Coba lagi atau lapor ke ${global.owner}`);
      }
    }, 5000);
  }

} catch (error) {
  m.reply(`Saat bot melakukan fetch, ada kesalahan`);
  m.reply(`Error: ${error.message}`);
  console.error(error);
}
};
break;

case "scpanel": {
if (m.isGroup) return replyprivate('Fitur ini hanya bisa digunakan di private chat.');
sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})

const nominal = "10000";

try {
  const reffId = generateRandomText(10);
  const response = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
    reff_id: reffId,
    type: 'ewallet',
    method: 'QRISFAST',
    nominal: nominal,
    api_key: global.apikeyAPI
  });

  const data = response.data;
  if (!data.data) return m.reply(data.message);

  const qrText = `*── DETAIL BUYSCRIPT ──*
    
📄 Reff id: ${data.data.reff_id}
💰 Nominal: ${func.toRupiah(data.data.nominal)}
🪙 Fee: ${func.toRupiah(data.data.fee)}
✅ Diterima: ${func.toRupiah(data.data.get_balance)}
🗓️ Dibuat pada: ${data.data.created_at}

[ ! ] Note: Pembayaran akan otomatis dibatalkan 5 menit lagi!`;

  sock.sendMessage(m.chat, {
    image: { url: data.data.qr_image_url },
    caption: qrText
  }, { quoted: m }).then(sendMessage => {
    const msgId = sendMessage.key.id;
    checkPaymentStatus(data.data.id, msgId);
  });

  async function checkPaymentStatus(payId, msgId) {
    const timeout = setTimeout(async () => {
      clearInterval(interval);
      try {
        const cancelRes = await axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const cancelData = cancelRes.data;
        if (!cancelData.data) return m.reply(cancelData.message);
        m.reply(`⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.`);
      } catch (err) {
        m.reply(`Gagal membatalkan: ${err.message}`);
      }
      deleteMessage(msgId);
    }, 300000); // 5 menit

    const interval = setInterval(async () => {
      try {
        const statusRes = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
          id: payId,
          api_key: global.apikeyAPI
        });
        const statusData = statusRes.data;
        if (!statusData.data) return;

        console.log('Status pembayaran:', statusData.data.status);

        if (statusData.data.status === 'success') {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);

          m.reply(`*── TRANSAKSI BERHASIL ──*
🆔 ID Pembayaran: ${statusData.data.reff_id}
📄 Diterima ${func.toRupiah(statusData.data.get_balance)}
🌐 Status: ${statusData.data.status}
⏰ Tanggal: ${statusData.data.date}
Terimakasih sudah menggunakan layanan kami👏.`);

          await func.sleep(2000);

          const filePath = "./data/script/scpanelxpush.zip";
          if (!fs.existsSync(filePath)) return m.reply('File tidak ditemukan di server.');

          try {
            await sock.sendMessage(m.chat, {
              document: fs.readFileSync(filePath),
              fileName: 'scpanelxpush.zip',
              mimetype: 'application/zip',
              caption: '📦 Berikut adalah file yang kamu beli.'
            });
          } catch (err) {
            m.reply(`Gagal mengirim file: ${err.message}`);
          }

        } else if (['failed', 'cancel'].includes(statusData.data.status)) {
          clearInterval(interval);
          clearTimeout(timeout);
          deleteMessage(msgId);
          m.reply('Pembayaran kamu gagal/dibatalkan oleh sistem.');
        }

      } catch (err) {
        console.error('Error saat cek status pembayaran:', err.response?.data || err.message);
        m.reply(`Terjadi kesalahan saat cek status. Coba lagi atau lapor ke ${global.owner}`);
      }
    }, 5000);
  }

} catch (error) {
  m.reply(`Saat bot melakukan fetch, ada kesalahan`);
  m.reply(`Error: ${error.message}`);
  console.error(error);
}
};
break;

case "buyvps": {
  if (global.apidigitalocean.length < 1) return m.reply("Maaf, VPS sedang tidak tersedia.");
  if (m.isGroup) return m.reply("Pembelian VPS hanya tersedia di private chat.");
  if (sock[m.sender]) return m.reply("Masih ada transaksi yang belum diselesaikan.\n\nKetik *.batalbeli* untuk membatalkan.");

  if (args.length < 4) {
    return sock.sendMessage(m.chat, {
      buttons: [{
        buttonId: 'action',
        buttonText: { displayText: 'Pilih VPS' },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Pilih VPS',
            sections: [{
              rows: [
                { header: "RAM 1GB & 1 CPU", title: "Sgp Ubuntu 20.04", description: "Rp20.000", id: ".buyvps vps1g1c ubuntu 20-04 sgp1 20000" },
                { header: "RAM 2GB & 1 CPU", title: "Sgp Ubuntu 20.04", description: "Rp25.000", id: ".buyvps vps2g1c ubuntu 20-04 sgp1 25000" },
                { header: "RAM 2GB & 2 CPU", title: "Sgp Ubuntu 20.04", description: "Rp30.000", id: ".buyvps vps2g2c ubuntu 20-04 sgp1 30000" },
                { header: "RAM 4GB & 2 CPU", title: "Sgp Ubuntu 20.04", description: "Rp35.000", id: ".buyvps vps4g2c ubuntu 20-04 sgp1 35000" },
                { header: "RAM 8GB & 4 CPU", title: "Sgp Ubuntu 20.04", description: "Rp50.000", id: ".buyvps vps8g4c ubuntu 20-04 sgp1 50000" },
                { header: "RAM 16GB & 4 CPU", title: "Sgp Ubuntu 20.04", description: "Rp60.000", id: ".buyvps vps16g4c ubuntu 20-04 sgp1 60000" }
              ]
            }]
          })
        }
      }],
      headerType: 1,
      viewOnce: true,
      text: "\nPilih Spesifikasi VPS 🛍️",
      contextInfo: { isForwarded: true }
    }, { quoted: null });
  }

  const [sizeOption, osOptionRaw, osVersionRaw, regionOption, harga] = args;
  const osOption = osOptionRaw.toLowerCase();
  const osVersionOption = osVersionRaw.toLowerCase();
  const baseAmount = Number(harga);
  const unique = func.generateRandomNumber(110, 250);
  const amount = baseAmount + unique;
  const password = crypto.randomBytes(10).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 10);
  const hostname = `skyzopedia${func.generateRandomNumber(1, 10)}`;

  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '7': 'centos-7-x64', '8': 'centos-8-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };
  const regionMap = {
    sgp1: 'Singapore', nyc3: 'New York', ams3: 'Amsterdam', lon1: 'London',
    fra1: 'Frankfurt', sfo1: 'San Francisco', blr1: 'Bangalore', tor1: 'Toronto'
  };

  if (!osMap[osOption] || !osMap[osOption][osVersionOption]) return m.reply(`*OS atau versinya tidak valid!*`);
  if (!sizeMap[sizeOption]) return m.reply(`*Ukuran VPS tidak valid!*`);
  if (!regionMap[regionOption]) return m.reply(`*Region tidak valid!*`);

  const reffId = generateRandomText(12);

  try {
    const qris = await axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
      reff_id: reffId,
      type: "ewallet",
      method: "QRISFAST",
      nominal: amount,
      api_key: global.apikeyAPI
    });

    const pay = qris.data.data;
    const teks = `*── INFORMASI PEMBAYARAN ──*\n\n` +
      `• Reff ID: ${reffId}\n` +
      `• Total: Rp${func.toRupiah(amount)}\n` +
      `• VPS: ${sizeOption.toUpperCase()} - ${regionOption.toUpperCase()}\n` +
      `• Expired: 5 menit`;

    const sent = await sock.sendMessage(m.chat, {
      image: { url: pay.qr_image_url },
      caption: teks,
      buttons: [{ buttonId: '.batalbeli', buttonText: { displayText: 'Batalkan Pembelian' }, type: 1 }],
      headerType: 1,
      viewOnce: true,
      contextInfo: { isForwarded: true }
    });

    sock[m.sender] = {
      msg: sent,
      chat: m.sender,
      idDeposit: pay.id,
      amount: amount.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender]?.status) {
          await sock.sendMessage(m.sender, { text: "QRIS telah expired." }, { quoted: sent });
          await sock.sendMessage(m.sender, { delete: sent.key });
          delete sock[m.sender];
        }
      }, 300000)
    };

    const interval = setInterval(async () => {
      const statusCheck = await axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
        id: pay.id,
        api_key: global.apikeyAPI
      });

      const data = statusCheck.data.data;
      if (data.status === "success") {
        clearInterval(interval);
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(m.sender, { text: "*PEMBAYARAN BERHASIL ✅*\nMembuat VPS Anda..." }, { quoted: sent });

        const dropletData = {
          name: hostname,
          region: regionOption,
          size: sizeMap[sizeOption],
          image: osMap[osOption][osVersionOption],
          ssh_keys: null,
          backups: false,
          ipv6: true,
          user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`,
          private_networking: null,
          volumes: null,
          tags: ['T'],
        };

        const create = await fetch('https://api.digitalocean.com/v2/droplets', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + global.apidigitalocean,
          },
          body: JSON.stringify(dropletData),
        });

        const created = await create.json();
        if (!create.ok) throw new Error(`Gagal: ${created.message}`);

        const dropletId = created.droplet.id;
        await new Promise(res => setTimeout(res, 60000));

        const info = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + global.apidigitalocean,
          },
        });

        const detail = await info.json();
        const ipVPS = detail.droplet.networks.v4?.[0]?.ip_address || "IP tidak ditemukan";

        const msg = `*VPS BERHASIL DIBUAT ✅*\n\n*• ID:* ${dropletId}\n*• IP:* ${ipVPS}\n*• Username:* root\n*• Password:* ${password}`;

        await sock.sendMessage(m.sender, { text: msg }, { quoted: null });
        await sock.sendMessage(m.sender, { delete: sent.key });
        delete sock[m.sender];
      }
    }, 5000);
  } catch (err) {
    console.error(err);
    m.reply(`Gagal membuat QRIS atau VPS: ${err.response?.data?.message || err.message}`);
  }

  break;
}

case "batalbeli": {
  if (!sock[m.sender]) return m.reply("❌ Tidak ada transaksi yang sedang berjalan.");
  delete sock[m.sender];
  m.reply("✅ Transaksi berhasil dibatalkan.");
}
break;

case 'mlbb':
    case 'ml':
    case 'ml_wdp':
    case 'ml_sl':
    case 'ml_tl':
    case 'wdp':
    case 'starlight':
    case 'twilight':
    case 'hok':
    case 'aov':
    case 'lol':
    case 'coc':
    case 'ff':
    case 'pubg':

    case 'byu_data':
    case 'tsel_data':
    case 'xl_data':
    case 'axis_data':
    case 'isat_data':
    case 'tri_data':

    case 'byu_pulsa':
    case 'tsel_pulsa':
    case 'xl_pulsa':
    case 'axis_pulsa':
    case 'isat_pulsa':
    case 'tri_pulsa':

    case 'pln': {
      const products = {
        'ml': {
          name: 'mobile-legends',
          category: 'games',
          filter_type: 'Umum',
          filter_code: null
        },
        'mlbb': {
          name: 'mobile-legends',
          category: 'games',
          filter_type: 'Umum',
          filter_code: null
        },
        'ml_wdp': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLW'
        },
        'ml_sl': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLS'
        },
        'ml_tl': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLT'
        },
        'wdp': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLW'
        },
        'starlight': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLS'
        },
        'twilight': {
          name: 'mobile-legends',
          category: 'games',
          filter_code: 'MLT'
        },
        'hok': {
          name: 'honor-of-kings',
          category: 'games',
          filter_code: null
        },
        'aov': {
          name: 'arena-of-valor',
          category: 'games',
          filter_code: null
        },
        'lol': {
          name: 'league-of-legends',
          category: 'games',
          filter_code: null
        },
        'coc': {
          name: 'clash-of-clans',
          category: 'games',
          filter_code: null
        },
        'ff': {
          name: 'free-fire',
          category: 'games',
          filter_code: null
        },
        'pubg': {
          name: 'pubg',
          category: 'games',
          filter_code: null
        },

        'byu_data': {
          name: 'byu',
          category: 'data-internet',
          filter_code: null
        },
        'telkomsel_data': {
          name: 'telkomsel',
          category: 'data-internet',
          filter_code: null
        },
        'tsel_data': {
          name: 'telkomsel',
          category: 'data-internet',
          filter_code: null
        },
        'xl_data': {
          name: 'xl',
          category: 'data-internet',
          filter_code: null
        },
        'axis_data': {
          name: 'axis',
          category: 'data-internet',
          filter_code: null
        },
        'indosat_data': {
          name: 'indosat',
          category: 'data-internet',
          filter_code: null
        },
        'isat_data': {
          name: 'indosat',
          category: 'data-internet',
          filter_code: null
        },
        'tri_data': {
          name: 'tri',
          category: 'data-internet',
          filter_code: null
        },

        'byu_pulsa': {
          name: 'byu',
          category: 'pulsa',
          filter_code: null
        },
        'telkomsel_pulsa': {
          name: 'telkomsel',
          category: 'pulsa',
          filter_code: null
        },
        'tsel_pulsa': {
          name: 'telkomsel',
          category: 'pulsa',
          filter_code: null
        },
        'xl_pulsa': {
          name: 'xl',
          category: 'pulsa',
          filter_code: null
        },
        'axis_pulsa': {
          name: 'axis',
          category: 'pulsa',
          filter_code: null
        },
        'indosat_pulsa': {
          name: 'indosat',
          category: 'pulsa',
          filter_code: null
        },
        'isat_pulsa': {
          name: 'indosat',
          category: 'pulsa',
          filter_code: null
        },
        'tri_pulsa': {
          name: 'tri',
          category: 'pulsa',
          filter_code: null
        },

        'pln': {
          name: 'pln',
          category: 'voucher',
          filter_code: null
        }

      };

      const productKey = products[command];
      if (!productKey) {
        return m.reply('Perintah tidak valid.');
      }

      try {
        const response = await axios.post(
          `${global.baseurl}/api/h2h/price-list/${productKey.category}/${productKey.name}`, {
            filter_code: productKey.filter_code || undefined,
            api_key: global.apikeyAPI,
          }, {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        );

        const result = response.data;

        if (!result.data) {
          return m.reply(result.message);
        }

        let listText = `*✅ : Tersedia*
*⛔ : Tidak Tersedia*

\`\`\`🛒 Ingin melakukan topup?, silahkan ketik .topup code,tujuan\`\`\`.\n\n`;
        result.data.forEach((item) => {
          const profit = (global.profit / 100) * item.price;
          const finalPrice = Number(item.price) + Number(Math.ceil(profit));
          listText += `╭⟬ *${item.status} ${item.name}*\n` +
            `┆•  Harga: ${func.toRupiah(finalPrice)}\n` +
            `┆•  Kode: ${item.code}\n` +
            `┆•  Note: ${item.note}\n` +
            `╰──────────◇\n\n`;
        });

        m.reply(listText);
      } catch (error) {
        m.reply(`Error: ${error.response.data.message}`);
        console.error(error.response.data);
      }
   }
      break;
      

case 'topup': {
      if (!text) return m.reply(example(`AX5,083874320051`));

    const input = text.trim();
    if (!input.includes(',')) {
        return m.reply('❌ Format salah. Gunakan format seperti .topup KODE,ID');
    }

    const [codeRaw, targetRaw] = input.split(',');
    const code = codeRaw?.trim();
    const target = targetRaw?.trim();

    if (!code || !target) {
        return m.reply('❌ Format salah. Kode atau tujuan tidak boleh kosong.');
    }

    m.reply(`🌐Mohon menunggu sebentar.`);
      
      try {
      const reffId = generateRandomText(10);
      
      const tmpDirPath = path.join(__dirname, 'tmp');
      const tmpFilePath = path.join(tmpDirPath, 'orders.json');

      if (!fs.existsSync(tmpDirPath)) {
        fs.mkdirSync(tmpDirPath, {
          recursive: true
        });
      }

      if (!fs.existsSync(tmpFilePath)) {
        fs.writeFileSync(tmpFilePath, '{}');
      }

      let orderData = {};

      try {
        orderData = JSON.parse(fs.readFileSync(tmpFilePath, 'utf8'));
      } catch (error) {
        console.error(`Gagal membaca file order data: ${error}`);
      }

      if (orderData[m.sender]) {
        sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
        return m.reply(`Kamu masih memiliki transaksi yang belum selesai. Tunggu hingga pembayaran selesai, kadaluarsa, atau gagal untuk membuat transaksi baru.\n\n _Ingin membatalkan topup? ketik *${prefix}cancel*_`);
      }

      const date = new Date();
      const currentDate = new Date(date.toLocaleString('en-US', {
        timeZone: config.time_zone
      }));

      axios.post(`${global.baseurl}/api/h2h/price-list/all`, {
          api_key: global.apikeyAPI,
        })
        .then(response => {
          const data = response.data;
          if (!data.data) return m.reply(data.message);

          const produk = data.data.find(item => item.code === code.toUpperCase());
          if (!produk) return m.reply('Produk tidak ditemukan.');
          
          const profit = (global.profit / 100) * produk.price;
          const finalPrice = Number(produk.price) + Math.ceil(profit);
          const produkDetail = `*Nama Produk:* ${produk.name}\n*Kode Produk:* ${produk.code}`;
          
          const reportText = `Ada transaksi baru nih:\n\nReff Id: ${reffId}\nNomor WA: ${m.sender}\nProduk yg dibeli: ${produk.name}\nHarga produk (sdh termasuk PPN): ${toRupiah(parseInt(finalPrice))}\nHarga produk (blm termasuk PPN): ${toRupiah(parseInt(produk.price))}\nProfit: ${toRupiah(parseInt(profit))} (${config.api.profit}%)\n\nKamu dapat menarik saldo profit kamu menggunakan perintah *${prefix}wd_balance* atau melalui web Payment Gateway resmi: ${global.baseurl}/transfer`;
          
          performDeposit(reffId, produkDetail, finalPrice, code, target, reportText);
        })
        .catch(error => {
          sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
          m.reply(`Error: ${error.response.data.message}`);
          console.error(error.response.data);
        });

      function performDeposit(reffId, product, nominal, code, target, reportText) {
        axios.post(`${global.baseurl}/api/h2h/deposit/create`, {
            reff_id: reffId,
            type: 'ewallet',
            method: 'QRISFAST',
            nominal: nominal,
            api_key: global.apikeyAPI,
          })
          .then(response => {
            const data = response.data;
            if (!data.data) return m.reply(data.message);
            
            console.log(data.data)
            
            const text = `*TRANSAKSI BERHASIL DIBUAT*\n\n*Kode Pembayaran:* ${data.data.reff_id}\n*Nominal:* ${toRupiah(data.data.nominal)}\n${product}\n*Dibuat Pada:* ${data.data.created_at}\n\n*Note:* Pembayaran akan otomatis dibatalkan 5 menit lagi!\n\n\`Bot ini telah terintegrasi dengan API Payment Gateway yang disediakan oleh ${global.baseurl}\``;

            sock.sendMessage(m.chat, {
              image: {
                url: data.data.qr_image_url
              },
              caption: text,
            }, {
              quoted: qcmd
            }).then(sendMessage => {
              const msgId = sendMessage.key.id;
              orderData[m.sender] = {
                msgId,
                reffId,
                payId: data.data.id,
                createdAt: data.data.created_at
              };
              fs.writeFileSync(tmpFilePath, JSON.stringify(orderData, null, 2));
              checkPaymentStatus(msgId, data.data.id, reffId, code, target, reportText);
            });
          })
          .catch(error => {
            sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
            m.reply(`Error: ${error.response.data.message}`);
            console.error(error.response.data);
          });
      }

      function checkPaymentStatus(msgId, payId, reffId, code, target, reportText) {
        const timeout = setTimeout(() => {
          clearInterval(interval);

          axios.post(`${global.baseurl}/api/h2h/deposit/cancel`, {
              id: payId,
              api_key: global.apikeyAPI,
            })
            .then(() => {
              deleteMessage(msgId);
              delete orderData[m.sender];
              fs.writeFileSync(tmpFilePath, JSON.stringify(orderData, null, 2));
              sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
              m.reply('⚠️ *Pembayaran Dibatalkan Otomatis* setelah 5 menit tanpa konfirmasi keberhasilan.');
            });
        }, 300000);

        const interval = setInterval(() => {
          axios.post(`${global.baseurl}/api/h2h/deposit/status`, {
              id: payId,
              api_key: global.apikeyAPI,
            })
            .then(response => {
              const data = response.data.data;
              
              if (data.status === 'success' || data.status === 'failed') {
                clearInterval(interval);
                clearTimeout(timeout);

                deleteMessage(msgId);
                delete orderData[m.sender];
                fs.writeFileSync(tmpFilePath, JSON.stringify(orderData, null, 2));

                  performTopupTransaction(reffId, code, target);
                  sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})	
                  m.reply(`⬣ *Pembayaran Berhasil!*\n\n` +
                    `◉ ID Pembayaran: ${data.reff_id}\n` +
                    `◉ Status: ${data.status}\n` +
                    `◉ Diterima: ${toRupiah(data.get_balance)}\n` +
                    `◉ Tanggal: ${data.date}\n\n` +
                    `Terimakasih.`);                                      
                    
                    sock.sendMessage("6285664637742@s.whatsapp.net", { text: `Hai ${ownerName} - @${ownerNumber}\n\n${reportText}`, mentions: [`${ownerNumber}@s.whatsapp.net`] });
                } else if (data.status === 'failed' || data.status === 'cancel' || data.status === 'canceled') {
                  clearInterval(interval);
                  deleteMessage(msgId);
                  sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	
                  return m.reply('Sangat disayangkan sekali. Pembayaran kamu dibatalkan oleh sistem.');
                }
              
            }).catch(error => {
              sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	
              m.reply(`Error: ${error.response.data.message}`);
              console.error(error.response.data);
            });
        }, 5000);
      }

      function performTopupTransaction(reffId, code, target) {
        axios.post(`${global.baseurl}/api/h2h/transaction/create`, {
            reff_id: reffId,
            product_code: code.toUpperCase(),
            target: target,
            api_key: global.apikeyAPI,
          })
          .then(response => {
            const data = response.data;

            if (!data.data) return m.reply(data.message);

            const text = 'Pembelian sedang di proses...';

            sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	

            sock.sendMessage(m.chat, {
              text
            }, {
              quoted: qcmd
            }).then(sendMessage => {
              const msgId = sendMessage.key.id;
              checkTransactionStatus(msgId, data.data.id);
            });
          })
          .catch(error => {
            sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
            m.reply(`Error: ${error.response.data.message}`);
            console.error(error.response.data);
          });
      }

      function checkTransactionStatus(msgId, id) {
        const interval = setInterval(() => {
          axios.post(`${global.baseurl}/api/h2h/transaction/status`, {
              id: id,
              api_key: global.apikeyAPI,
            })
            .then(response => {
              const data = response.data.data;

              if (data.status === 'success') {
                clearInterval(interval);

                deleteMessage(msgId);
                sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})	

                const text = `⬣ *Pembelian Berhasil!*\n\n` +
                  `◉ ID Transaksi: ${data.reff_id}\n` +
                  `◉ Status: ${data.status}\n` +
                  `◉ Layanan: ${data.name}\n` +
                  `◉ Target: ${data.target}\n` +
                  `◉ Serial Number: ${data.serial_number}\n` +
                  `◉ Tanggal: ${data.date}\n\n` +
                  `Terimakasih.`;

                sock.sendMessage(m.chat, {
                  text
                }, {
                  quoted: qcmd
                });
              } else if (data.status === 'cancel' || data.status === 'canceled') {
                clearInterval(interval);
                deleteMessage(msgId);
                sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
              } else if (data.status === 'failed') {
                clearInterval(interval);
                deleteMessage(msgId);
                sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
                m.reply('Transaksi gagal. Silakan laporkan masalah ini ke owner bot.');
              }
            }).catch(error => {
              sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})	
              m.reply(`Error: ${error.response.data.message}`);
              console.error(error.response.data);
            });
        }, 5000);
      };
      
      } catch (error) {
      	sock.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})	
              m.reply(`Error: ${error.message}`);
              console.error(error);
             };
             
      break;
    };
    
    case 'buy': {
  if (!isOwner) return replyown(msg.owner);
  if (!text) return m.reply(example(`code,tujuan`));

  const [productCodeRaw, targetValue] = text.split(",");
  const productCode = productCodeRaw?.trim()?.toUpperCase();

  if (!productCode || !targetValue) {
    return m.reply(`Semua parameter (code, target) diperlukan.\n\nContoh: ${prefix}${command} ML3,628299715|10135`);
  }

  try {
    sock.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    const reffId = generateRandomText(10);

    const response = await axios.post(`${global.baseurl}/api/h2h/transaction/create`, {
      reff_id: reffId,
      product_code: productCode,
      target: targetValue,
      api_key: global.apikeyAPI
    });

    const resData = response.data;

    if (!resData.data) {
      return m.reply(resData.message || 'Terjadi kesalahan pada respon API.');
    }

    const replyText = `🛒 *Pesanan Sedang Diproses!*\n\n` +
      `📦 *Layanan:* ${resData.data.name}\n` +
      `🎯 *Target:* ${resData.data.target}\n` +
      `🆔 *Reff ID:* ${resData.data.reff_id}\n` +
      `💰 *Harga:* ${func.toRupiah(resData.data.price)}\n` +
      `🔢 *SN:* ${resData.data.serial_number || '-'}\n` +
      `🕒 *Waktu Order:* ${resData.data.date}\n\n` +
      `Mohon tunggu, pesananmu sedang diproses...`;

    const sendMessage = await sock.sendMessage(m.chat, { text: replyText }, { quoted: m });
    const msgId = sendMessage.key.id;

    checkTransactionStatus(resData.data.id, msgId, resData.data);

  } catch (error) {
    const errorMsg = error?.response?.data?.message || error.message || 'Terjadi kesalahan.';
    m.reply(`❌ *Error: ${errorMsg}*`);
    console.error('AXIOS ERROR:', error?.response?.data || error);
  }

  async function checkTransactionStatus(payId, msgId, initialData) {
    let attempt = 0;
    const maxAttempts = 10;

    const interval = setInterval(async () => {
      attempt++;
      try {
        const response = await axios.post(`${global.baseurl}/api/h2h/transaction/status`, {
          id: payId,
          api_key: global.apikeyAPI
        });

        const statusData = response.data;

        if (!statusData.data) {
          m.reply('⚠️ Gagal mengambil status transaksi.');
          return;
        }

        const status = statusData.data.status;
        const sn = statusData.data.serial_number || '-';

        if (status === 'success') {
          clearInterval(interval);

          m.reply(`✅ *Pembelian Berhasil!*\n\n` +
            `🧾 *ID Pembayaran:* ${statusData.data.reff_id}\n` +
            `📦 *Layanan:* ${statusData.data.name}\n` +
            `🎯 *Target:* ${statusData.data.target}\n` +
            `🔢 *Serial Number:* ${sn}\n` +
            `🕒 *Tanggal:* ${statusData.data.date}\n\n` +
            `Terima kasih telah menggunakan layanan kami!`);
          deleteMessage(msgId);

        } else if (status === 'failed') {
          clearInterval(interval);
          m.reply(`❌ *Transaksi Gagal!*\n\nPesanan kamu tidak dapat diproses. Silakan hubungi admin untuk refund.`);

          deleteMessage(msgId);

          sock.sendMessage(global.ownerNumber + "@s.whatsapp.net", {
            text: `❌ TRANSAKSI GAGAL\n\nID: ${statusData.data.reff_id}\nLayanan: ${statusData.data.name}\nTarget: ${statusData.data.target}\nHarga: ${func.toRupiah(initialData.price)}\nStatus: Gagal\nSilakan cek manual dan proses refund jika diperlukan.`
          });
        }

        if (attempt >= maxAttempts) {
          clearInterval(interval);
          m.reply(`⏳ *Transaksi Pending Terlalu Lama!*\n\nAdmin telah diberitahu untuk pengecekan manual.`);

          sock.sendMessage(global.ownerNumber + "@s.whatsapp.net", {
            text: `⚠️ TRANSAKSI PENDING TERLALU LAMA\n\nID: ${initialData.reff_id}\nLayanan: ${initialData.name}\nTarget: ${initialData.target}\nStatus: ${statusData.data.status}\nPerlu dicek manual.`
          });
        }

      } catch (error) {
        console.error('STATUS ERROR:', error?.response?.data || error);
      }
    }, 5000);
  }

  break;
}

case "autoread": case "autoreadsw": case "anticall": case "autotyping": case "autorecording": {
if (!isOwner) return replyown(msg.owner)
const getStatus = () => {
let teks = ""
for (let i of Object.keys(setbot)) {
teks += `* *${func.capital(i)} :* ${setbot[i] ? "aktif ✅" : "tidak aktif ❌"}
`
}
return teks
}
if (!text || !/on|off/.test(text)) return m.reply(`\nContoh : *${cmd}* on/off\n\n${getStatus()}`)
const input = text.toLowerCase()
if (/on/.test(input)) {
if (setbot[command.toLowerCase()] == true) return m.reply(`*${func.capital(command)}* sudah aktif!`)
if (command == "autotyping" && setbot.autorecording == true) setbot.autorecording = false
if (command == "autorecording" && setbot.autotyping == true) setbot.autotyping = false
setbot[command.toLowerCase()] = true
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil menyalakan *${func.capital(command)}* ✅

${getStatus()}`)
} 
if (/off/.test(input)) {
if (setbot[command.toLowerCase()] == false) return m.reply(`${func.capital(command)} sudah tidak aktif!`)
setbot[command.toLowerCase()] = false
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil mematikan *${func.capital(command)}* ✅

${getStatus()}`)
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isOwner) return
exec(chats.slice(2), (err, stdout) => {
if(err) return sock.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return sock.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if (m.text.toLowerCase() == "vps") {
    let asciiCodes = vps;
    
    let text = String.fromCharCode(...asciiCodes);
    
    return m.reply(text);
}

if (m.text.toLowerCase() == "script") {
    let anu = script;
    
    let text = String.fromCharCode(...anu);
    
    return m.reply(text);
}

if (m.text.toLowerCase() == "bot") {
	repe(`Shopbotz Online ✅`)
	}
	
	if (m.text.toLowerCase() == "p") {
	m.reply(`pa pe pa pe
gapunya agama ya dek pa pe pa pe salam woy 🤓😠`)
	}

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return sock.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
sock.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
sock.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})