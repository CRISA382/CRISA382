require("./server/handler.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "6288276348522"
global.namabot = "DanzBotz" 
global.namaowner = "Skydanzpedia"
global.linkgc = 'https://chat.whatsapp.com/IYZ8wTwKKSWCqYdY4dbR9O'
global.packname = "Skydanz"
global.author = "Skydanz"
global.versionbot = "V-3.0.0"
global.foother = "Payment"

// >~~~~~ Setting gateaway ~~~~~~~~ //
global.linkgrupresellerpanel = ""
global.baseurl = "https://forestapi.web.id"
global.apikeyAPI = "sk-fyoycohwe2fr6e" // isi
global.profit = '4'

// >~~~~~~~ Setting Orderkuota ~~~~~~~~< //

global.QrisOrderKuota = ""
global.ApikeyOrderKuota = ""
global.IdMerchant = ""
global.pinH2H = ""
global.passwordH2H = ""

global.ApikeyRestApi = "new"

// >~~~~~ Setting emote ~~~~~~~~ //
global.succes = "✅"
global.gagal = "❌"
global.proses = "⌛"

// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "089690235468"
global.ovo = "isi" 
global.gopay = "isi"

// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "120363373941283254@newsletter"
global.namasaluran = "!- Skydanz Marketplace"
global.linksaluran = "https://whatsapp.com/channel/0029VayrD8xI1rcrL9sc4s03"

// >~~~~~~~~ Setting Do ~~~~~~~~~< //
global.apidigitalocean = ""

// >~~~~~~~~~~ Setting Image ~~~~~~~~~~~~< //
global.imgdanz = "https://files.catbox.moe/rab8da.jpg"

// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://panel.ndutvps.com"
global.apikey = "ptla_Ku8Rem6HncUGKWh0bkAglUIRRjXSPQ1HTCPSsYoj894" // Isi api ptla

global.capikey = "ptlc_U5rlBaVAmSG1FQ1OXOzHTjoDLiCphS4WdlQs8vnQDYM" // Isi api ptlc

//~~~~~ Settings Api Panel ~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID 
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "ptla_bWNQIJpKJkPERlnQs8p2UUIZUYrTF0mESeTO7UM1z" //ptla
global.capikeyV2 = "ptlc_e5HDwnIfiUDyDNst8501HOu0aeuSWxMmxKFWRyOjc" //ptlc

//~~~~~ Settings Api Panel Untuk Buy Otomatis ~~~~~//
global.eggAPI = "15" // Egg ID
global.nestidAPI = "5" // nest ID 
global.locAPI = "1" // Location ID
global.domainAPI = "https://hynnpanel.zakzz.web.id"
global.apikeyAPIPANEL = "ptla_z3lDjspCE2PWu8uCcZmOcnz4Zl7wF2s5svVudkgVKc8" //ptla
global.capikeyAPI = "ptlc_ZRIB3pp9uNYI7prc8xhqcMTkuP2XbRyUszHU0r9gmNV" //ptlc

// >~~~~~~~~ Setting Message ~~~~~~~~~< //

global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
private: "Fitur ini untuk dalam private chat!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}



let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})